# Catalogue Files - Location and Download Guide

## 📍 Where Files Are Located

### Generated Files Location
```
/home/z/my-project/catalogue/
```

### File Structure
```
catalogue/
├── catalogue_full.html           # Complete HTML catalogue (29KB)
├── catalogue_full.pdf            # Complete PDF catalogue (not generated yet)
├── catalogue_manifest.json        # File manifest
├── report.json                  # Detailed generation report
├── sections/                    # Individual brand sections (HTML)
│   ├── brand-ikea.html
│   ├── brand-herman-miller.html
│   ├── brand-steelcase.html
│   ├── brand-divers.html
│   ├── elec-samsung.html
│   ├── elec-dell.html
│   ├── elec-logitech.html
│   └── elec-apple.html
├── pdfs/                       # Individual brand sections (PDF - empty)
├── catalogue_master.json         # Master product data
├── catalogue_electronics.json    # Electronics product data
├── code.txt                     # Brand themes/colors
├── brand_priority.json          # Brand ordering
└── beauty.txt                   # Enable enhanced UI
```

## 📥 How to Download Files

### Method 1: Via Web UI (Recommended)

1. **Open the PDF Catalogue Builder**
   - Navigate to the application in your browser
   - Click on **"Status & Files"** tab

2. **Browse Generated Files**
   - All generated files are listed
   - Shows file size, type, and modification date
   - Click the download button (↓) next to each file

3. **Download File**
   - Click the download button
   - File opens in new tab/starts download
   - Toast notification confirms download

### Method 2: Direct API URL

You can download files directly using these URLs:

#### Main Catalogue Files
```
http://localhost:3000/api/catalogue/download/catalogue_full.html
http://localhost:3000/api/catalogue/download/catalogue_full.pdf (if generated)
```

#### Section Files (HTML)
```
http://localhost:3000/api/catalogue/download/brand-ikea.html
http://localhost:3000/api/catalogue/download/brand-herman-miller.html
http://localhost:3000/api/catalogue/download/brand-steelcase.html
http://localhost:3000/api/catalogue/download/brand-divers.html
http://localhost:3000/api/catalogue/download/elec-samsung.html
http://localhost:3000/api/catalogue/download/elec-dell.html
http://localhost:3000/api/catalogue/download/elec-logitech.html
http://localhost:3000/api/catalogue/download/elec-apple.html
```

#### Reports and Manifests
```
http://localhost:3000/api/catalogue/download/report.json
http://localhost:3000/api/catalogue/download/catalogue_manifest.json
```

### Method 3: Command Line (curl)

```bash
# Download main HTML catalogue
curl -O http://localhost:3000/api/catalogue/download/catalogue_full.html

# Download a specific section
curl -O http://localhost:3000/api/catalogue/download/brand-ikea.html

# Download report
curl -O http://localhost:3000/api/catalogue/download/report.json
```

### Method 4: Direct File Access

You can also copy files directly from the server:

```bash
# Copy to current directory
cp /home/z/my-project/catalogue/catalogue_full.html .

# Copy all sections
cp /home/z/my-project/catalogue/sections/*.html .

# Copy report
cp /home/z/my-project/catalogue/report.json .
```

## 📊 Current File Status

### ✅ Generated Files

| File | Size | Type | Status |
|------|-------|------|--------|
| catalogue_full.html | 29 KB | HTML | ✅ Ready |
| brand-ikea.html | 10 KB | HTML | ✅ Ready |
| brand-herman-miller.html | 6.7 KB | HTML | ✅ Ready |
| brand-steelcase.html | 5.0 KB | HTML | ✅ Ready |
| brand-divers.html | 5.2 KB | HTML | ✅ Ready |
| elec-samsung.html | 7.0 KB | HTML | ✅ Ready |
| elec-dell.html | 5.2 KB | HTML | ✅ Ready |
| elec-logitech.html | 5.1 KB | HTML | ✅ Ready |
| elec-apple.html | 5.3 KB | HTML | ✅ Ready |
| report.json | 903 B | JSON | ✅ Ready |
| catalogue_manifest.json | 2.1 KB | JSON | ✅ Ready |

### ❌ Not Generated Yet

| File | Reason | Solution |
|------|--------|----------|
| catalogue_full.pdf | Edge browser not installed | Install Edge or use HTML |
| Section PDFs | PDF generation requires Edge | Use HTML sections instead |

## 🎯 Best Way to Access

### For Quick Preview
Use the Web UI → Status & Files tab → Click download button

### For Bulk Download
Use command line:
```bash
cd /home/z/my-project/catalogue
tar -czf catalogue.tar.gz *.html sections/*.html
```

### For Programmatic Access
Use the API endpoints with your application

## 🔍 Checking File Status

### Via API
```bash
curl http://localhost:3000/api/catalogue/status
```

This returns:
- Total products
- Match rate
- List of all files with sizes
- Last generation time

### Via Command Line
```bash
# List all files
ls -lh /home/z/my-project/catalogue/*.html /home/z/my-project/catalogue/sections/

# Check if PDF exists
ls -lh /home/z/my-project/catalogue/*.pdf
```

## 💡 Tips

1. **Use HTML files if PDF isn't generated**
   - HTML can be printed to PDF from browser
   - Better formatting control
   - Smaller file size

2. **Download sections for individual brands**
   - Useful for brand-specific catalogs
   - Smaller files, faster downloads

3. **Check report.json for details**
   - Shows what was generated
   - Match rates and statistics
   - Any errors that occurred

4. **Use the manifest for automation**
   - `catalogue_manifest.json` lists all generated files
   - Great for batch processing
   - Programmatic access

## 🔧 Troubleshooting

### Issue: "File not found" error

**Solution:**
- Check if file exists in `/home/z/my-project/catalogue/`
- Verify filename spelling (case-sensitive)
- Use the Status API to see available files

### Issue: Download button doesn't work

**Solution:**
- Check browser console for errors
- Try direct URL access
- Clear browser cache and retry

### Issue: PDF not generated

**Solution:**
- HTML files are available as alternative
- Use browser "Print to PDF" functionality
- Install Edge browser for automatic PDF generation

## 📱 Access from Browser

1. Open the PDF Catalogue Builder application
2. Click **"Status & Files"** tab
3. See all generated files listed
4. Click **download button** (↓) for any file
5. File downloads or opens in new tab

## 🎉 Summary

**Files are ready at:**
- Web UI: Status & Files tab
- API: `/api/catalogue/download/[filename]`
- Server: `/home/z/my-project/catalogue/`

**9 HTML files** are currently available for download:
- Complete catalogue (29 KB)
- 8 brand/section files

**Download options:**
- Web UI (easiest)
- Direct API URLs (programmable)
- Command line (fastest)
- Direct file access (local)

All files are immediately downloadable via the web interface!
