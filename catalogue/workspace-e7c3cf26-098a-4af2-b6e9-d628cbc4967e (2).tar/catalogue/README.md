# PDF Catalogue Builder

A modern, full-featured PDF catalogue generation system built with Next.js, featuring intelligent image matching and real-time progress tracking.

## Features

- 🎨 **Beautiful UI** - Modern interface with shadcn/ui components
- ⚡ **Intelligent Image Matching** - 7 matching strategies including fuzzy matching
- 🚀 **Parallel Processing** - Configurable worker threads for faster generation
- 💾 **Caching System** - Up to 90% faster on subsequent runs
- 📊 **Validation Mode** - Pre-flight checks before generation
- 📈 **Real-time Progress** - Live feedback during generation
- 🎯 **Detailed Statistics** - Match rates, per-brand breakdown, and more
- 🔧 **Configurable** - Fine-tune every aspect of generation
- 📱 **Responsive Design** - Works on all screen sizes

## Quick Start

### 1. Setup

The project is already set up with Next.js 16, TypeScript, and all required dependencies.

```bash
# Install dependencies (if needed)
bun install
```

### 2. Add Your Products

Edit the product data files in the `catalogue/` directory:

- **catalogue_master.json** - Main product catalogue
- **catalogue_electronics.json** - Electronics products (optional)
- **code.txt** - Brand themes and colors
- **brand_priority.json** - Brand ordering for TOC

### 3. Add Product Images

Place your product images in `catalogue/images_photos/`.

**Image Naming Conventions:**
- Exact ID match: `IKEA-001.jpg`
- Brand-label combo: `ikea-bureau-flaxa.jpg`
- Label only: `bureau-flaxa.jpg`
- Use JPG, PNG, or WebP formats

### 4. Start the Development Server

```bash
bun run dev
```

The application will be available at `http://localhost:3000`

### 5. Generate Your Catalogue

1. Open the PDF Catalogue Builder in your browser
2. Configure your generation settings:
   - Output format (HTML, PDF, or both)
   - Enable parallel processing
   - Set match threshold (0.5 - 1.0)
   - Configure image size limits
3. Click "Validate" to check your data
4. Click "Generate Catalogue" to create the PDF
5. Download from the Status & Files tab

## Data Structure

### Product Item

```json
{
  "id": "IKEA-001",
  "brand": "IKEA",
  "name_fr": "Bureau FLAXA",
  "name_ar": "مكتب فاكسا",
  "label": "Bureau FLAXA",
  "price": "199.00",
  "variants": [
    {
      "kind": "Couleur",
      "value": "Blanc"
    }
  ]
}
```

### Brand Theme

```json
{
  "BRAND_NAME": {
    "primary_color": "#0058A3",
    "logo_path": "/path/to/logo.png"
  }
}
```

## API Endpoints

### Generate Catalogue

```
POST /api/catalogue/generate
```

**Body:**
```json
{
  "format": "both",        // "html", "pdf", or "both"
  "parallel": true,
  "workers": 4,
  "force": false,
  "dryRun": false,
  "matchThreshold": 0.85,
  "minSize": 10000,
  "maxSize": 50000000
}
```

### Validate Catalogue

```
POST /api/catalogue/validate
```

**Body:**
```json
{
  "matchThreshold": 0.85,
  "minSize": 10000,
  "maxSize": 50000000
}
```

### Get Status

```
GET /api/catalogue/status
```

### Download Files

```
GET /api/catalogue/download/[filename]
```

## Image Matching Strategies

The system uses 7 matching strategies (in order):

1. **Manual Map** - Direct mapping in `image_map.json`
2. **Custom Matchers** - User-defined matching functions
3. **Exact ID Match** - Product ID → filename
4. **Brand-Label Combo** - `brand-label.ext`
5. **Label Only** - `label.ext`
6. **Fuzzy Matching** - Jaro-Winkler + Levenshtein distance
7. **Auto Assignment** - Round-robin fallback

### Manual Image Mapping

Create `catalogue/images_photos/image_map.json`:

```json
{
  "IKEA-001": "/path/to/custom-image.jpg",
  "IKEA-002": "/path/to/another-image.jpg"
}
```

### Fuzzy Matching Threshold

- **0.90+** - Very strict, fewer false positives
- **0.80-0.89** - Balanced (recommended)
- **0.70-0.79** - Permissive, more matches
- **< 0.70** - Loose, may include incorrect matches

## Performance Optimization

### Parallel Processing

Enable parallel processing for faster PDF generation:

- **1-4 workers**: Good for low-end systems
- **4-8 workers**: Recommended for most systems
- **8-16 workers**: High-end systems with plenty of RAM

**Note**: Each PDF generation uses ~100-200MB RAM.

### Caching

The system automatically caches:
- Image lists
- Brand themes
- Brand priorities
- Manual image maps

Cache is stored in `.cache/catalogue/`.

### Force Regeneration

Use "Force Regenerate" to:
- Clear the cache
- Regenerate all files
- Update with latest changes

## Configuration Files

### catalogue/config.json (Optional)

```json
{
  "logLevel": "info",
  "minImageSize": 10000,
  "maxImageSize": 50000000,
  "allowedExtensions": [".jpg", ".jpeg", ".png", ".webp"],
  "fuzzyMatchThreshold": 0.85,
  "parallelWorkers": 4,
  "cacheDir": "./.cache/catalogue",
  "outputDir": "./catalogue",
  "enableCache": true,
  "enableParallel": false,
  "imageQualityCheck": true,
  "duplicateDetection": true
}
```

## Troubleshooting

### Low Match Rate

1. Check image filenames match product IDs
2. Lower the match threshold to 0.80
3. Create manual image mappings
4. Use validation mode to see issues

### PDF Generation Fails

1. Ensure Edge browser is installed
2. Try generating HTML only
3. Check file permissions
4. Reduce worker count

### Missing Images

1. Verify images are in `catalogue/images_photos/`
2. Check file sizes (min 10KB, max 50MB)
3. Verify file extensions (jpg, png, webp)
4. Check validation results for details

### Performance Issues

1. Enable caching
2. Reduce parallel workers
3. Split large catalogues into smaller batches
4. Use dry-run mode to test configuration

## Output Files

Generated files are saved in the `catalogue/` directory:

- `catalogue_full.html` - Complete HTML catalogue
- `catalogue_full.pdf` - Complete PDF catalogue
- `sections/` - Individual brand sections (HTML)
- `pdfs/` - Individual brand sections (PDF)
- `report.json` - Detailed generation report

## Advanced Features

### Dry Run Mode

Test without generating files:
1. Enable "Dry Run" toggle
2. Click Generate
3. Review results in validation panel

### Validation Mode

Check data integrity before generation:
1. Click "Validate" button
2. Review match rate and issues
3. Fix any problems found
4. Generate when ready

### Custom Matchers

Define custom matching logic in `config.json`:

```json
{
  "customMatchers": {
    "myMatcher": "function(product, images) { /* your logic */ }"
  }
}
```

## Best Practices

1. **Always validate before generating**
2. **Start with dry-run mode for testing**
3. **Use descriptive image filenames**
4. **Maintain consistent naming conventions**
5. **Regularly update image mappings**
6. **Monitor match rates over time**
7. **Keep brand themes up to date**

## Development

```bash
# Start development server
bun run dev

# Run linting
bun run lint

# Build for production
bun run build

# Start production server
bun run start
```

## Support

For issues or questions:
- Check the validation results
- Review the generated report
- Consult the troubleshooting section
- Review the API documentation

## License

This project is part of the Z.ai Code Scaffold.
