'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  FileText, 
  Download, 
  RefreshCw, 
  CheckCircle2, 
  AlertCircle, 
  Clock, 
  FileImage,
  Settings,
  Sparkles,
  Zap 
} from 'lucide-react';
import { toast } from 'sonner';

// Types
interface GenerationConfig {
  format: 'html' | 'pdf' | 'both';
  parallel: boolean;
  workers: number;
  force: boolean;
  dryRun: boolean;
  matchThreshold: number;
  minSize: number;
  maxSize: number;
}

interface GenerationStatus {
  totalProducts: number;
  matchRate: string;
  htmlGenerated: boolean;
  pdfGenerated: boolean;
  sectionCount: number;
  pdfCount: number;
  lastGenerated: string | null;
  files: Array<{
    name: string;
    size: number;
    modified: string;
    type: string;
  }>;
}

interface ValidationResult {
  totalProducts: number;
  matched: number;
  notFound: number;
  matchRate: string;
  byMethod: Record<string, number>;
  perBrand: Record<string, {
    total: number;
    matched: number;
    notFound: number;
  }>;
  issues: Array<{
    id: string;
    brand: string;
    name: string;
    issue: string;
  }>;
}

export default function CatalogueBuilder() {
  const [config, setConfig] = useState<GenerationConfig>({
    format: 'both',
    parallel: true,
    workers: 4,
    force: false,
    dryRun: false,
    matchThreshold: 0.85,
    minSize: 10000,
    maxSize: 50000000,
  });

  const [isGenerating, setIsGenerating] = useState(false);
  const [isValidating, setIsValidating] = useState(false);
  const [progress, setProgress] = useState(0);
  const [status, setStatus] = useState<GenerationStatus | null>(null);
  const [validationResult, setValidationResult] = useState<ValidationResult | null>(null);

  // Load status on mount
  useEffect(() => {
    loadStatus();
  }, []);

  const loadStatus = async () => {
    try {
      const response = await fetch('/api/catalogue/status');
      const data = await response.json();
      if (data.success) {
        setStatus(data.status);
      }
    } catch (error) {
      console.error('Failed to load status:', error);
      toast.error('Failed to load catalogue status');
    }
  };

  const handleValidate = async () => {
    setIsValidating(true);
    toast.info('Validating catalogue data...', {
      icon: <Clock className="w-4 h-4" />,
    });

    try {
      const response = await fetch('/api/catalogue/validate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          matchThreshold: config.matchThreshold,
          minSize: config.minSize,
          maxSize: config.maxSize,
        }),
      });

      const data = await response.json();

      if (data.success) {
        setValidationResult(data.validation);
        const rate = parseFloat(data.validation.matchRate);

        if (rate >= 90) {
          toast.success(`Validation complete! ${data.validation.matchRate} match rate`, {
            icon: <CheckCircle2 className="w-4 h-4 text-green-500" />,
          });
        } else if (rate >= 70) {
          toast.warning(`Validation complete: ${data.validation.matchRate} match rate`, {
            icon: <AlertCircle className="w-4 h-4 text-yellow-500" />,
          });
        } else {
          toast.error(`Validation complete: ${data.validation.matchRate} match rate`, {
            icon: <AlertCircle className="w-4 h-4 text-red-500" />,
          });
        }
      } else {
        toast.error(data.error || 'Validation failed');
      }
    } catch (error) {
      console.error('Validation error:', error);
      toast.error('Failed to validate catalogue');
    } finally {
      setIsValidating(false);
    }
  };

  const handleGenerate = async () => {
    if (config.dryRun) {
      toast.info('Running in dry-run mode - no files will be generated', {
        icon: <Sparkles className="w-4 h-4" />,
      });
    }

    setIsGenerating(true);
    setProgress(0);

    try {
      const response = await fetch('/api/catalogue/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(config),
      });

      const data = await response.json();

      if (data.success) {
        toast.success('Catalogue generated successfully!', {
          icon: <CheckCircle2 className="w-4 h-4 text-green-500" />,
        });
        setStatus(data.output);
        await loadStatus();
      } else {
        toast.error(data.error || 'Generation failed');
        setProgress(0);
      }
      } catch (error) {
        console.error('Generation error:', error);
        toast.error('Failed to generate catalogue');
        setProgress(0);
        setIsGenerating(false);
      }
  };

  const handleDownload = (filename: string) => {
    window.open(`/api/catalogue/download/${filename}`, '_blank');
    toast.success(`Downloading ${filename}`);
  };

  const handleDownloadPDF = () => {
    handleDownload('catalogue_full.pdf');
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  return `${(bytes / (1024 * 1024 * 1024)).toFixed(2)} GB`;
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('fr-FR', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const formatMatchRate = (rate: string) => {
    const rateValue = parseFloat(rate);
    if (rateValue >= 90) return { text: rate, variant: 'success', color: 'text-green-600', bg: 'bg-green-50' };
    if (rateValue >= 70) return { text: rate, variant: 'default', color: 'text-yellow-600', bg: 'bg-yellow-50' };
    if (rateValue >= 50) return { text: rate, variant: 'warning', color: 'text-orange-600', bg: 'bg-orange-50' };
    return { text: rate, variant: 'destructive', color: 'text-red-600', bg: 'bg-red-50' };
  };

  return (
    <div style={{
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      minHeight: '100vh',
      gap: '2rem',
      padding: '1rem',
      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 50%, #f093fb 100%)'
    }}>
      {/* Header */}
      <div style={{
        position: 'relative',
        width: '6rem',
        height: '6rem',
        marginBottom: '2rem'
      }}>
        <img
          src="/logo.svg"
          alt="Z.ai Logo"
          style={{
            width: '100%',
            height: '100%',
            objectFit: 'contain'
          }}
        />
      </div>

      <div style={{
        position: 'relative',
        textAlign: 'center',
        maxWidth: '800px',
        zIndex: 1
      }}>
        <h1 style={{
          fontSize: '56px',
          fontWeight: 800,
          margin: '0 0 20px 0',
          letterSpacing: '-1px',
          textShadow: '0 4px 12px rgba(0,0,0,0.2)',
          color: '#ffffff'
        }}>
          PDF Catalogue Builder
        </h1>
        <p style={{
          fontSize: '18px',
          fontWeight: '400',
          margin: '0',
          opacity: 0.95
        }}>
          Advanced catalogue generation with intelligent image matching
        </p>
      </div>

      <Tabs defaultValue="generate" className="space-y-6">
        <TabsList className="grid w-full max-w-4xl grid-cols-2 gap-2">
          <TabsTrigger value="generate" className="gap-2">
            <Sparkles className="w-4 h-4" />
            Generate
          </TabsTrigger>
          <TabsTrigger value="status" className="gap-2">
            <FileText className="w-4 h-4" />
            Status & Files
          </TabsTrigger>
        </TabsList>

        {/* Generate Tab */}
        <TabsContent value="generate" className="space-y-6">
          <div className="container mx-auto px-4 py-8 max-w-7xl">
            <div className="grid lg:grid-cols-3 gap-6">
              {/* Configuration Panel */}
              <Card className="lg:col-span-2">
                <CardHeader>
                  <CardTitle>Configuration</CardTitle>
                  <CardDescription>
                    Customize your catalogue generation settings for optimal results.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Output Format */}
                  <div className="space-y-4">
                    <label className="text-sm font-medium">Output Format</label>
                    <div className="flex gap-2">
                      {(['html', 'pdf', 'both'] as const fmt).map((fmt) => (
                        <Button
                          key={fmt}
                          variant={config.format === fmt ? 'default' : 'outline'}
                          onClick={() => setConfig({ ...config, format: fmt })}
                          className="flex-1"
                        >
                          {fmt.toUpperCase()}
                        </Button>
                      ))}
                    </div>
                  </div>

                  {/* Performance Settings */}
                  <div className="space-y-4">
                    <label className="text-sm font-medium">Performance</label>
                    <div className="space-y-4">
                      <div className="flex items-center gap-2">
                        <Switch
                          checked={config.parallel}
                          onCheckedChange={(checked) => setConfig({ ...config, parallel: checked })}
                        />
                        <span className="text-sm">Parallel Processing</span>
                      </div>
                      {config.parallel && (
                        <div className="flex items-center gap-2">
                          <label className="text-sm font-medium mr-4">Workers</label>
                          <Slider
                            value={[config.workers]}
                            onValueChange={([value]) => setConfig({ ...config, workers: value[0] })}
                            min={1}
                            max={16}
                            step={1}
                            className="flex-1"
                          />
                          <Badge variant="secondary">{config.workers}</Badge>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Image Matching */}
                  <div className="space-y-4">
                    <label className="text-sm font-medium">Image Matching</label>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <label className="text-sm font-medium">Match Threshold</label>
                        <Badge variant="secondary">{(config.matchThreshold * 100).toFixed(0)}%</Badge>
                      </div>
                      <Slider
                        value={[config.matchThreshold]}
                        onValueChange={([value]) => setConfig({ ...config, matchThreshold: value[0] })}
                        min={0.5}
                        max={1}
                        step={0.05}
                        className="flex-1"
                      />
                    </div>
                    <p className="text-xs text-slate-500">
                      Higher threshold = stricter matching, fewer false positives.
                      Lower threshold = more matches, but potentially more errors.
                    </p>
                  </div>

                  {/* Image Size Limits */}
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Image Size Limits</label>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="text-sm font-medium mr-2">Min Size</label>
                          <input
                            type="number"
                            value={config.minSize}
                            onChange={(e) => setConfig({ ...config, minSize: parseInt(e.target.value) })}
                            className="w-full px-3 py-2 text-sm border rounded-md"
                            placeholder="10000"
                          />
                        </div>
                        <div>
                          <label className="text-sm font-medium ml-2">Max Size (bytes)</label>
                          <input
                            type="number"
                            value={config.maxSize}
                            onChange={(e) => setConfig({ ...config, maxSize: parseInt(e.target.value) })}
                            className="w-full px-3 py-2 text-sm border rounded-md"
                            placeholder="50000000"
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Options */}
                  <div className="space-y-4">
                    <div className="flex gap-4">
                      <div className="flex items-center gap-2">
                        <Switch
                          checked={config.force}
                          onCheckedChange={(checked) => setConfig({ ...config, force: checked })}
                        />
                        <span className="text-sm font-medium">Force Regenerate</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Switch
                          checked={config.dryRun}
                          onCheckedChange={(checked) => setConfig({ ...config, dryRun: checked })}
                        />
                        <span className="text-sm font-medium">Dry Run (validate only)</span>
                      </div>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="space-y-6">
                    <Button
                      onClick={handleValidate}
                      disabled={isValidating || isGenerating}
                      className="w-full"
                      variant="outline"
                    >
                      <RefreshCw className={`w-4 h-4 mr-2 ${isValidating ? 'animate-spin' : ''}`} />
                      Validate
                    </Button>

                    <Button
                      onClick={handleGenerate}
                      disabled={isGenerating || isValidating}
                      className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700"
                      size="lg"
                    >
                      <Sparkles className={`w-4 h-4 mr-2 ${isGenerating ? 'animate-pulse' : ''}`} />
                      Generate Catalogue
                    </Button>

                    {progress > 0 && (
                      <div className="space-y-4">
                        <Progress value={progress} className="w-full h-2" />
                        <p className="text-center text-sm text-slate-500">
                          {progress < 100 ? 'Generating...' : 'Complete!'}
                        </p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Validation Results */}
              {validationResult && (
                <Card className="lg:col-span-1">
                  <CardHeader>
                    <CardTitle>Validation Results</CardTitle>
                    <CardDescription>
                      Review your catalogue data before generating.
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-4">
                      <div className="flex items-center justify-between text-sm mb-2">
                        <Badge variant={formatMatchRate(validationResult.matchRate).variant}>
                          {formatMatchRate(validationResult.matchRate).text}
                        </Badge>
                      </div>
                      <div className="text-slate-500">
                        {validationResult.totalProducts} products
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4 mb-6">
                      <div>
                        <div className="text-sm font-medium text-slate-500">Matched</div>
                        <div className="text-2xl font-bold text-slate-900">
                          {validationResult.matched}
                        </div>
                      </div>
                      <div>
                        <div className="text-sm text-slate-500">Not Found</div>
                        <div className="text-2xl font-bold text-slate-900">
                          {validationResult.notFound}
                        </div>
                      </div>

                    <div className="border-t pt-4 mt-4">
                      <h3 className="text-sm font-medium mb-3">Match Method Distribution</h3>
                      <div className="space-y-2">
                        {Object.entries(validationResult.byMethod).map(([method, count]) => (
                          <div key={method} className="flex items-center justify-between text-sm py-2">
                            <span className="text-slate-500 w-2/3">{method}</span>
                            <div className="flex-1">
                              <Badge variant="outline">{count}</Badge>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    {validationResult.issues.length > 0 && (
                      <Alert>
                        <AlertCircle className="h-4 w-4 text-red-500" />
                        <AlertDescription>
                          Found {validationResult.issues.length} products with missing or mismatched images.
                        </AlertDescription>
                        <div className="max-h-48 overflow-y-auto space-y-2">
                          {validationResult.issues.slice(0, 10).map((issue, idx) => (
                            <div key={idx} className="p-3 bg-slate-50 rounded-lg">
                              <div className="flex items-center gap-2 mb-2">
                                <Badge variant="outline" className="text-xs">?</Badge>
                                <span className="text-sm text-slate-500">[{issue.id}] {issue.brand}</span>
                                <span className="text-sm text-slate-500">{issue.name}</span>
                              </div>
                              <div className="text-sm text-red-600 ml-2">
                                {issue.issue}
                              </div>
                            </div>
                          ))}
                          {validationResult.issues.length > 10 && (
                            <div className="text-center text-sm text-slate-500 mt-2">
                              Showing 10 of {validationResult.issues.length} issues
                            </div>
                          )}
                        </div>
                      </Alert>
                    )}
                  </CardContent>
                </Card>
              )}
            </div>

            {/* Help Panel */}
            <Card className="lg:col-span-1">
              <CardHeader>
                <CardTitle>How to Improve Image Matching</CardTitle>
                <CardDescription>
                  Get better match rates by following these guidelines.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <h3 className="text-sm font-medium mb-2">Image Naming Conventions</h3>
                  <p className="text-sm text-slate-600 mb-2">
                    <strong>Best:</strong> PRODUCT-ID.jpg (exact ID match)
                  </p>
                  <p className="text-sm text-slate-600 mb-1">
                    <code>PRODUCT-001.jpg</code> - Highest priority, 100% match rate
                  </p>
                  <p className="text-sm text-slate-500 mb-4">
                    <strong>Good:</strong> brand-product-name.jpg
                  </p>
                  <p className="text-sm text-slate-600 mb-1">
                    <code>ikea-bureau-flaxa.jpg</code> - High accuracy, 85-95% match rate
                  </p>
                  <p className="text-sm text-slate-500 mb-1">
                    <strong>Acceptable:</strong> product-name.jpg
                  </p>
                  <p className="text-sm text-slate-600 mb-1">
                    <code>bureau-flaxa.jpg</code> - Still good accuracy, 70-80% match rate
                  </p>
                  <p className="text-xs text-slate-400">
                    Uses slugified names, handles special characters, easy to remember.
                  </p>
                  </div>

                  <h3 className="text-sm font-medium mb-2">Image Size Guidelines</h3>
                  <p className="text-sm text-slate-600 mb-2">
                    <strong>Recommended:</strong> 5KB - 10MB
                  </p>
                  <p className="text-sm text-slate-600 mb-1">
                    Images below 5KB may appear pixelated
                  </p>
                  <p className="text-sm text-slate-500 mb-4">
                    Images above 10MB may slow down loading
                  </p>
                  </div>

                  <h3 className="text-sm font-medium mb-2">Tips for Better Results</h3>
                  <p className="text-sm text-square-600 mb-2">
                    1. Create <code class="image_map.json"</code> for tricky cases
                  </p>
                  <p className="text-sm text-slate-500 mb-4">
                    Manually map product IDs to image paths for critical products.
                  </p>
                  </p>
                  <p className="text-sm text-slate-500 mb-1">
                    Example:
                  </p>
                  <pre className="bg-slate-900 text-green-400 p-4 rounded-md overflow-x-auto text-xs">{`{
  "PRODUCT-001": "/path/to/image.jpg",
  "PRODUCT-002": "/path/to/image.jpg"
}`}</pre>
                  </p>

                  <p className="text-sm text-slate-500 mb-4">
                    2. Organize by brand folders
                  </p>
                  <p className="text-sm text-slate-500 mb-1">
                    <code>catalogue/images_photos/brand/product.jpg</code>
                  </p>
                  <p className="text-xs text-slate-400">
                    Grouping by brand improves automatic detection.
                  </p>
                  </p>

                  <p className="text-sm text-slate-500 mb-4">
                    <strong>3. Use consistent file extensions</strong>
                  </p>
                  <p className="text-sm text-slate-600 mb-2">
                    <strong>Best:</strong> .jpg (most common, best compression)
                  </p>
                  <p className="text-sm text-slate-500 mb-1">
                    <strong>Good:</strong> .png (quality, transparency)
                  </p>
                  <p className="text-sm text-slate-500 mb-1">
                    <strong>Acceptable:</strong> .webp (modern, efficient)
                  </p>
                  </p>
                  </div>

                  <h3 className="text-sm font-medium mb-4">Image Matching Strategies</h3>
                  <p className="text-sm text-slate-600 mb-2">
                    The system uses 7 matching strategies in order:
                  </p>
                  <ol className="list-decimal list-inside text-sm space-y-2 text-slate-700">
                    <li>
                      <strong>1. Manual Map</strong> - Highest priority, from <code>image_map.json</code>
                    </li>
                    <li>
                      <strong>2. Exact ID Match</strong> - <code>PRODUCT-ID.jpg</code> - Best accuracy
                    </li>
                    <li>
                      <strong>3. Brand-Name Match</strong> - <code>brand-product-name.jpg</code>
                    </li>
                    <li>
                      <strong>4. Slugified Name</strong> - <code>product-name.jpg</code> (85-95% match)
                    </li>
                    <li>
                      <strong>5. Pattern Match</strong> - Finds files matching patterns
                    </li>
                    <li>
                      <strong>6. Fuzzy Match</strong> - Uses similarity scoring (based on threshold)
                    </li>
                    <li>
                      <strong>7. Auto Assignment</strong> - Round-robin fallback
                    </li>
                  </ol>
                  </div>

                  <h3 className="text-sm font-medium mb-4">Match Threshold Guide</h3>
                  <div className="bg-slate-900 text-green-400 p-4 rounded-lg">
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <Badge variant="success">0.90+</Badge>
                        <span className="text-sm text-green-700 font-medium">Very strict - fewer false positives</span>
                      </div>
                      <div className="text-xs text-slate-400">
                        Use for catalogs with well-organized images. Best for professional use.
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <Badge variant="warning">0.70-0.89</Badge>
                        <span className="text-sm text-yellow-600 font-medium">Good balance - recommended</span>
                      </div>
                      <div className="text-xs text-slate-400">
                        Default setting. Good mix of accuracy and coverage.
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <Badge variant="destructive">0.50-0.69</Badge>
                        <span className="text-sm text-red-600 font-medium">Permissive - more matches</span>
                      </div>
                      <div className="text-xs text-slate-400">
                        Use for messy image directories with inconsistent naming.
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <Badge variant="outline">Below 0.50</Badge>
                        <span className="text-s text-slate-400">Very strict - may miss many</span>
                      </div>
                  </div>

                  <p className="text-sm text-slate-500 mt-4">
                    <strong>Tip:</strong> Start with a higher threshold (0.85-0.90), 
                    review unmatched products, then lower if needed.
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Tips Card */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Tips</CardTitle>
                  <CardDescription>
                  Get better results quickly.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="text-sm text-slate-600">
                    <div className="flex items-start gap-2 mb-2">
                      <CheckCircle2 className="w-4 h-4 text-green-500" />
                      <span>Always run <strong>Validate</strong> before generating</span>
                    </div>
                    <div className="flex items-start gap-2 mb-2">
                      <CheckCircle2 className="w-4 h-4 text-green-500" />
                      <span>Review the <strong>image discovery report</strong></span>
                    </div>
                    <div className="flex items-start gap-2 mb-2">
                      <CheckCircle2 className="w-4 h-4 text-green-500" />
                      <span>Follow <strong>naming conventions</strong></span>
                    </div>
                    <div className="flex items-start gap-2 mb-2">
                      <CheckCircle2 className="w-4 h-4 text-green-500" />
                      <span>Create <strong>manual image mappings</strong> for critical products</span>
                    </div>
                  </div>

                  <div className="border-t pt-4 mt-4">
                    <h3 className="text-sm font-medium mb-3">Common Issues & Solutions</h3>
                    <div className="space-y-3">
                      <div className="flex items-start gap-2 mb-3">
                        <AlertCircle className="w-4 h-4 text-red-500" />
                        <span className="text-sm font-medium">No images found</span>
                        <p className="text-sm text-slate-500 mt-1">
                          <strong>Cause:</strong> Images not in <code>images_photos/</code> directory
                        </p>
                        <p className="text-sm text-slate-400 mt-1">
                          <strong>Solution:</strong> Place images in <code>catalogue/images_photos/</code>
                        </p>
                      </div>

                      <div className="flex items-start gap-2 mb-3">
                        <AlertCircle className="w-4 h-4 text-red-500" />
                        <span className="text-sm font-medium">Low match rate</span>
                        <p className="text-sm text-slate-500 mt-1">
                          <strong>Cause:</strong> Images don't match naming conventions
                        </p>
                        <p className="text-sm text-slate-400 mt-1">
                          <strong>Solution:</strong> Review naming guide, rename images, or adjust match threshold
                        </p>
                      </div>

                      <div className="flex items-start gap-2 mb-3">
                        <AlertCircle className="w-w h-4 text-green-500" />
                        <span className="text-sm font-medium">All placeholders</span>
                        <p className="text-sm text-slate-500 mt-1">
                          <strong>Cause:</strong> No images found at all
                        </p>
                        <p className="text-sm text-slate-400 mt-1">
                          <strong>Solution:</strong> Add images to <code>images_photos/</code> directory
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        {/* Status & Files Tab */}
        <TabsContent value="status" className="space-y-6">
          <div className="container mx-auto px-4 py-8 max-w-7xl">
            {!status ? (
              <Card>
                <CardContent>
                  <div className="flex flex-col items-center justify-center py-12">
                    <FileText className="w-12 h-12 text-slate-400" />
                    <p className="text-center text-slate-500 mt-4">
                      No catalogue generated yet
                    </p>
                    <p className="text-center text-sm text-slate-400 mt-1">
                      Use the Generate tab to create your first catalogue
                    </p>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <div className="grid lg:grid-cols-4 gap-4">
                {/* Overview Stats */}
                <Card className="lg:col-span-4">
                  <CardContent className="text-center">
                    <FileImage className="w-8 h-8 text-blue-500" />
                    <div className="text-lg font-bold text-slate-900 mb-2">Total Products</div>
                    <div className="text-3xl font-bold text-slate-900">{status.totalProducts}</div>
                    <div className="text-sm text-slate-500">
                      {status.lastGenerated ? `Generated: ${formatDate(status.lastGenerated)}` : 'Not yet'}
                    </div>
                  </CardContent>
                </Card>

                <Card className="lg:col-span-2">
                  <CardContent className="text-center">
                    <RefreshCw className="w-5 h-5 text-slate-400" />
                    <div className="text-sm font-medium text-slate-600">Match Rate</div>
                    <div className={`text-3xl font-bold ${formatMatchRate(status.matchRate).color}`}>
                      {status.matchRate}
                    </div>
                    <Badge variant={formatMatchRate(status.matchRate).variant}>
                      {formatMatchRate(status.matchRate).text}
                    </Badge>
                  </CardContent>
                </Card>

                <Card className="lg:col-span-2">
                  <CardContent className="text-center">
                    <Download className="w-6 h-6 text-slate-400" />
                    <div className="text-lg font-bold text-slate-900 mb-2">Files Generated</div>
                    <div className={`text-3xl font-bold text-slate-900 ${status.sectionCount} sections`}</div>
                  </CardContent>
                </Card>

                {/* Download Actions */}
                <Card>
                  <CardHeader>
                    <CardTitle>Download Catalogue</CardTitle>
                      <CardDescription>
                        Download the generated catalogue files.
                      </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {status.htmlGenerated && (
                      <div className="space-y-4">
                        <Button
                          onClick={() => handleDownload('catalogue_full.html')}
                          className="w-full"
                          variant="outline"
                        >
                          <Download className="w-4 h-4 mr-2" />
                          HTML Catalogue
                        </Button>
                      </div>
                    )}

                    {status.pdfGenerated && (
                      <div className="space-y-4">
                        <Button
                          onClick={handleDownloadPDF}
                          className="w-full"
                          variant="outline"
                        >
                          <Download className="w-4 h-4 mr-2" />
                          PDF Catalogue
                        </Button>
                      </div>
                    )}

                    {!status.pdfGenerated && (
                      <div className="space-y-4">
                        <div className="text-sm text-slate-400">
                          <Download className="w-4 h-4 mr-2" />
                          <span className="text-slate-400">PDF not generated yet</span>
                          <p className="text-xs text-slate-400 mt-1">
                            Enable PDF generation by installing Edge browser or generate HTML and print to PDF
                          </p>
                        </div>
                      </div>
                    )}

                    <div className="border-t pt-4 mt-4">
                      <h3 className="text-sm font-medium mb-3">Download Instructions</h3>
                      <p className="text-sm text-slate-600 mb-2">
                        Click the download button to open the file in a new tab. Then:
                      </p>
                      <ol className="list-decimal list-inside text-sm text-slate-700 space-y-2">
                        <li>
                          Press <strong>Cmd/Ctrl + P</strong> or <strong>Command + P</strong>
                        </li>
                        <li>
                          Select <strong>"Save as PDF"</strong> or <strong>"Save as HTML"</strong>
                        </li>
                        <li>
                          Choose <strong>"More settings"</strong> to access quality and layout options
                        </li>
                        <li>
                          Click <strong>"Print"</strong> to preview
                        </li>
                      </ol>
                    </div>
                  </CardContent>
                </Card>

                {/* Generated Files */}
                <Card className="lg:col-span-4">
                  <CardHeader>
                    <CardTitle>Generated Files</CardTitle>
                      <CardDescription>
                        All files generated by the catalogue system.
                      </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {!status || status.files.length === 0 ? (
                      <CardContent>
                        <div className="flex flex-col items-center justify-center py-12">
                          <Download className="w-8 h-8 text-slate-400" />
                          <p className="text-center text-slate-500 mt-4">
                            No files generated yet
                          </p>
                          <p className="text-center text-sm text-slate-400 mt-1">
                              Generate your first catalogue to see files here
                          </p>
                        </div>
                      </CardContent>
                    ) : (
                      <div className="space-y-4">
                        {status.files
                          .filter(f => f.type !== 'directory')
                          .slice(0, 20)
                          .map((file, idx) => (
                            <div key={idx} className="group">
                              <div
                                onClick={() => handleDownload(file.name)}
                                className="flex items-center justify-between p-3 bg-slate-50 hover:bg-slate-100 rounded-lg cursor-pointer transition-colors border border-slate-200 hover:border-slate-300 hover:bg-slate-50 hover:text-slate-900 transition-all duration-200"
                              >
                                <div className="flex items-center gap-3">
                                  {file.type === '.pdf' ? (
                                    <Download className="w-4 h-4 text-red-500" />
                                  ) : (
                                    <FileImage className="w-4 h-4 text-blue-500" />
                                  )}
                                  <div className="text-sm text-slate-600 font-medium">
                                    {file.name}
                                  </div>
                                </div>
                                <div className="text-right text-xs text-slate-400">
                                  {formatFileSize(file.size)}
                                </div>
                              </div>
                            </div>
                          ))}
                      </div>

                      {status.files.filter(f => f.type !== 'directory').length > 20 && (
                        <div className="text-center mt-4">
                          <Button
                            onClick={() => handleDownload('catalogue_full.html')}
                            variant="outline"
                            size="sm"
                          >
                            View All Files ({status.files.length})
                          </Button>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </TabsContent>
      </div>

      {/* Footer */}
      <div className="mt-auto py-6 border-t bg-white/50 dark:bg-slate-950">
        <div className="container mx-auto px-4 py-8 max-w-7xl">
          <div className="flex flex-col items-center justify-between gap-4 text-sm">
            <p className="text-slate-500">
              © 2026 Atlas Fournitures — Catalogue Professionnel
            </p>
            <p className="text-slate-400">
              Built with Next.js, TypeScript, and shadcn/ui
            </p>
            <div className="flex items-center gap-4">
              <a href="/api/catalogue" className="text-slate-400 hover:text-blue-500 hover:underline">
                API Documentation
              </a>
              <a href="/api/catalogue/download/catalogue_full.html" className="text-slate-400 hover:text-blue-500 hover:underline">
                Download Latest Catalogue
              </a>
            </div>
          </div>
        </div>
      </div>
  );
}
