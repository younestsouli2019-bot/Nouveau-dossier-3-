import { NextRequest, NextResponse } from "next/server";
import { exec } from "child_process";
import { promisify } from "util";
import path from "path";
import fs from "fs";

const execAsync = promisify(exec);

export async function POST(request: NextRequest) {
  try {
    const scriptPath = path.join(process.cwd(), 'upload', 'enhanced_catalogue_generator_v4.js');
    
    if (!fs.existsSync(scriptPath)) {
      return NextResponse.json(
        { error: "Enhanced catalogue generator not found" },
        { status: 404 }
      );
    }

    // Execute enhanced catalogue generator
    const { stdout, stderr } = await execAsync(`bun ${scriptPath}`, {
      cwd: process.cwd(),
      maxBuffer: 10 * 1024 * 1024, // 10MB buffer
    });

    const output = JSON.parse(stdout.trim());

    if (!output.ok) {
      return NextResponse.json(
        { error: output.error || "Catalogue generation failed", stderr },
        { status: 500 }
      );
    }

    // Check for generated files
    const cataloguePath = path.join(process.cwd(), 'catalogue', 'catalogue_full.html');
    const exists = fs.existsSync(cataloguePath);

    return NextResponse.json({
      success: true,
      output: {
        htmlGenerated: exists,
        path: '/api/catalogue/download/catalogue_full.html',
        timestamp: new Date().toISOString()
      },
      discovery: output.discovery,
      recommendations: output.recommendations || [],
      timestamp: new Date().toISOString()
    });

  } catch (error: any) {
    console.error('Catalogue generation error:', error);
    return NextResponse.json(
      { 
        error: "Failed to generate catalogue",
        details: error.message,
        stderr: error.stderr
      },
      { status: 500 }
    );
  }
}

export async function GET() {
  return NextResponse.json({
    endpoint: '/api/catalogue/generate',
    method: 'POST',
    description: 'Generate professional catalogue with advanced image discovery',
    features: [
      '✓ 7 image discovery strategies',
      '✓ Professional e-commerce style layout',
      '✓ Responsive design',
      '✓ Print-optimized',
      '✓ Image discovery report',
      '✓ Recommendations for improvement',
      '✓ Product cards with pricing',
      '✓ Brand-based organization',
      '✓ Professional typography'
    ],
    howToUse: {
      step1: 'Place product images in catalogue/images_photos/',
      step2: 'Name images: PRODUCT-ID.jpg or brand-product-name.jpg',
      'step3: 'Click "Generate Catalogue" button',
      step4: 'Review image discovery report',
      step5: 'Download generated catalogue'
    },
    imageNaming: {
      exactId: 'PRODUCT-ID.jpg (best option)',
      brandName: 'brand-product-name.jpg',
      slugified: 'product-name.jpg'
    },
    troubleshooting: {
      noImages: 'Check that images are in the correct directory',
      wrongNames: 'Follow naming conventions shown above',
      formatIssues: 'Use JPG, PNG, or WebP formats',
      sizeIssues: 'Images should be between 5KB and 10MB'
    }
  });
}
