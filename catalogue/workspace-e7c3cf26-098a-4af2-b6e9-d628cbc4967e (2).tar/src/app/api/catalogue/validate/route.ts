import { NextRequest, NextResponse } from "next/server";
import { exec } from "child_process";
import { promisify } from "util";
import path from "path";
import fs from "fs";

const execAsync = promisify(exec);

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      matchThreshold = 0.85,
      minSize = 10000,
      maxSize = 50000000,
    } = body;

    // Build command arguments for validation
    const args: string[] = [
      '--validate',
      '--match-threshold', String(matchThreshold),
      '--min-size', String(minSize),
      '--max-size', String(maxSize),
      '--report', 'validation-report.json'
    ];

    const scriptPath = path.join(process.cwd(), 'upload', 'final_style_catalogue_improved_v2.js');
    
    if (!fs.existsSync(scriptPath)) {
      return NextResponse.json(
        { error: "Catalogue generator script not found" },
        { status: 404 }
      );
    }

    // Execute the catalogue validator
    const { stdout, stderr } = await execAsync(`bun ${scriptPath} ${args.join(' ')}`, {
      cwd: process.cwd(),
      maxBuffer: 10 * 1024 * 1024,
    });

    // Read validation report
    const reportPath = path.join(process.cwd(), 'catalogue', 'validation-report.json');
    let report = null;
    if (fs.existsSync(reportPath)) {
      report = JSON.parse(fs.readFileSync(reportPath, 'utf-8'));
    }

    return NextResponse.json({
      success: true,
      validation: {
        totalProducts: report?.totalProducts || 0,
        matched: report?.matched || 0,
        notFound: report?.notFound || 0,
        matchRate: report?.matchRate || '0%',
        byMethod: report?.byMethod || {},
        perBrand: report?.perBrand || {},
        issues: report?.issues || [],
      },
      timestamp: new Date().toISOString(),
    });

  } catch (error: any) {
    console.error('Validation error:', error);
    return NextResponse.json(
      { 
        error: "Failed to validate catalogue",
        details: error.message,
        stderr: error.stderr
      },
      { status: 500 }
    );
  }
}

export async function GET() {
  return NextResponse.json({
    endpoint: '/api/catalogue/validate',
    method: 'POST',
    description: 'Validate catalogue data and images before generation',
    parameters: {
      matchThreshold: { type: 'number', default: 0.85, min: 0, max: 1 },
      minSize: { type: 'number', default: 10000 },
      maxSize: { type: 'number', default: 50000000 },
    },
  });
}
