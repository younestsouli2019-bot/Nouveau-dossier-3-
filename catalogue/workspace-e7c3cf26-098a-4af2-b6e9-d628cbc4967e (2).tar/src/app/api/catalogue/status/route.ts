import { NextRequest, NextResponse } from "next/server";
import path from "path";
import fs from "fs";

export async function GET(request: NextRequest) {
  try {
    const catalogueDir = path.join(process.cwd(), 'catalogue');
    const reportPath = path.join(catalogueDir, 'report.json');
    
    // Check if catalogue exists
    const catalogueExists = fs.existsSync(catalogueDir);
    
    // List generated files
    let files: any[] = [];
    if (catalogueExists) {
      const entries = fs.readdirSync(catalogueDir, { withFileTypes: true });
      
      for (const entry of entries) {
        if (entry.isFile()) {
          const filePath = path.join(catalogueDir, entry.name);
          const stats = fs.statSync(filePath);
          files.push({
            name: entry.name,
            size: stats.size,
            modified: stats.mtime,
            type: path.extname(entry.name).toLowerCase(),
          });
        } else if (entry.isDirectory()) {
          const dirPath = path.join(catalogueDir, entry.name);
          const dirStats = fs.statSync(dirPath);
          const subEntries = fs.readdirSync(dirPath);
          files.push({
            name: entry.name,
            type: 'directory',
            size: dirStats.size,
            modified: dirStats.mtime,
            itemCount: subEntries.length,
          });
        }
      }
    }

    // Read report if available
    let report = null;
    if (fs.existsSync(reportPath)) {
      report = JSON.parse(fs.readFileSync(reportPath, 'utf-8'));
    }

    // Check for PDF and HTML files
    const fullHtmlExists = fs.existsSync(path.join(catalogueDir, 'catalogue_full.html'));
    const fullPdfExists = fs.existsSync(path.join(catalogueDir, 'catalogue_full.pdf'));
    
    const sectionsDir = path.join(catalogueDir, 'sections');
    const pdfsDir = path.join(catalogueDir, 'pdfs');
    
    const sections = fs.existsSync(sectionsDir) 
      ? fs.readdirSync(sectionsDir).filter(f => f.endsWith('.html')).length 
      : 0;
    
    const pdfs = fs.existsSync(pdfsDir) 
      ? fs.readdirSync(pdfsDir).filter(f => f.endsWith('.pdf')).length 
      : 0;

    return NextResponse.json({
      success: true,
      status: {
        catalogueExists,
        lastGenerated: report?.performance?.endTime || null,
        totalProducts: report?.totalProducts || 0,
        matchRate: report?.matchRate || '0%',
        htmlGenerated: fullHtmlExists,
        pdfGenerated: fullPdfExists,
        sectionCount: sections,
        pdfCount: pdfs,
        files,
      },
      report,
      timestamp: new Date().toISOString(),
    });

  } catch (error: any) {
    console.error('Status check error:', error);
    return NextResponse.json(
      { 
        error: "Failed to get catalogue status",
        details: error.message
      },
      { status: 500 }
    );
  }
}
