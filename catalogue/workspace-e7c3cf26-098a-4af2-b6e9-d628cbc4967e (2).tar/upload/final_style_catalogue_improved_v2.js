#!/usr/bin/env node

/**
 * Advanced PDF Catalogue Generator
 * 
 * Features:
 * - Intelligent image matching (exact, fuzzy, ML-assisted)
 * - Caching for performance
 * - Parallel PDF generation
 * - Image quality validation
 * - CLI argument parsing
 * - Progress tracking
 * - Dry-run and validation modes
 * - Detailed statistics and reporting
 * - Error recovery and retry logic
 * - Multi-threaded image processing
 * 
 * Usage:
 *   node final_style_catalogue_improved_v2.js [options]
 * 
 * Options:
 *   --help, -h              Show help
 *   --verbose, -v           Verbose logging
 *   --debug                 Debug logging
 *   --quiet                 Only errors
 *   --dry-run               Validate without generating files
 *   --validate              Validate images and data
 *   --force                 Force regeneration (ignore cache)
 *   --parallel              Enable parallel PDF generation
 *   --no-pdf                Skip PDF generation
 *   --config FILE           Use custom config file
 *   --output DIR            Custom output directory
 *   --format FORMAT         Output format (html, pdf, both)
 *   --min-size SIZE         Minimum image size in bytes
 *   --max-size SIZE         Maximum image size in bytes
 *   --match-threshold NUM   Fuzzy match threshold (0.0-1.0)
 *   --cache-dir DIR         Custom cache directory
 *   --workers NUM           Number of parallel workers
 *   --report FILE           Generate report file
 *   --webhook URL           Send webhook on completion
 *   --notify EMAIL          Email notification on failure
 */

import fs from "node:fs";
import path from "node:path";
import { spawnSync, spawn } from "node:child_process";
import { fileURLToPath } from "node:url";
import { Worker, isMainThread, parentPort, workerData } from "node:worker_threads";
import crypto from "node:crypto";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// ============================================
// CLI ARGUMENT PARSER
// ============================================

function parseArgs() {
  const args = process.argv.slice(2);
  const options = {
    help: false,
    verbose: false,
    debug: false,
    quiet: false,
    dryRun: false,
    validate: false,
    force: false,
    parallel: false,
    noPdf: false,
    config: null,
    output: null,
    format: 'both',
    minSize: 10_000,
    maxSize: 50_000_000,
    matchThreshold: 0.85,
    cacheDir: null,
    workers: 4,
    report: null,
    webhook: null,
    notify: null,
    logLevel: 'info'
  };

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    const nextArg = args[i + 1];

    switch (arg) {
      case '--help':
      case '-h':
        options.help = true;
        break;
      case '--verbose':
      case '-v':
        options.verbose = true;
        options.logLevel = 'verbose';
        break;
      case '--debug':
        options.debug = true;
        options.logLevel = 'debug';
        break;
      case '--quiet':
        options.quiet = true;
        options.logLevel = 'error';
        break;
      case '--dry-run':
        options.dryRun = true;
        break;
      case '--validate':
        options.validate = true;
        break;
      case '--force':
        options.force = true;
        break;
      case '--parallel':
        options.parallel = true;
        break;
      case '--no-pdf':
        options.noPdf = true;
        break;
      case '--config':
        if (nextArg && !nextArg.startsWith('--')) {
          options.config = nextArg;
          i++;
        }
        break;
      case '--output':
        if (nextArg && !nextArg.startsWith('--')) {
          options.output = nextArg;
          i++;
        }
        break;
      case '--format':
        if (nextArg && !nextArg.startsWith('--')) {
          options.format = nextArg;
          i++;
        }
        break;
      case '--min-size':
        if (nextArg && !nextArg.startsWith('--')) {
          options.minSize = parseInt(nextArg);
          i++;
        }
        break;
      case '--max-size':
        if (nextArg && !nextArg.startsWith('--')) {
          options.maxSize = parseInt(nextArg);
          i++;
        }
        break;
      case '--match-threshold':
        if (nextArg && !nextArg.startsWith('--')) {
          options.matchThreshold = parseFloat(nextArg);
          i++;
        }
        break;
      case '--cache-dir':
        if (nextArg && !nextArg.startsWith('--')) {
          options.cacheDir = nextArg;
          i++;
        }
        break;
      case '--workers':
        if (nextArg && !nextArg.startsWith('--')) {
          options.workers = parseInt(nextArg);
          i++;
        }
        break;
      case '--report':
        if (nextArg && !nextArg.startsWith('--')) {
          options.report = nextArg;
          i++;
        }
        break;
      case '--webhook':
        if (nextArg && !nextArg.startsWith('--')) {
          options.webhook = nextArg;
          i++;
        }
        break;
      case '--notify':
        if (nextArg && !nextArg.startsWith('--')) {
          options.notify = nextArg;
          i++;
        }
        break;
    }
  }

  return options;
}

// Show help
function showHelp() {
  console.log(`
Advanced PDF Catalogue Generator
=================================

Usage:
  node final_style_catalogue_improved_v2.js [options]

Options:
  --help, -h              Show this help message
  --verbose, -v           Verbose logging (shows all operations)
  --debug                 Debug logging (includes detailed traces)
  --quiet                 Only show errors
  --dry-run               Validate without generating files
  --validate              Validate images and data only
  --force                 Force regeneration (ignore cache)
  --parallel              Enable parallel PDF generation
  --no-pdf                Skip PDF generation (HTML only)
  --config FILE           Use custom config file (JSON)
  --output DIR            Custom output directory
  --format FORMAT         Output format: html, pdf, or both (default: both)
  --min-size SIZE         Minimum image size in bytes (default: 10000)
  --max-size SIZE         Maximum image size in bytes (default: 50000000)
  --match-threshold NUM   Fuzzy match threshold 0.0-1.0 (default: 0.85)
  --cache-dir DIR         Custom cache directory
  --workers NUM           Number of parallel workers (default: 4)
  --report FILE           Generate detailed report file
  --webhook URL           Send webhook on completion
  --notify EMAIL          Email notification on failure

Examples:
  # Basic generation
  node final_style_catalogue_improved_v2.js

  # Verbose mode with parallel PDF generation
  node final_style_catalogue_improved_v2.js --verbose --parallel

  # Dry run to validate without generating
  node final_style_catalogue_improved_v2.js --dry-run

  # Generate only HTML with custom output
  node final_style_catalogue_improved_v2.js --format html --output ./output

  # Validate images with detailed report
  node final_style_catalogue_improved_v2.js --validate --report report.json

  # Force regeneration with 8 parallel workers
  node final_style_catalogue_improved_v2.js --force --parallel --workers 8

Environment Variables:
  LOG_LEVEL               Override log level (debug, verbose, info, warn, error)
  CACHE_DIR               Override cache directory
  OUTPUT_DIR              Override output directory

Config File Format (JSON):
{
  "logLevel": "info",
  "minImageSize": 10000,
  "maxImageSize": 50000000,
  "fuzzyMatchThreshold": 0.85,
  "parallelWorkers": 4,
  "allowedExtensions": [".jpg", ".jpeg", ".png", ".webp"],
  "customMatchers": {...}
}
`);
}

// ============================================
// CONFIGURATION
// ============================================

let cliOptions = parseArgs();

if (cliOptions.help) {
  showHelp();
  process.exit(0);
}

function loadConfig() {
  const configPath = cliOptions.config || 
    path.resolve(process.cwd(), "catalogue", "config.json");
  
  let userConfig = {};
  
  if (fs.existsSync(configPath)) {
    try {
      const content = fs.readFileSync(configPath, 'utf8');
      userConfig = JSON.parse(content);
    } catch (err) {
      logger.warn(`Failed to load config from ${configPath}:`, err.message);
    }
  }
  
  return {
    logLevel: cliOptions.logLevel || 
      userConfig.logLevel || 
      process.env.LOG_LEVEL || 
      'info',
    minImageSize: cliOptions.minSize || 
      userConfig.minImageSize || 
      10_000,
    maxImageSize: cliOptions.maxSize || 
      userConfig.maxImageSize || 
      50_000_000,
    allowedExtensions: userConfig.allowedExtensions || 
      [".jpg", ".jpeg", ".png", ".webp", ".avif", ".svg"],
    fuzzyMatchThreshold: cliOptions.matchThreshold !== undefined ? 
      cliOptions.matchThreshold : 
      (userConfig.fuzzyMatchThreshold || 0.85),
    parallelWorkers: cliOptions.workers || 
      userConfig.parallelWorkers || 
      4,
    cacheDir: cliOptions.cacheDir || 
      userConfig.cacheDir || 
      process.env.CACHE_DIR || 
      path.resolve(process.cwd(), ".cache", "catalogue"),
    outputDir: cliOptions.output || 
      userConfig.outputDir || 
      process.env.OUTPUT_DIR || 
      path.resolve(process.cwd(), "catalogue"),
    enableCache: !cliOptions.force && 
      (userConfig.enableCache !== false),
    enableParallel: cliOptions.parallel || 
      userConfig.enableParallel || 
      false,
    customMatchers: userConfig.customMatchers || {},
    imageQualityCheck: userConfig.imageQualityCheck !== false,
    duplicateDetection: userConfig.duplicateDetection !== false,
    autoOptimizeImages: userConfig.autoOptimizeImages || false,
    maxRetries: userConfig.maxRetries || 3,
    retryDelay: userConfig.retryDelay || 1000,
    webhook: cliOptions.webhook || userConfig.webhook || null,
    notify: cliOptions.notify || userConfig.notify || null,
    reportFile: cliOptions.report || userConfig.reportFile || null
  };
}

const CONFIG = loadConfig();

// ============================================
// ADVANCED LOGGER
// ============================================

const logger = {
  levels: { error: 0, warn: 1, info: 2, verbose: 3, debug: 4 },
  currentLevel: 2,

  setLevel(level) {
    this.currentLevel = this.levels[level] || this.levels.info;
  },

  log(level, ...args) {
    if (this.levels[level] <= this.currentLevel) {
      const timestamp = new Date().toISOString();
      const pid = process.pid;
      const prefix = `[${timestamp}] [${level.toUpperCase()}] [PID:${pid}]`;
      const message = args.join(' ');
      process.stderr.write(`${prefix} ${message}\n`);
    }
  },

  debug(...args) { this.log('debug', ...args); },
  verbose(...args) { this.log('verbose', ...args); },
  info(...args) { this.log('info', ...args); },
  warn(...args) { this.log('warn', ...args); },
  error(...args) { this.log('error', ...args); },
  
  progress(current, total, message = '') {
    if (this.currentLevel >= this.levels.info) {
      const percent = ((current / total) * 100).toFixed(1);
      const bar = '█'.repeat(Math.floor(percent / 2)).padEnd(50, ' ');
      process.stderr.write(`\r[${bar}] ${percent}% ${message}      `);
    }
  },
  
  clearProgress() {
    if (this.currentLevel >= this.levels.info) {
      process.stderr.write('\r' + ' '.repeat(100) + '\r');
    }
  }
};

logger.setLevel(CONFIG.logLevel);

// ============================================
// CACHING SYSTEM
// ============================================

class CacheManager {
  constructor(cacheDir) {
    this.cacheDir = cacheDir;
    this.enabled = CONFIG.enableCache;
    this.ensureCacheDir();
  }

  ensureCacheDir() {
    if (!this.enabled) return;
    try {
      fs.mkdirSync(this.cacheDir, { recursive: true });
    } catch (err) {
      logger.warn(`Failed to create cache directory: ${err.message}`);
      this.enabled = false;
    }
  }

  getCacheKey(data) {
    const hash = crypto.createHash('sha256');
    hash.update(JSON.stringify(data));
    return hash.digest('hex');
  }

  get(key, maxAge = 3600000) {
    if (!this.enabled) return null;
    
    try {
      const cacheFile = path.join(this.cacheDir, `${key}.json`);
      if (!fs.existsSync(cacheFile)) return null;
      
      const stats = fs.statSync(cacheFile);
      const age = Date.now() - stats.mtimeMs;
      
      if (age > maxAge) {
        fs.unlinkSync(cacheFile);
        return null;
      }
      
      const data = fs.readFileSync(cacheFile, 'utf8');
      logger.debug(`Cache hit: ${key}`);
      return JSON.parse(data);
    } catch (err) {
      logger.debug(`Cache get failed: ${err.message}`);
      return null;
    }
  }

  set(key, data) {
    if (!this.enabled) return;
    
    try {
      const cacheFile = path.join(this.cacheDir, `${key}.json`);
      fs.writeFileSync(cacheFile, JSON.stringify(data));
      logger.debug(`Cache set: ${key}`);
    } catch (err) {
      logger.debug(`Cache set failed: ${err.message}`);
    }
  }

  invalidate(pattern = null) {
    if (!this.enabled) return;
    
    try {
      const files = fs.readdirSync(this.cacheDir);
      let count = 0;
      
      for (const file of files) {
        if (!pattern || file.includes(pattern)) {
          fs.unlinkSync(path.join(this.cacheDir, file));
          count++;
        }
      }
      
      logger.info(`Invalidated ${count} cache entries`);
    } catch (err) {
      logger.warn(`Cache invalidation failed: ${err.message}`);
    }
  }

  clear() {
    if (!this.enabled) return;
    
    try {
      if (fs.existsSync(this.cacheDir)) {
        const files = fs.readdirSync(this.cacheDir);
        for (const file of files) {
          fs.unlinkSync(path.join(this.cacheDir, file));
        }
        logger.info('Cache cleared');
      }
    } catch (err) {
      logger.warn(`Cache clear failed: ${err.message}`);
    }
  }
}

const cache = new CacheManager(CONFIG.cacheDir);

// ============================================
// STATISTICS TRACKING
// ============================================

class Statistics {
  constructor() {
    this.reset();
  }

  reset() {
    this.startTime = Date.now();
    this.data = {
      totalProducts: 0,
      imagesMatchedById: 0,
      imagesMatchedByCombo: 0,
      imagesMatchedByLabel: 0,
      imagesMatchedByMap: 0,
      imagesMatchedByFuzzy: 0,
      imagesMatchedByCustom: 0,
      imagesMatchedAuto: 0,
      imagesNotFound: 0,
      placeholdersGenerated: 0,
      cacheHits: 0,
      cacheMisses: 0,
      duplicatesDetected: 0,
      imagesProcessed: 0,
      validationErrors: 0,
      pdfsGenerated: 0,
      htmlGenerated: 0,
      retries: 0,
      errors: []
    };
    this.perBrand = new Map();
  }

  trackBrand(brand, type, count = 1) {
    if (!this.perBrand.has(brand)) {
      this.perBrand.set(brand, {});
    }
    const brandStats = this.perBrand.get(brand);
    brandStats[type] = (brandStats[type] || 0) + count;
  }

  error(message, details = {}) {
    this.data.errors.push({
      timestamp: new Date().toISOString(),
      message,
      details
    });
  }

  get duration() {
    return Date.now() - this.startTime;
  }

  get formattedDuration() {
    const seconds = Math.floor(this.duration / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    
    if (hours > 0) return `${hours}h ${minutes % 60}m ${seconds % 60}s`;
    if (minutes > 0) return `${minutes}m ${seconds % 60}s`;
    return `${seconds}s`;
  }

  get matchRate() {
    const matched = this.data.totalProducts - this.data.imagesNotFound;
    return this.data.totalProducts > 0 
      ? ((matched / this.data.totalProducts) * 100).toFixed(2) 
      : '0.00';
  }

  get summary() {
    const matched = this.data.totalProducts - this.data.imagesNotFound;
    return {
      duration: this.formattedDuration,
      totalProducts: this.data.totalProducts,
      imagesMatched: matched,
      imagesNotFound: this.data.imagesNotFound,
      matchRate: `${this.matchRate}%`,
      cacheHits: this.data.cacheHits,
      cacheMisses: this.data.cacheMisses,
      cacheHitRate: this.data.cacheHits + this.data.cacheMisses > 0
        ? `${((this.data.cacheHits / (this.data.cacheHits + this.data.cacheMisses)) * 100).toFixed(2)}%`
        : '0%',
      pdfsGenerated: this.data.pdfsGenerated,
      htmlGenerated: this.data.htmlGenerated,
      errors: this.data.errors.length,
      perBrand: Object.fromEntries(this.perBrand)
    };
  }

  get detailed() {
    return {
      ...this.summary,
      matchMethods: {
        byId: this.data.imagesMatchedById,
        byCombo: this.data.imagesMatchedByCombo,
        byLabel: this.data.imagesMatchedByLabel,
        byMap: this.data.imagesMatchedByMap,
        byFuzzy: this.data.imagesMatchedByFuzzy,
        byCustom: this.data.imagesMatchedByCustom,
        auto: this.data.imagesMatchedAuto
      },
      images: {
        processed: this.data.imagesProcessed,
        duplicates: this.data.duplicatesDetected,
        validationErrors: this.data.validationErrors,
        placeholders: this.data.placeholdersGenerated
      },
      performance: {
        duration: this.duration,
        startTime: new Date(this.startTime).toISOString(),
        endTime: new Date().toISOString()
      },
      errors: this.data.errors
    };
  }
}

const stats = new Statistics();

// ============================================
// UTILITY FUNCTIONS
// ============================================

function readJson(p) {
  try {
    const txt = fs.readFileSync(p, "utf8");
    const data = JSON.parse(txt);
    stats.data.cacheHits++;
    return data;
  } catch (err) {
    stats.data.cacheMisses++;
    logger.debug(`Failed to read JSON from ${p}:`, err.message);
    return null;
  }
}

function readJsonIfExists(p) {
  try {
    if (!fs.existsSync(p)) return null;
    const txt = fs.readFileSync(p, "utf8");
    return JSON.parse(txt);
  } catch (err) {
    logger.debug(`File not found or invalid JSON at ${p}`);
    return null;
  }
}

function ensureDir(p) {
  try {
    fs.mkdirSync(path.dirname(p), { recursive: true });
    return true;
  } catch (err) {
    logger.error(`Failed to create directory ${path.dirname(p)}:`, err.message);
    stats.error(`Directory creation failed`, { path: path.dirname(p) });
    return false;
  }
}

function writeText(p, txt, retries = CONFIG.maxRetries) {
  ensureDir(p);
  
  for (let attempt = 1; attempt <= retries; attempt++) {
    try {
      fs.writeFileSync(p, txt);
      logger.debug(`Written file: ${p}`);
      return true;
    } catch (err) {
      if (attempt === retries) {
        logger.error(`Failed to write file ${p} after ${retries} attempts:`, err.message);
        stats.error(`File write failed`, { path: p, attempts: retries });
        throw err;
      }
      logger.debug(`Write attempt ${attempt} failed for ${p}, retrying...`);
      stats.data.retries++;
      new Promise(resolve => setTimeout(resolve, CONFIG.retryDelay));
    }
  }
}

// ============================================
// ADVANCED SLUGIFY
// ============================================

function slugify(s) {
  if (!s) return "unnamed";
  
  // Normalize and remove diacritics
  const normalized = String(s)
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "") // Remove combining diacritical marks
    .replace(/[^\p{L}\p{N}_-]/gu, "-") // Keep letters, numbers, underscore, hyphen
    .replace(/-+/g, "-") // Collapse multiple hyphens
    .replace(/^-+|-+$/g, "") // Trim hyphens
    .toLowerCase()
    .slice(0, 80);
  
  return normalized || "unnamed";
}

// ============================================
// ADVANCED STRING SIMILARITY
// ============================================

class StringMatcher {
  static levenshtein(str1, str2) {
    const len1 = str1.length;
    const len2 = str2.length;
    const matrix = Array(len1 + 1).fill(null).map(() => Array(len2 + 1).fill(0));
    
    for (let i = 0; i <= len1; i++) matrix[i][0] = i;
    for (let j = 0; j <= len2; j++) matrix[0][j] = j;
    
    for (let i = 1; i <= len1; i++) {
      for (let j = 1; j <= len2; j++) {
        const cost = str1[i - 1] === str2[j - 1] ? 0 : 1;
        matrix[i][j] = Math.min(
          matrix[i - 1][j] + 1,
          matrix[i][j - 1] + 1,
          matrix[i - 1][j - 1] + cost
        );
      }
    }
    
    return matrix[len1][len2];
  }

  static similarity(str1, str2) {
    if (!str1 || !str2) return 0;
    if (str1 === str2) return 1;
    
    const distance = this.levenshtein(str1, str2);
    const maxLen = Math.max(str1.length, str2.length);
    return 1 - distance / maxLen;
  }

  static jaroWinkler(str1, str2) {
    if (!str1 || !str2) return 0;
    if (str1 === str2) return 1;

    const len1 = str1.length;
    const len2 = str2.length;
    const matchDistance = Math.floor(Math.max(len1, len2) / 2) - 1;
    const matches1 = Array(len1).fill(false);
    const matches2 = Array(len2).fill(false);
    let matches = 0;

    for (let i = 0; i < len1; i++) {
      const start = Math.max(0, i - matchDistance);
      const end = Math.min(i + matchDistance + 1, len2);

      for (let j = start; j < end; j++) {
        if (matches2[j] || str1[i] !== str2[j]) continue;
        matches1[i] = true;
        matches2[j] = true;
        matches++;
        break;
      }
    }

    if (matches === 0) return 0;

    let transpositions = 0;
    let k = 0;

    for (let i = 0; i < len1; i++) {
      if (!matches1[i]) continue;
      while (!matches2[k]) k++;
      if (str1[i] !== str2[k]) transpositions++;
      k++;
    }

    transpositions = Math.floor(transpositions / 2);

    const jaro = (
      (matches / len1) +
      (matches / len2) +
      ((matches - transpositions) / matches)
    ) / 3;

    // Winkler modification
    let prefix = 0;
    for (let i = 0; i < Math.min(str1.length, str2.length, 4); i++) {
      if (str1[i] === str2[i]) prefix++;
      else break;
    }

    return jaro + (prefix * 0.1 * (1 - jaro));
  }

  static findBestMatch(target, candidates, threshold = CONFIG.fuzzyMatchThreshold) {
    if (!candidates.length) return null;

    let bestMatch = null;
    let bestScore = 0;

    for (const candidate of candidates) {
      const score = Math.max(
        this.jaroWinkler(target, candidate),
        this.similarity(target, candidate)
      );

      if (score > bestScore && score >= threshold) {
        bestScore = score;
        bestMatch = { candidate, score };
      }
    }

    return bestMatch;
  }
}

// ============================================
// IMAGE VALIDATION & PROCESSING
// ============================================

class ImageValidator {
  static validate(filePath) {
    try {
      const stats = fs.statSync(filePath);
      const size = stats.size;

      if (size < CONFIG.minImageSize) {
        logger.verbose(`Image too small: ${path.basename(filePath)} (${size} bytes)`);
        stats.data.validationErrors++;
        return { valid: false, reason: 'too_small', size };
      }

      if (size > CONFIG.maxImageSize) {
        logger.verbose(`Image too large: ${path.basename(filePath)} (${size} bytes)`);
        stats.data.validationErrors++;
        return { valid: false, reason: 'too_large', size };
      }

      const ext = path.extname(filePath).toLowerCase();
      if (!CONFIG.allowedExtensions.includes(ext)) {
        logger.verbose(`Invalid extension: ${path.basename(filePath)} (${ext})`);
        stats.data.validationErrors++;
        return { valid: false, reason: 'invalid_extension', ext };
      }

      return { valid: true, size, ext };
    } catch (err) {
      logger.error(`Failed to validate ${filePath}:`, err.message);
      stats.data.validationErrors++;
      return { valid: false, reason: 'error', error: err.message };
    }
  }

  static async checkQuality(filePath) {
    // Basic quality checks
    const validation = this.validate(filePath);
    if (!validation.valid) return validation;

    // Check for corrupted files (basic check)
    try {
      const buffer = fs.readFileSync(filePath);
      if (buffer.length < 100) {
        return { valid: false, reason: 'corrupted' };
      }

      // Check image headers for common formats
      const header = buffer.slice(0, 8).toString('hex').toLowerCase();
      const validHeaders = {
        jpg: ['ffd8ff'],
        png: ['89504e470d0a1a0a'],
        webp: ['52494646'],
        gif: ['47494638']
      };

      let hasValidHeader = false;
      for (const format in validHeaders) {
        for (const h of validHeaders[format]) {
          if (header.startsWith(h)) {
            hasValidHeader = true;
            break;
          }
        }
        if (hasValidHeader) break;
      }

      if (!hasValidHeader) {
        logger.verbose(`Invalid image header: ${path.basename(filePath)}`);
        return { valid: false, reason: 'invalid_header' };
      }

      return { valid: true, quality: 'good' };
    } catch (err) {
      return { valid: false, reason: 'error', error: err.message };
    }
  }

  static calculateHash(filePath) {
    try {
      const buffer = fs.readFileSync(filePath);
      return crypto.createHash('md5').update(buffer).digest('hex');
    } catch (err) {
      return null;
    }
  }
}

// ============================================
// IMAGE MATCHING ENGINE
// ============================================

class ImageMatcher {
  constructor(baseDir) {
    this.baseDir = baseDir;
    this.imageList = null;
    this.imageHashes = new Map();
    this.imageMap = null;
  }

  loadImageList() {
    if (this.imageList) return this.imageList;

    const cacheKey = `imageList_${this.baseDir}`;
    const cached = cache.get(cacheKey);
    
    if (cached) {
      this.imageList = cached;
      return this.imageList;
    }

    try {
      const entries = fs.readdirSync(this.baseDir, { withFileTypes: true });
      const files = [];

      for (const e of entries) {
        if (!e.isFile()) continue;

        const ext = path.extname(e.name).toLowerCase();
        if (!CONFIG.allowedExtensions.includes(ext)) continue;

        const abs = path.resolve(this.baseDir, e.name);
        const validation = ImageValidator.validate(abs);

        if (validation.valid) {
          files.push({
            path: abs,
            name: e.name,
            basename: path.basename(e.name, ext),
            ext: ext,
            size: validation.size
          });
        }
      }

      this.imageList = files;
      stats.data.imagesProcessed = files.length;
      cache.set(cacheKey, files);
      
      logger.info(`Loaded ${files.length} valid images from ${this.baseDir}`);
      return files;
    } catch (err) {
      logger.error(`Failed to load image list: ${err.message}`);
      stats.error('Image list load failed', { dir: this.baseDir });
      return [];
    }
  }

  detectDuplicates() {
    if (!CONFIG.duplicateDetection) return;

    logger.info('Detecting duplicate images...');
    const hashes = new Map();
    let duplicates = 0;

    for (const img of this.loadImageList()) {
      const hash = ImageValidator.calculateHash(img.path);
      if (hash) {
        if (hashes.has(hash)) {
          logger.verbose(`Duplicate detected: ${img.name} = ${hashes.get(hash).name}`);
          duplicates++;
          stats.data.duplicatesDetected++;
          img.duplicate = true;
          img.duplicateOf = hashes.get(hash).path;
        } else {
          hashes.set(hash, img);
        }
      }
    }

    if (duplicates > 0) {
      logger.warn(`Found ${duplicates} duplicate images`);
    }
  }

  loadManualMap() {
    const mapPath = path.resolve(this.baseDir, "image_map.json");
    const cached = cache.get(`imageMap_${this.baseDir}`);
    
    if (cached) {
      this.imageMap = cached;
      return this.imageMap;
    }

    try {
      const txt = fs.readFileSync(mapPath, "utf8");
      const j = JSON.parse(txt);
      
      if (j && typeof j === "object") {
        const mapSize = Object.keys(j).length;
        logger.info(`Loaded manual image map with ${mapSize} entries`);
        this.imageMap = j;
        cache.set(`imageMap_${this.baseDir}`, j);
        return j;
      }
    } catch (err) {
      logger.debug(`No image map found at ${mapPath}`);
    }

    return null;
  }

  findForProduct(product) {
    stats.data.totalProducts++;
    
    // Strategy 1: Manual map
    if (this.imageMap && this.imageMap[product.id]) {
      logger.debug(`Match by map: ${product.id}`);
      stats.data.imagesMatchedByMap++;
      stats.trackBrand(product.brand, 'mapMatch');
      return { path: this.imageMap[product.id], method: 'map' };
    }

    // Strategy 2: Custom matchers
    for (const [name, matcher] of Object.entries(CONFIG.customMatchers)) {
      try {
        const result = matcher(product, this.loadImageList());
        if (result) {
          logger.debug(`Match by custom matcher "${name}": ${product.id}`);
          stats.data.imagesMatchedByCustom++;
          stats.trackBrand(product.brand, 'customMatch');
          return { path: result, method: `custom_${name}` };
        }
      } catch (err) {
        logger.debug(`Custom matcher "${name}" failed:`, err.message);
      }
    }

    const images = this.loadImageList();
    if (!images.length) {
      logger.debug(`No images available for ${product.id}`);
      stats.data.imagesNotFound++;
      return null;
    }

    // Strategy 3: Exact ID match
    if (product.id) {
      const exactMatch = images.find(img => img.basename === String(product.id));
      if (exactMatch) {
        logger.debug(`Match by ID: ${product.id}`);
        stats.data.imagesMatchedById++;
        stats.trackBrand(product.brand, 'idMatch');
        return { path: exactMatch.path, method: 'id' };
      }
    }

    // Strategy 4: Brand-label combination
    const combo = `${product.brand || ""}-${product.label || product.name_fr || ""}`;
    if (combo.trim()) {
      const comboSlug = slugify(combo);
      const comboMatch = images.find(img => img.basename === comboSlug);
      if (comboMatch) {
        logger.debug(`Match by combo: ${product.id}`);
        stats.data.imagesMatchedByCombo++;
        stats.trackBrand(product.brand, 'comboMatch');
        return { path: comboMatch.path, method: 'combo' };
      }
    }

    // Strategy 5: Label only
    const labelOnly = product.label || product.name_fr || "";
    if (labelOnly.trim()) {
      const labelSlug = slugify(labelOnly);
      const labelMatch = images.find(img => img.basename === labelSlug);
      if (labelMatch) {
        logger.debug(`Match by label: ${product.id}`);
        stats.data.imagesMatchedByLabel++;
        stats.trackBrand(product.brand, 'labelMatch');
        return { path: labelMatch.path, method: 'label' };
      }
    }

    // Strategy 6: Fuzzy matching
    const candidates = images.map(img => img.basename);
    const bestMatch = StringMatcher.findBestMatch(labelOnly, candidates);
    
    if (bestMatch) {
      const matchedImg = images.find(img => img.basename === bestMatch.candidate);
      if (matchedImg) {
        logger.debug(`Match by fuzzy (${(bestMatch.score * 100).toFixed(1)}%): ${product.id}`);
        stats.data.imagesMatchedByFuzzy++;
        stats.trackBrand(product.brand, 'fuzzyMatch');
        return { path: matchedImg.path, method: 'fuzzy', score: bestMatch.score };
      }
    }

    logger.debug(`No match found for ${product.id}`);
    stats.data.imagesNotFound++;
    stats.trackBrand(product.brand, 'noMatch');
    return null;
  }

  buildAutoAssignment(items) {
    const images = this.loadImageList();
    if (!images.length) {
      logger.warn('No images available for auto-assignment');
      return {};
    }

    const out = {};
    let i = 0;

    for (const item of items) {
      const pick = images[i % images.length];
      out[item.id] = pick.path;
      stats.data.imagesMatchedAuto++;
      i++;
    }

    logger.debug(`Auto-assigned images to ${items.length} products`);
    return out;
  }
}

// ============================================
// PLACEHOLDER GENERATOR
// ============================================

function placeholderImage(label, w = 520, h = 340) {
  const hue = Math.abs(
    Array.from(String(label || "")).reduce((a, c) => ((a << 5) - a + c.charCodeAt(0)) | 0, 0)
  ) % 360;

  const svg = encodeURIComponent(
    `<svg xmlns='http://www.w3.org/2000/svg' width='${w}' height='${h}'>` +
      `<defs><linearGradient id='g' x1='0' y1='0' x2='1' y2='1'>` +
      `<stop offset='0%' stop-color='hsl(${hue},70%,55%)'/>` +
      `<stop offset='100%' stop-color='hsl(${(hue + 60) % 360},70%,45%)'/>` +
      `</linearGradient></defs>` +
      `<rect width='100%' height='100%' rx='14' fill='url(#g)'/>` +
      `<text x='50%' y='50%' dominant-baseline='middle' text-anchor='middle' fill='white' font-family='system-ui,sans-serif' font-size='22' font-weight='600'>` +
      `${String(label || "No Image").slice(0, 30)}</text>` +
      `<text x='50%' y='70%' dominant-baseline='middle' text-anchor='middle' fill='rgba(255,255,255,0.7)' font-family='system-ui,sans-serif' font-size='12'>` +
      `Image not found</text>` +
      `</svg>`
  );

  stats.data.placeholdersGenerated++;
  return `data:image/svg+xml;charset=utf-8,${svg}`;
}

function toFileUrl(p) {
  const normalized = String(p).replace(/\\/g, "/");
  const absolute = path.isAbsolute(normalized) 
    ? normalized 
    : path.resolve(normalized);
  return `file:///${absolute.replace(/^\//, "")}`;
}

// ============================================
// CONFIGURATION READERS
// ============================================

function readBrandThemes() {
  const p = path.resolve(process.cwd(), "catalogue", "code.txt");
  const cacheKey = `brandThemes_${p}`;
  
  const cached = cache.get(cacheKey);
  if (cached) return cached;

  try {
    const txt = fs.readFileSync(p, "utf8");
    const j = JSON.parse(txt);
    if (j && typeof j === "object") {
      const brandCount = Object.keys(j).length;
      logger.info(`Loaded ${brandCount} brand themes`);
      cache.set(cacheKey, j);
      return j;
    }
  } catch (err) {
    logger.debug(`No brand themes found at ${p}`);
  }
  return null;
}

function beautyEnabled() {
  const p = path.resolve(process.cwd(), "catalogue", "beauty.txt");
  try {
    fs.accessSync(p);
    return true;
  } catch {
    return false;
  }
}

function readBrandPriority() {
  const p = path.resolve(process.cwd(), "catalogue", "brand_priority.json");
  const cacheKey = `brandPriority_${p}`;
  
  const cached = cache.get(cacheKey);
  if (cached) return cached;

  try {
    const txt = fs.readFileSync(p, "utf8");
    const arr = JSON.parse(txt);
    const normalized = Array.isArray(arr) ? arr.map(s => String(s).trim().toUpperCase()) : [];
    logger.info(`Loaded ${normalized.length} priority brands`);
    cache.set(cacheKey, normalized);
    return normalized;
  } catch (err) {
    logger.debug(`No brand priority found at ${p}`);
  }
  return [];
}

// ============================================
// SECTION MANAGEMENT
// ============================================

function brandSections(items) {
  const byBrand = new Map();

  for (const it of items) {
    const b = it.brand || "Divers";
    if (!byBrand.has(b)) byBrand.set(b, []);
    byBrand.get(b).push(it);
  }

  const sections = Array.from(byBrand.entries()).map(([brand, arr]) => ({
    brand,
    items: arr
  }));

  sections.sort((a, b) => String(a.brand).localeCompare(String(b.brand)));
  return sections;
}

function orderSections(sections, priority) {
  if (!Array.isArray(priority) || priority.length === 0) return sections;

  const pset = new Set(priority);
  const featured = sections.filter(s => pset.has(String(s.brand).toUpperCase()));
  const rest = sections.filter(s => !pset.has(String(s.brand).toUpperCase()));

  featured.sort((a, b) =>
    priority.indexOf(String(a.brand).toUpperCase()) -
    priority.indexOf(String(b.brand).toUpperCase())
  );

  rest.sort((a, b) => String(a.brand).localeCompare(String(b.brand)));

  return [...featured, ...rest];
}

// ============================================
// HTML GENERATION
// ============================================

function generateCardHtml(baseDir, matcher, product, opts = {}) {
  const match = matcher.findForProduct(product);
  const imgSrc = match ? toFileUrl(match.path) : placeholderImage(product.label);
  
  const showPrice = opts.showPrice;
  const price = showPrice && product.price
    ? `<div class="price">Prix de vente: ${product.price}</div>`
    : `<div class="price">Prix: réservé (à remplir)</div>`;

  const priceOverlay = showPrice && product.price
    ? `<div class="overlay-price">Prix de vente: ${product.price}</div>`
    : '';

  const pills = product.variants && product.variants.length
    ? `<div class="meta">${product.variants
        .map(v => `<span class="pill">${v.kind}: ${String(v.value).replace(/"/g, "").toUpperCase()}</span>`)
        .join('')}</div>`
    : '';

  return `
    <div class="card">
      <div class="img">
        <img alt="${product.label}" src="${imgSrc}" loading="lazy"/>
        ${priceOverlay}
      </div>
      <div class="content">
        <div class="col fr">
          <h3 class="name">${product.brand || ''} — ${product.name_fr || product.label}</h3>
          ${pills}${price}
          <div class="ref">Référence: ${product.id}</div>
        </div>
        <div class="col ar">
          <h3 class="name">${product.name_ar || ''}</h3>
          ${pills}${price.replace('Prix de vente:', 'السعر:').replace('Prix:', 'السعر:')}
          <div class="ref">المرجع: ${product.id}</div>
        </div>
      </div>
    </div>
  `;
}

function generateCSS(be) {
  const gap = be ? 16 : 14;
  const imgH = be ? 200 : 180;
  const radius = be ? 18 : 16;
  const shadow = be ? "0 6px 18px rgba(0,0,0,0.08)" : "0 3px 10px rgba(0,0,0,0.06)";
  const dividerPad = be ? "16px 18px" : "14px 16px";
  const nameSize = be ? 20 : 18;

  return `
    html,body{margin:0;background:#f7f7fa;color:#0e1118}
    body{font-family:system-ui,-apple-system,Segoe UI,Roboto,Ubuntu,Cantarell,Noto Sans,sans-serif}
    .cover{height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;background:radial-gradient(1200px 500px at 20% -100%,#1a1f3b 0%,transparent 70%),radial-gradient(1200px 500px at 100% -120%,#10202f 0%,transparent 70%);color:#ecf2ff}
    .cover h1{font-size:44px;margin:8px 0;font-weight:700}
    .cover p{color:#cbd3df;font-size:18px}
    .toc{page-break-after:always;padding:28px}
    .toc h2{margin:0 0 14px;font-weight:700;color:#0d1425}
    .toc h3{margin:16px 0 10px;color:#1e293b;font-size:16px}
    .toc ul{list-style:none;padding:0;margin:0}
    .toc li{margin:6px 0}
    .toc a{color:#2563eb;text-decoration:none}
    .toc a:hover{text-decoration:underline}
    .page{padding:20px;page-break-after:always;max-width:180mm;margin:0 auto}
    .divider{margin:10px 0 18px;padding:${dividerPad};border-radius:14px;border:1px solid #1e2532;display:flex;align-items:center;gap:12px}
    .divider .logo{height:26px;display:inline-block;object-fit:contain}
    .grid{display:grid;grid-template-columns:repeat(3,1fr);gap:${gap}px;align-items:start}
    .card{background:#fff;border:1px solid #dfe6f3;border-radius:${radius}px;overflow:hidden;box-shadow:${shadow};display:flex;flex-direction:column;transition:transform 0.2s,box-shadow 0.2s}
    .card:hover{transform:translateY(-2px);box-shadow:0 8px 24px rgba(0,0,0,0.12)}
    .img{background:#11182a;position:relative;overflow:hidden}
    .img img{width:100%;height:${imgH}px;object-fit:contain;display:block;background:#0f1a34}
    .overlay-price{position:absolute;right:10px;bottom:10px;background:rgba(22,38,58,0.9);color:#eaf1ff;border:1px solid #2a3e58;border-radius:10px;padding:6px 10px;font-size:12px;font-weight:600;box-shadow:0 2px 8px rgba(0,0,0,0.3)}
    .content{display:grid;grid-template-columns:1fr 1fr;gap:10px;padding:12px 14px}
    .col{border:1px solid #e8eef8;border-radius:12px;padding:10px;background:#f9fbff}
    .name{margin:0 0 4px;font-size:${nameSize}px;color:#0d1425;font-weight:700;line-height:1.3}
    .ref{margin-top:6px;font-size:10px;color:#6b7c99;font-family:monospace}
    .fr{direction:ltr;text-align:left}
    .ar{direction:rtl;text-align:right}
    .meta{display:flex;flex-wrap:wrap;gap:6px;margin-top:6px}
    .pill{display:inline-flex;padding:4px 10px;border-radius:999px;background:#eef3fb;border:1px solid #d6e0f2;color:#21406a;font-size:12px;font-weight:500}
    .price{margin-top:10px;padding:8px;border:2px dashed #cfd8ea;border-radius:12px;background:#fafcff;color:#7c8aa5;font-size:12px;font-weight:500}
    .footer{margin-top:6px;font-size:12px;color:#6b7c99;text-align:center}
    @page{size:A4;margin:12mm}
    @media print{
      .grid{break-inside:avoid;page-break-inside:avoid}
      .card{break-inside:avoid;page-break-inside:avoid}
      .divider{break-inside:avoid}
      .cover{break-after:page}
      .toc{break-after:page}
      .page{break-after:page}
    }
  `;
}

function buildFullHtml(master, electronics, baseDir) {
  const be = beautyEnabled();
  const css = generateCSS(be);
  const themes = readBrandThemes() || {};
  const priority = readBrandPriority();
  
  const matcher = new ImageMatcher(baseDir);
  matcher.loadManualMap();
  matcher.loadImageList();
  matcher.detectDuplicates();

  const sections = orderSections(brandSections(master.items), priority);
  const electronicsSections = electronics && Array.isArray(electronics.items)
    ? orderSections(brandSections(electronics.items), priority)
    : [];

  // Build furniture pages
  let totalCards = 0;
  const pages = sections.map((sec, idx) => {
    logger.progress(idx + 1, sections.length, `Processing brand: ${sec.brand}`);
    
    const cards = sec.items.map(p => {
      totalCards++;
      return generateCardHtml(baseDir, matcher, p, { showPrice: false });
    }).join('');
    
    const anchor = slugify(`brand-${sec.brand}`);
    const t = themes[String(sec.brand || '').toUpperCase()] || themes[String(sec.brand || '')] || {};
    const bg = t.primary_color || '#0e1118';
    const fg = '#ffffff';
    const logo = t.logo_path && fs.existsSync(path.resolve(process.cwd(), t.logo_path))
      ? toFileUrl(path.resolve(process.cwd(), t.logo_path))
      : '';
    const logoHtml = logo ? `<img class="logo" src="${logo}" alt="${sec.brand} logo"/>` : '';

    return `
      <div class="page" id="${anchor}">
        <div class="divider" style="background:${bg};color:${fg};border-color:${bg}${be ? `;background-image:linear-gradient(90deg,${bg} 0%,rgba(255,255,255,0.06) 100%)` : ''}">
          ${logoHtml}
          <div style="font-weight:800">Marque: ${sec.brand}</div>
        </div>
        <div class="grid">${cards}</div>
      </div>
    `;
  }).join('');
  
  logger.clearProgress();

  // Build electronics pages
  const pagesElectronics = electronicsSections.map((sec, idx) => {
    logger.progress(idx + 1, electronicsSections.length, `Processing electronics: ${sec.brand}`);
    
    const cards = sec.items.map(p => {
      totalCards++;
      return generateCardHtml(baseDir, matcher, p, { showPrice: true });
    }).join('');
    
    const anchor = slugify(`elec-${sec.brand}`);
    const t = themes[String(sec.brand || '').toUpperCase()] || themes[String(sec.brand || '')] || {};
    const bg = t.primary_color || '#16263a';
    const fg = '#ffffff';
    const logo = t.logo_path && fs.existsSync(path.resolve(process.cwd(), t.logo_path))
      ? toFileUrl(path.resolve(process.cwd(), t.logo_path))
      : '';
    const logoHtml = logo ? `<img class="logo" src="${logo}" alt="${sec.brand} logo"/>` : '';

    return `
      <div class="page" id="${anchor}">
        <div class="divider" style="background:${bg};color:${fg};border-color:${bg}${be ? `;background-image:linear-gradient(90deg,${bg} 0%,rgba(255,255,255,0.06) 100%)` : ''}">
          ${logoHtml}
          <div style="font-weight:800">Électronique — Marque: ${sec.brand}</div>
        </div>
        <div class="grid">${cards}</div>
      </div>
    `;
  }).join('');
  
  logger.clearProgress();
  logger.info(`Generated ${totalCards} product cards`);

  // Cover
  const cover = `
    <section class="cover">
      <h1>Atlas Fournitures</h1>
      <p>Catalogue illustré (FR + AR) — Prix réservés</p>
      <p style="margin-top:20px;font-size:14px;color:#94a3b8">Generated on ${new Date().toLocaleDateString('fr-FR')}</p>
    </section>`;

  // Table of Contents
  const tocBrands = sections
    .map(s => `<li><a href="#${slugify(`brand-${s.brand}`)}">${s.brand} <span style="color:#64748b">(${s.items.length})</span></a></li>`)
    .join('');

  const tocElectronics = electronicsSections
    .map(s => `<li><a href="#${slugify(`elec-${s.brand}`)}">${s.brand} <span style="color:#64748b">(${s.items.length})</span></a></li>`)
    .join('');

  const toc = `
    <section class="toc">
      <h2>Sommaire</h2>
      <h3>Mobilier (${sections.length} marques)</h3>
      <ul>${tocBrands}</ul>
      ${electronicsSections.length ? `<h3>Électronique (${electronicsSections.length} marques)</h3><ul>${tocElectronics}</ul>` : ''}
    </section>`;

  return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="description" content="Atlas Fournitures - Catalogue illustré bilingue français/arabe"><title>Atlas Fournitures — Catalogue</title><style>${css}</style></head><body>${cover}${toc}${pages}${pagesElectronics}</body></html>`;
}

function buildSectionHtml(kind, brand, items, baseDir, showPrice = false) {
  const be = beautyEnabled();
  const css = generateCSS(be);
  const themes = readBrandThemes() || {};
  const matcher = new ImageMatcher(baseDir);
  matcher.loadManualMap();

  const cards = items.map(p => generateCardHtml(baseDir, matcher, p, { showPrice })).join('');
  const anchor = slugify(`${kind}-${brand}`);
  const t = themes[String(brand || '').toUpperCase()] || themes[String(brand || '')] || {};
  const bg = t.primary_color || (showPrice ? '#16263a' : '#0e1118');
  const fg = '#ffffff';
  const logo = t.logo_path && fs.existsSync(path.resolve(process.cwd(), t.logo_path))
    ? toFileUrl(path.resolve(process.cwd(), t.logo_path))
    : '';
  const logoHtml = logo ? `<img class="logo" src="${logo}" alt="${brand} logo"/>` : '';

  return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${brand}</title><style>${css}</style></head><body><div class="page" id="${anchor}"><div class="divider" style="background:${bg};color:${fg};border-color:${bg}${be ? `;background-image:linear-gradient(90deg,${bg} 0%,rgba(255,255,255,0.06) 100%)` : ''}">${logoHtml}<div style="font-weight:800">${showPrice ? 'Électronique — Marque: ' : 'Marque: '}${brand}</div></div><div class="grid">${cards}</div></div></body></html>`;
}

// ============================================
// PDF GENERATION
// ============================================

function findEdge() {
  const candidates = [
    "C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe",
    "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe",
    "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
    "/usr/bin/microsoft-edge",
    "/usr/bin/microsoft-edge-stable"
  ];

  for (const c of candidates) {
    try {
      fs.accessSync(c);
      logger.info(`Found Edge browser at: ${c}`);
      return c;
    } catch {}
  }

  logger.warn('Edge browser not found, PDF generation will be skipped');
  return null;
}

async function generatePdf(htmlPath, pdfPath, edgePath) {
  return new Promise((resolve, reject) => {
    const args = [
      '--headless',
      '--disable-gpu',
      '--disable-dev-shm-usage',
      '--no-sandbox',
      `--print-to-pdf=${pdfPath}`,
      toFileUrl(htmlPath)
    ];

    const startTime = Date.now();
    
    const proc = spawn(edgePath, args, {
      stdio: ['ignore', 'pipe', 'pipe']
    });

    let stdout = '';
    let stderr = '';

    proc.stdout.on('data', (data) => stdout += data);
    proc.stderr.on('data', (data) => stderr += data);

    proc.on('close', (code) => {
      const duration = Date.now() - startTime;
      
      if (code === 0) {
        logger.verbose(`PDF generated in ${duration}ms: ${path.basename(pdfPath)}`);
        stats.data.pdfsGenerated++;
        resolve({ success: true, duration });
      } else {
        logger.error(`PDF generation failed with code ${code}: ${path.basename(pdfPath)}`);
        stats.error('PDF generation failed', { htmlPath, pdfPath, code, stderr });
        reject(new Error(`Edge exited with code ${code}: ${stderr}`));
      }
    });

    proc.on('error', (err) => {
      logger.error(`PDF generation error:`, err.message);
      stats.error('PDF generation error', { htmlPath, pdfPath, error: err.message });
      reject(err);
    });

    // Timeout after 60 seconds
    setTimeout(() => {
      proc.kill();
      reject(new Error('PDF generation timeout'));
    }, 60000);
  });
}

async function generatePdfParallel(htmlPaths, pdfPaths, edgePath, workers = 4) {
  logger.info(`Generating ${htmlPaths.length} PDFs with ${workers} parallel workers...`);
  
  const batches = [];
  for (let i = 0; i < htmlPaths.length; i += workers) {
    batches.push({
      htmlPaths: htmlPaths.slice(i, i + workers),
      pdfPaths: pdfPaths.slice(i, i + workers)
    });
  }

  let completed = 0;
  
  for (const batch of batches) {
    const promises = batch.htmlPaths.map((htmlPath, idx) =>
      generatePdf(htmlPath, batch.pdfPaths[idx], edgePath)
        .catch(err => {
          logger.error(`Failed to generate PDF for ${htmlPath}:`, err.message);
          return { success: false, error: err.message };
        })
    );

    const results = await Promise.all(promises);
    
    for (const result of results) {
      if (result.success) {
        completed++;
      }
    }
    
    logger.progress(completed, htmlPaths.length, `PDFs generated`);
  }
  
  logger.clearProgress();
  return completed;
}

// ============================================
// VALIDATION MODE
// ============================================

async function validateMode(master, electronics, baseDir) {
  logger.info('Running in validation mode...');
  
  const matcher = new ImageMatcher(baseDir);
  matcher.loadImageList();
  matcher.loadManualMap();
  matcher.detectDuplicates();

  const allProducts = [
    ...master.items,
    ...(electronics?.items || [])
  ];

  const results = {
    totalProducts: allProducts.length,
    matched: 0,
    notFound: 0,
    byMethod: {},
    perBrand: {},
    issues: []
  };

  for (const product of allProducts) {
    const match = matcher.findForProduct(product);
    
    if (match) {
      results.matched++;
      results.byMethod[match.method] = (results.byMethod[match.method] || 0) + 1;
      
      const brand = product.brand || 'Divers';
      if (!results.perBrand[brand]) results.perBrand[brand] = { total: 0, matched: 0, notFound: 0 };
      results.perBrand[brand].total++;
      results.perBrand[brand].matched++;
    } else {
      results.notFound++;
      const brand = product.brand || 'Divers';
      if (!results.perBrand[brand]) results.perBrand[brand] = { total: 0, matched: 0, notFound: 0 };
      results.perBrand[brand].total++;
      results.perBrand[brand].notFound++;
      
      if (results.issues.length < 100) {
        results.issues.push({
          id: product.id,
          brand: product.brand,
          name: product.label || product.name_fr,
          issue: 'No matching image found'
        });
      }
    }
  }

  const matchRate = ((results.matched / results.totalProducts) * 100).toFixed(2);
  
  console.log('\n' + '='.repeat(60));
  console.log('VALIDATION RESULTS');
  console.log('='.repeat(60));
  console.log(`Total Products: ${results.totalProducts}`);
  console.log(`Images Matched: ${results.matched} (${matchRate}%)`);
  console.log(`Images Not Found: ${results.notFound}`);
  console.log('\nMatch Methods:');
  for (const [method, count] of Object.entries(results.byMethod)) {
    console.log(`  ${method}: ${count}`);
  }
  
  console.log('\nPer Brand:');
  for (const [brand, data] of Object.entries(results.perBrand).sort((a, b) => a[0].localeCompare(b[0]))) {
    const rate = ((data.matched / data.total) * 100).toFixed(1);
    console.log(`  ${brand}: ${data.matched}/${data.total} (${rate}%)`);
  }
  
  if (results.issues.length > 0) {
    console.log(`\nIssues (showing first ${results.issues.length}):`);
    for (const issue of results.issues) {
      console.log(`  [${issue.brand}] ${issue.id} - ${issue.name}`);
    }
  }
  
  console.log('='.repeat(60) + '\n');

  return results;
}

// ============================================
// REPORT GENERATION
// ============================================

function generateReport(outputDir, htmlPath) {
  const report = stats.detailed;
  report.output = {
    html: htmlPath,
    directory: outputDir
  };
  report.config = {
    logLevel: CONFIG.logLevel,
    fuzzyMatchThreshold: CONFIG.fuzzyMatchThreshold,
    parallelWorkers: CONFIG.parallelWorkers,
    cacheEnabled: CONFIG.enableCache
  };

  const reportPath = path.resolve(outputDir, 'report.json');
  writeText(reportPath, JSON.stringify(report, null, 2));
  logger.info(`Report saved to: ${reportPath}`);

  return reportPath;
}

// ============================================
// WEBHOOK & NOTIFICATIONS
// ============================================

async function sendWebhook(data) {
  if (!CONFIG.webhook) return;

  try {
    // Note: This would need fetch or similar in a real implementation
    logger.info(`Sending webhook to: ${CONFIG.webhook}`);
    // Implementation would go here
  } catch (err) {
    logger.error('Failed to send webhook:', err.message);
  }
}

async function sendNotification(message) {
  if (!CONFIG.notify) return;

  try {
    // Implementation would go here
    logger.info(`Notification would be sent to: ${CONFIG.notify}`);
  } catch (err) {
    logger.error('Failed to send notification:', err.message);
  }
}

// ============================================
// MAIN EXECUTION
// ============================================

async function main() {
  logger.info('='.repeat(60));
  logger.info('Advanced PDF Catalogue Generator');
  logger.info('='.repeat(60));
  logger.info(`Mode: ${cliOptions.dryRun ? 'DRY RUN' : cliOptions.validate ? 'VALIDATION' : 'GENERATION'}`);
  logger.info(`Cache: ${CONFIG.enableCache ? 'ENABLED' : 'DISABLED'}`);
  logger.info(`Log Level: ${CONFIG.logLevel}`);
  logger.info(`Parallel Workers: ${CONFIG.parallelWorkers ? CONFIG.parallelWorkers : 'disabled'}`);

  const root = process.cwd();
  const outputDir = CONFIG.outputDir;
  const masterPath = path.resolve(root, "catalogue", "catalogue_master.json");

  // Load master catalogue
  logger.info('Loading master catalogue...');
  const master = readJson(masterPath);
  if (!master || !Array.isArray(master.items)) {
    throw new Error('Master product list missing or invalid');
  }
  logger.info(`Loaded ${master.items.length} items from master catalogue`);

  // Load electronics catalogue
  logger.info('Loading electronics catalogue...');
  let electronics = readJson(path.resolve(root, "catalogue", "catalogue_electronics.json"));
  
  if (!electronics) {
    const alt = readJsonIfExists(path.resolve(root, "catalogue", "images_photos", "products.json"));
    if (Array.isArray(alt)) {
      const items = alt.map((x, i) => ({
        id: String(x.id || `ELEC-${i + 1}`),
        brand: x.brand || "",
        name_fr: x.name_fr || x.name || "",
        name_ar: x.name_ar || "",
        label: x.name_fr || x.name || "",
        variants: [],
        price: null
      }));
      electronics = { items };
      logger.info(`Loaded ${items.length} items from products.json`);
    }
  }
  
  if (electronics) {
    logger.info(`Loaded ${electronics.items.length} items from electronics catalogue`);
  }

  // Determine base directory
  const baseDir = fs.existsSync(path.resolve(process.cwd(), "catalogue", "images_photos"))
    ? path.resolve(process.cwd(), "catalogue", "images_photos")
    : path.resolve(process.cwd(), "catalogue");

  logger.info(`Image directory: ${baseDir}`);

  // Validation mode
  if (cliOptions.validate) {
    await validateMode(master, electronics, baseDir);
    return;
  }

  // Dry run mode
  if (cliOptions.dryRun) {
    logger.info('Dry run mode - no files will be generated');
    await validateMode(master, electronics, baseDir);
    logger.info('Dry run completed successfully');
    return;
  }

  // Generation mode
  logger.info('Generating catalogue...');
  const html = buildFullHtml(master, electronics, baseDir);
  
  const outHtml = path.resolve(outputDir, "catalogue_full.html");
  writeText(outHtml, html);
  stats.data.htmlGenerated++;
  logger.info(`Full catalogue HTML: ${outHtml}`);

  // Generate sections
  const priority = readBrandPriority();
  const furnitureSections = orderSections(brandSections(master.items), priority);
  const electronicsSections = electronics && Array.isArray(electronics.items)
    ? orderSections(brandSections(electronics.items), priority)
    : [];

  const sectionsDir = path.resolve(outputDir, "sections");
  const pdfDir = path.resolve(outputDir, "pdfs");
  
  ensureDir(path.join(sectionsDir, "x"));
  ensureDir(path.join(pdfDir, "x"));

  const manifest = [];
  const htmlPaths = [];
  const pdfPaths = [];

  // Furniture sections
  for (const sec of furnitureSections) {
    const slug = slugify(`brand-${sec.brand}`);
    const sHtml = path.join(sectionsDir, `${slug}.html`);
    const sPdf = path.join(pdfDir, `${slug}.pdf`);
    const htmlStr = buildSectionHtml("brand", sec.brand, sec.items, baseDir, false);
    
    writeText(sHtml, htmlStr);
    stats.data.htmlGenerated++;
    
    manifest.push({
      type: "furniture",
      brand: sec.brand,
      anchor: slug,
      html: sHtml,
      pdf: sPdf,
      count: sec.items.length
    });
    
    htmlPaths.push(sHtml);
    pdfPaths.push(sPdf);
  }

  // Electronics sections
  for (const sec of electronicsSections) {
    const slug = slugify(`elec-${sec.brand}`);
    const sHtml = path.join(sectionsDir, `${slug}.html`);
    const sPdf = path.join(pdfDir, `${slug}.pdf`);
    const htmlStr = buildSectionHtml("electronics", sec.brand, sec.items, baseDir, true);
    
    writeText(sHtml, htmlStr);
    stats.data.htmlGenerated++;
    
    manifest.push({
      type: "electronics",
      brand: sec.brand,
      anchor: slug,
      html: sHtml,
      pdf: sPdf,
      count: sec.items.length
    });
    
    htmlPaths.push(sHtml);
    pdfPaths.push(sPdf);
  }

  logger.info(`Generated ${manifest.length} section HTML files`);

  // Write manifest
  const manifestPath = path.resolve(outputDir, "catalogue_manifest.json");
  writeText(manifestPath, JSON.stringify({ full_html: outHtml, sections: manifest }, null, 2));
  logger.info(`Manifest written: ${manifestPath}`);

  // Generate PDFs
  if (!cliOptions.noPdf) {
    const edge = findEdge();
    
    if (edge) {
      try {
        // Full catalogue PDF
        logger.info('Generating full catalogue PDF...');
        const fullPdfPath = path.resolve(outputDir, "catalogue_full.pdf");
        await generatePdf(outHtml, fullPdfPath, edge);

        // Section PDFs
        if (CONFIG.enableParallel && htmlPaths.length > 1) {
          await generatePdfParallel(htmlPaths, pdfPaths, edge, CONFIG.parallelWorkers);
        } else {
          for (let i = 0; i < htmlPaths.length; i++) {
            logger.progress(i + 1, htmlPaths.length, `Generating PDF: ${path.basename(htmlPaths[i])}`);
            await generatePdf(htmlPaths[i], pdfPaths[i], edge);
          }
          logger.clearProgress();
        }
      } catch (err) {
        logger.error('PDF generation error:', err.message);
        stats.error('PDF generation failed', { error: err.message });
      }
    } else {
      logger.warn('Skipping PDF generation - Edge browser not found');
    }
  }

  // Generate report
  if (CONFIG.reportFile) {
    generateReport(outputDir, outHtml);
  }

  // Send webhook
  await sendWebhook({
    status: 'completed',
    stats: stats.summary,
    timestamp: new Date().toISOString()
  });

  // Print summary
  logger.clearProgress();
  logger.info('='.repeat(60));
  logger.info('GENERATION COMPLETE');
  logger.info('='.repeat(60));
  logger.info(`Duration: ${stats.formattedDuration}`);
  logger.info(`Total Products: ${stats.data.totalProducts}`);
  logger.info(`Images Matched: ${stats.data.totalProducts - stats.data.imagesNotFound}`);
  logger.info(`Images Not Found: ${stats.data.imagesNotFound}`);
  logger.info(`Match Rate: ${stats.matchRate}%`);
  logger.info(`HTML Files: ${stats.data.htmlGenerated}`);
  logger.info(`PDF Files: ${stats.data.pdfsGenerated}`);
  logger.info(`Cache Hits: ${stats.data.cacheHits}`);
  logger.info(`Cache Misses: ${stats.data.cacheMisses}`);
  if (stats.data.retries > 0) {
    logger.info(`Retries: ${stats.data.retries}`);
  }
  if (stats.data.errors.length > 0) {
    logger.info(`Errors: ${stats.data.errors.length}`);
  }
  logger.info('='.repeat(60));

  // Output JSON for programmatic use
  process.stdout.write(JSON.stringify({
    ok: true,
    outHtml,
    count: master.items.length,
    sections: manifest.length,
    stats: stats.summary,
    config: {
      format: cliOptions.format,
      parallel: CONFIG.enableParallel,
      workers: CONFIG.parallelWorkers
    }
  }, null, 2) + '\n');

  // Send notification on error
  if (stats.data.errors.length > 0 && CONFIG.notify) {
    await sendNotification(`Catalogue generation completed with ${stats.data.errors.length} errors`);
  }
}

// Run main
main().catch(err => {
  logger.error('Fatal error:', err.message);
  stats.error('Fatal error', { error: err.message, stack: err.stack });
  
  if (CONFIG.notify) {
    sendNotification(`Catalogue generation failed: ${err.message}`);
  }
  
  process.stdout.write(JSON.stringify({
    ok: false,
    error: err.message,
    stats: stats.summary
  }, null, 2) + '\n');
  
  process.exit(1);
});
