import fs from "node:fs";
import path from "node:path";
import { spawnSync } from "node:child_process";

// ============================================
// CONFIGURATION & LOGGING
// ============================================

const CONFIG = {
  logLevel: process.env.LOG_LEVEL || "info", // 'debug', 'info', 'warn', 'error'
  minImageSize: 10_000, // 10KB minimum
  maxImageSize: 50_000_000, // 50MB maximum
  allowedExtensions: [".jpg", ".jpeg", ".png", ".webp"],
  fuzzyMatchThreshold: 0.85, // Similarity threshold for fuzzy matching
};

const logger = {
  debug: (...args) => {
    if (CONFIG.logLevel === "debug") {
      process.stderr.write(`[DEBUG] ${new Date().toISOString()} - ${args.join(" ")}\n`);
    }
  },
  info: (...args) => {
    if (["debug", "info"].includes(CONFIG.logLevel)) {
      process.stderr.write(`[INFO] ${new Date().toISOString()} - ${args.join(" ")}\n`);
    }
  },
  warn: (...args) => {
    if (["debug", "info", "warn"].includes(CONFIG.logLevel)) {
      process.stderr.write(`[WARN] ${new Date().toISOString()} - ${args.join(" ")}\n`);
    }
  },
  error: (...args) => {
    process.stderr.write(`[ERROR] ${new Date().toISOString()} - ${args.join(" ")}\n`);
  },
};

// Statistics tracking
const stats = {
  totalProducts: 0,
  imagesMatchedById: 0,
  imagesMatchedByCombo: 0,
  imagesMatchedByLabel: 0,
  imagesMatchedByMap: 0,
  imagesMatchedAuto: 0,
  imagesNotFound: 0,
  placeholdersGenerated: 0,
};

// ============================================
// UTILITY FUNCTIONS
// ============================================

function readJson(p) {
  try {
    const txt = fs.readFileSync(p, "utf8");
    return JSON.parse(txt);
  } catch (err) {
    logger.debug(`Failed to read JSON from ${p}:`, err.message);
    return null;
  }
}

function readJsonIfExists(p) {
  try {
    const txt = fs.readFileSync(p, "utf8");
    return JSON.parse(txt);
  } catch (err) {
    logger.debug(`File not found or invalid JSON at ${p}`);
    return null;
  }
}

function ensureDir(p) {
  try {
    fs.mkdirSync(path.dirname(p), { recursive: true });
  } catch (err) {
    logger.error(`Failed to create directory ${path.dirname(p)}:`, err.message);
  }
}

function writeText(p, txt) {
  ensureDir(p);
  try {
    fs.writeFileSync(p, txt);
    logger.debug(`Written file: ${p}`);
  } catch (err) {
    logger.error(`Failed to write file ${p}:`, err.message);
  }
}

/**
 * Improved slugify function that handles:
 * - Unicode characters (Arabic, accents)
 * - Multiple consecutive separators
 * - Leading/trailing separators
 * - Length limit
 */
function slugify(s) {
  if (!s) return "";
  
  // Normalize unicode (decompose accents)
  const normalized = String(s)
    .normalize("NFKD")
    // Remove accents and diacritics
    .replace(/[\u0300-\u036f]/g, "")
    // Replace non-alphanumeric with hyphens
    .replace(/[^a-z0-9\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]+/gi, "-")
    // Remove leading/trailing hyphens
    .replace(/^-+|-+$/g, "")
    // Replace multiple consecutive hyphens
    .replace(/-+/g, "-")
    .toLowerCase()
    .slice(0, 80);
  
  return normalized || "unnamed";
}

/**
 * Calculate similarity between two strings using Levenshtein distance
 * Returns a value between 0 (no match) and 1 (perfect match)
 */
function calculateSimilarity(str1, str2) {
  if (!str1 || !str2) return 0;
  if (str1 === str2) return 1;
  
  const len1 = str1.length;
  const len2 = str2.length;
  const matrix = Array(len1 + 1).fill(null).map(() => Array(len2 + 1).fill(0));
  
  for (let i = 0; i <= len1; i++) matrix[i][0] = i;
  for (let j = 0; j <= len2; j++) matrix[0][j] = j;
  
  for (let i = 1; i <= len1; i++) {
    for (let j = 1; j <= len2; j++) {
      const cost = str1[i - 1] === str2[j - 1] ? 0 : 1;
      matrix[i][j] = Math.min(
        matrix[i - 1][j] + 1,
        matrix[i][j - 1] + 1,
        matrix[i - 1][j - 1] + cost
      );
    }
  }
  
  const distance = matrix[len1][len2];
  const maxLen = Math.max(len1, len2);
  return 1 - distance / maxLen;
}

/**
 * Validate image file
 */
function validateImageFile(filePath) {
  try {
    const stats = fs.statSync(filePath);
    const size = stats.size;
    
    if (size < CONFIG.minImageSize) {
      logger.warn(`Image too small: ${filePath} (${size} bytes)`);
      return false;
    }
    
    if (size > CONFIG.maxImageSize) {
      logger.warn(`Image too large: ${filePath} (${size} bytes)`);
      return false;
    }
    
    const ext = path.extname(filePath).toLowerCase();
    if (!CONFIG.allowedExtensions.includes(ext)) {
      logger.warn(`Invalid extension: ${filePath} (${ext})`);
      return false;
    }
    
    return true;
  } catch (err) {
    logger.error(`Failed to validate ${filePath}:`, err.message);
    return false;
  }
}

// ============================================
// IMAGE HANDLING FUNCTIONS
// ============================================

/**
 * Find product image with improved matching strategies:
 * 1. Exact ID match
 * 2. Brand-label combination match (slugified)
 * 3. Label only match (slugified)
 * 4. Fuzzy match with filename
 */
function findProductImage(baseDir, item) {
  const exts = CONFIG.allowedExtensions;
  const tryNames = [];
  
  // Strategy 1: ID match
  if (item.id) {
    tryNames.push({ name: String(item.id), type: "id" });
  }
  
  // Strategy 2: Brand-label combination
  const combo = `${item.brand || ""}-${item.label || item.name_fr || ""}`;
  if (combo.trim()) {
    tryNames.push({ name: slugify(combo), type: "combo" });
  }
  
  // Strategy 3: Label only
  const labelOnly = item.label || item.name_fr || "";
  if (labelOnly.trim()) {
    tryNames.push({ name: slugify(labelOnly), type: "label" });
  }
  
  // Try each strategy
  for (const { name, type } of tryNames) {
    for (const ext of exts) {
      const p = path.resolve(baseDir, `${name}${ext}`);
      
      try {
        fs.accessSync(p);
        if (validateImageFile(p)) {
          logger.debug(`Found image for ${item.id} via ${type}: ${path.basename(p)}`);
          
          // Track statistics
          if (type === "id") stats.imagesMatchedById++;
          else if (type === "combo") stats.imagesMatchedByCombo++;
          else if (type === "label") stats.imagesMatchedByLabel++;
          
          return { path: p, method: type };
        }
      } catch {
        // Continue to next attempt
      }
    }
  }
  
  // Strategy 4: Fuzzy match with available images
  try {
    const allImages = listImages(baseDir);
    if (allImages.length > 0) {
      const baseName = slugify(labelOnly);
      let bestMatch = null;
      let bestScore = 0;
      
      for (const imgPath of allImages) {
        const imgName = path.basename(imgPath, path.extname(imgPath));
        const score = calculateSimilarity(baseName, imgName);
        
        if (score > bestScore && score >= CONFIG.fuzzyMatchThreshold) {
          bestScore = score;
          bestMatch = imgPath;
        }
      }
      
      if (bestMatch) {
        logger.debug(`Found image for ${item.id} via fuzzy match: ${path.basename(bestMatch)} (${(bestScore * 100).toFixed(1)}%)`);
        return { path: bestMatch, method: "fuzzy" };
      }
    }
  } catch (err) {
    logger.debug(`Fuzzy matching failed for ${item.id}:`, err.message);
  }
  
  logger.debug(`No image found for ${item.id} (${item.label || item.name_fr})`);
  return null;
}

/**
 * List all valid images in directory
 */
function listImages(baseDir) {
  try {
    const entries = fs.readdirSync(baseDir, { withFileTypes: true });
    const files = [];
    
    for (const e of entries) {
      if (!e.isFile()) continue;
      
      const ext = path.extname(e.name).toLowerCase();
      if (!CONFIG.allowedExtensions.includes(ext)) continue;
      
      const abs = path.resolve(baseDir, e.name);
      
      if (validateImageFile(abs)) {
        files.push(abs);
      }
    }
    
    logger.debug(`Found ${files.length} valid images in ${baseDir}`);
    return files;
  } catch (err) {
    logger.error(`Failed to list images in ${baseDir}:`, err.message);
    return [];
  }
}

/**
 * Load manual image mapping
 */
function loadImageMap(baseDir) {
  const p = path.resolve(baseDir, "image_map.json");
  try {
    const txt = fs.readFileSync(p, "utf8");
    const j = JSON.parse(txt);
    
    if (j && typeof j === "object") {
      const mapSize = Object.keys(j).length;
      logger.info(`Loaded image map with ${mapSize} entries`);
      return j;
    }
  } catch (err) {
    logger.debug(`No image map found at ${p}`);
  }
  return null;
}

/**
 * Build automatic image assignment (fallback)
 */
function buildAutoImageAssignment(items, baseDir) {
  const imgs = listImages(baseDir);
  if (!imgs.length) {
    logger.warn("No images available for auto-assignment");
    return {};
  }
  
  const out = {};
  let i = 0;
  
  for (const it of items) {
    const pick = imgs[i % imgs.length];
    out[it.id] = pick;
    stats.imagesMatchedAuto++;
    i++;
  }
  
  logger.debug(`Auto-assigned images to ${items.length} products`);
  return out;
}

/**
 * Convert file path to file:// URL
 */
function toFileUrl(p) {
  // Normalize path separators
  const normalized = String(p).replace(/\\/g, "/");
  // Ensure it's an absolute path
  const absolute = path.isAbsolute(normalized) ? normalized : path.resolve(normalized);
  // Convert to file:// URL
  return `file:///${absolute.replace(/^\//, "")}`;
}

/**
 * Generate placeholder image with SVG
 */
function placeholderImage(label, w = 520, h = 340) {
  const hue = Math.abs(
    Array.from(String(label || "")).reduce((a, c) => ((a << 5) - a + c.charCodeAt(0)) | 0, 0)
  ) % 360;
  
  const svg = encodeURIComponent(
    `<svg xmlns='http://www.w3.org/2000/svg' width='${w}' height='${h}'>` +
      `<defs><linearGradient id='g' x1='0' y1='0' x2='1' y2='1'><stop offset='0%' stop-color='hsl(${hue},70%,55%)'/><stop offset='100%' stop-color='hsl(${(hue + 60) % 360},70%,45%)'/></linearGradient></defs>` +
      `<rect width='100%' height='100%' rx='14' fill='url(#g)'/>` +
      `<text x='50%' y='50%' dominant-baseline='middle' text-anchor='middle' fill='white' font-family='system-ui' font-size='22'>${String(label || "").slice(0, 42)}</text>` +
      `</svg>`
  );
  
  stats.placeholdersGenerated++;
  return `data:image/svg+xml;charset=utf-8,${svg}`;
}

// ============================================
// CONFIGURATION READING
// ============================================

function readBrandThemes() {
  const p = path.resolve(process.cwd(), "catalogue", "code.txt");
  try {
    const txt = fs.readFileSync(p, "utf8");
    const j = JSON.parse(txt);
    if (j && typeof j === "object") {
      const brandCount = Object.keys(j).length;
      logger.info(`Loaded ${brandCount} brand themes`);
      return j;
    }
  } catch (err) {
    logger.debug(`No brand themes found at ${p}`);
  }
  return null;
}

function beautyEnabled() {
  const p = path.resolve(process.cwd(), "catalogue", "beauty.txt");
  try {
    fs.accessSync(p);
    return true;
  } catch {
    return false;
  }
}

function readBrandPriority() {
  const p = path.resolve(process.cwd(), "catalogue", "brand_priority.json");
  try {
    const txt = fs.readFileSync(p, "utf8");
    const arr = JSON.parse(txt);
    const normalized = Array.isArray(arr) ? arr.map((s) => String(s).trim().toUpperCase()) : [];
    logger.info(`Loaded ${normalized.length} priority brands`);
    return normalized;
  } catch (err) {
    logger.debug(`No brand priority found at ${p}`);
    return [];
  }
}

// ============================================
// SECTION & BRAND MANAGEMENT
// ============================================

function brandSections(items) {
  const byBrand = new Map();
  
  for (const it of items) {
    const b = it.brand || "Divers";
    if (!byBrand.has(b)) byBrand.set(b, []);
    byBrand.get(b).push(it);
  }
  
  const sections = Array.from(byBrand.entries()).map(([brand, arr]) => ({
    brand,
    items: arr,
  }));
  
  sections.sort((a, b) => String(a.brand).localeCompare(String(b.brand)));
  return sections;
}

function orderSections(sections, priority) {
  if (!Array.isArray(priority) || priority.length === 0) return sections;
  
  const pset = new Set(priority);
  const featured = sections.filter((s) => pset.has(String(s.brand).toUpperCase()));
  const rest = sections.filter((s) => !pset.has(String(s.brand).toUpperCase()));
  
  featured.sort(
    (a, b) =>
      priority.indexOf(String(a.brand).toUpperCase()) -
      priority.indexOf(String(b.brand).toUpperCase())
  );
  
  rest.sort((a, b) => String(a.brand).localeCompare(String(b.brand)));
  
  return [...featured, ...rest];
}

// ============================================
// HTML/CSS GENERATION
// ============================================

/**
 * Generate card HTML for a single product
 */
function cardFor(baseDir, p, opts = {}, imageMap) {
  stats.totalProducts++;
  
  // Try to get image from map
  const mapped = imageMap && imageMap[p.id] ? imageMap[p.id] : null;
  
  if (mapped) {
    stats.imagesMatchedByMap++;
    logger.debug(`Using mapped image for ${p.id}: ${path.basename(mapped)}`);
  }
  
  // Find image or use placeholder
  const imgResult = mapped ? { path: mapped, method: "map" } : findProductImage(baseDir, p);
  
  if (!imgResult) {
    stats.imagesNotFound++;
    logger.debug(`No image for ${p.id}, using placeholder`);
  }
  
  const imgPath = imgResult ? imgResult.path : null;
  const imgSrc = imgPath ? toFileUrl(imgPath) : placeholderImage(p.label);
  
  // Generate variant pills
  const pills =
    p.variants && p.variants.length
      ? `<div class="meta">${p.variants
          .map(
            (v) =>
              `<span class="pill">${v.kind}: ${String(v.value)
                .replace(/"/g, "")
                .toUpperCase()}</span>`
          )
          .join("")}</div>`
      : "";
  
  // Generate price text
  const price = opts.showPrice && p.price
    ? `<div class="price">Prix de vente: ${p.price}</div>`
    : `<div class="price">Prix: réservé (à remplir)</div>`;
  
  const priceOverlay = opts.showPrice && p.price
    ? `<div class="overlay-price">Prix de vente: ${p.price}</div>`
    : "";
  
  return (
    `<div class="card">` +
    `<div class="img"><img alt="${p.label}" src="${imgSrc}"/>${priceOverlay}</div>` +
    `<div class="content">` +
    `<div class="col fr"><h3 class="name">${p.brand || ""} — ${p.name_fr || p.label}</h3>${pills}${price}<div class="ref">Référence: ${p.id}</div></div>` +
    `<div class="col ar"><h3 class="name">${p.name_ar || ""}</h3>${pills}${price.replace("Prix de vente:", "السعر:").replace("Prix:", "السعر:")}<div class="ref">المرجع: ${p.id}</div></div>` +
    `</div>` +
    `</div>`
  );
}

/**
 * Build complete HTML catalogue
 */
function buildHtml(master, electronics, baseDir) {
  const be = beautyEnabled();
  const gap = be ? 16 : 14;
  const imgH = be ? 200 : 180;
  const radius = be ? 18 : 16;
  const shadow = be ? "0 6px 18px rgba(0,0,0,0.08)" : "0 3px 10px rgba(0,0,0,0.06)";
  const dividerPad = be ? "16px 18px" : "14px 16px";
  const nameSize = be ? 20 : 18;
  
  const css =
    "html,body{margin:0;background:#f7f7fa;color:#0e1118}" +
    "body{font-family:system-ui,-apple-system,Segoe UI,Roboto,Ubuntu,Cantarell,Noto Sans,sans-serif}" +
    ".cover{height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;background:radial-gradient(1200px 500px at 20% -100%,#1a1f3b 0%,transparent 70%),radial-gradient(1200px 500px at 100% -120%,#10202f 0%,transparent 70%);color:#ecf2ff}" +
    ".cover h1{font-size:44px;margin:8px 0}" +
    ".cover p{color:#cbd3df}" +
    ".toc{page-break-after:always;padding:28px}" +
    ".toc h2{margin:0 0 14px;font-weight:700;color:#0d1425}" +
    ".toc ul{list-style:none;padding:0;margin:0}" +
    ".toc li{margin:6px 0}" +
    ".page{padding:20px;page-break-after:always;max-width:180mm;margin:0 auto}" +
    `.divider{margin:10px 0 18px;padding:${dividerPad};border-radius:14px;border:1px solid #1e2532;display:flex;align-items:center;gap:12px}` +
    ".divider .logo{height:26px;display:inline-block}" +
    `.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:${gap}px;align-items:start}` +
    `.card{background:#fff;border:1px solid #dfe6f3;border-radius:${radius}px;overflow:hidden;box-shadow:${shadow};display:flex;flex-direction:column}` +
    ".img{background:#11182a;position:relative}" +
    `.img img{width:100%;height:${imgH}px;object-fit:contain;display:block;background:#0f1a34}` +
    ".overlay-price{position:absolute;right:10px;bottom:10px;background:rgba(22,38,58,0.85);color:#eaf1ff;border:1px solid #2a3e58;border-radius:10px;padding:6px 10px;font-size:12px}" +
    ".content{display:grid;grid-template-columns:1fr 1fr;gap:10px;padding:12px 14px}" +
    ".col{border:1px solid #e8eef8;border-radius:12px;padding:10px;background:#f9fbff}" +
    `.name{margin:0 0 4px;font-size:${nameSize}px;color:#0d1425;font-weight:700}` +
    ".ref{margin-top:6px;font-size:10px;color:#6b7c99}" +
    ".fr{direction:ltr;text-align:left}" +
    ".ar{direction:rtl;text-align:right}" +
    ".meta{display:flex;flex-wrap:wrap;gap:6px;margin-top:6px}" +
    ".pill{display:inline-flex;padding:4px 10px;border-radius:999px;background:#eef3fb;border:1px solid #d6e0f2;color:#21406a;font-size:12px}" +
    ".price{margin-top:10px;padding:8px;border:2px dashed #cfd8ea;border-radius:12px;background:#fafcff;color:#7c8aa5;font-size:12px}" +
    ".footer{margin-top:6px;font-size:12px;color:#6b7c99}" +
    "@page{size:A4;margin:12mm}" +
    "@media print{.grid{break-inside:avoid;page-break-inside:avoid}.card{break-inside:avoid;page-break-inside:avoid}.divider{break-inside:avoid}.cover{break-after:page}.toc{break-after:page}.page{break-after:page}}";
  
  const themes = readBrandThemes() || {};
  const priority = readBrandPriority();
  const sections = orderSections(brandSections(master.items), priority);
  const electronicsSections = electronics && Array.isArray(electronics.items)
    ? orderSections(brandSections(electronics.items), priority)
    : [];
  
  // Build furniture pages
  const pages = sections
    .map((sec) => {
      const imageMap = loadImageMap(baseDir) || buildAutoImageAssignment(sec.items, baseDir);
      const cards = sec.items.map((p) => cardFor(baseDir, p, { showPrice: false }, imageMap)).join("");
      const anchor = slugify(`brand-${sec.brand}`);
      const t = themes[String(sec.brand || "").toUpperCase()] || themes[String(sec.brand || "")] || {};
      const bg = t.primary_color || "#0e1118";
      const fg = "#ffffff";
      const logo = t.logo_path && fs.existsSync(path.resolve(process.cwd(), t.logo_path))
        ? toFileUrl(path.resolve(process.cwd(), t.logo_path))
        : "";
      const logoHtml = logo ? `<img class="logo" src="${logo}" alt="${sec.brand} logo"/>` : "";
      
      return `<div class="page" id="${anchor}"><div class="divider" style="background:${bg};color:${fg};border-color:${bg}${be ? `;background-image:linear-gradient(90deg,${bg} 0%,rgba(255,255,255,0.06) 100%)` : ""}">${logoHtml}<div style="font-weight:800">Marque: ${sec.brand}</div></div><div class="grid">${cards}</div></div>`;
    })
    .join("");
  
  // Build cover
  const cover =
    `<section class="cover"><h1>Atlas Fournitures</h1><p>Catalogue illustré (FR + AR) — Prix réservés</p></section>`;
  
  // Build TOC
  const tocBrands = sections
    .map((s) => `<li><a href="#${slugify(`brand-${s.brand}`)}">${s.brand} (${s.items.length})</a></li>`)
    .join("");
  
  const tocElectronics = electronicsSections
    .map((s) => `<li><a href="#${slugify(`elec-${s.brand}`)}">${s.brand} (${s.items.length})</a></li>`)
    .join("");
  
  const toc =
    `<section class="toc"><h2>Sommaire</h2><h3>Mobilier</h3><ul>${tocBrands}</ul>` +
    (electronicsSections.length ? `<h3>Électronique</h3><ul>${tocElectronics}</ul>` : "") +
    `</section>`;
  
  // Build electronics pages
  const pagesElectronics =
    electronicsSections
      .map((sec) => {
        const imageMap = loadImageMap(baseDir) || buildAutoImageAssignment(sec.items, baseDir);
        const cards = sec.items.map((p) => cardFor(baseDir, p, { showPrice: true }, imageMap)).join("");
        const anchor = slugify(`elec-${sec.brand}`);
        const t = themes[String(sec.brand || "").toUpperCase()] || themes[String(sec.brand || "")] || {};
        const bg = t.primary_color || "#16263a";
        const fg = "#ffffff";
        const logo = t.logo_path && fs.existsSync(path.resolve(process.cwd(), t.logo_path))
          ? toFileUrl(path.resolve(process.cwd(), t.logo_path))
          : "";
        const logoHtml = logo ? `<img class="logo" src="${logo}" alt="${sec.brand} logo"/>` : "";
        
        return `<div class="page" id="${anchor}"><div class="divider" style="background:${bg};color:${fg};border-color:${bg}${be ? `;background-image:linear-gradient(90deg,${bg} 0%,rgba(255,255,255,0.06) 100%)` : ""}">${logoHtml}<div style="font-weight:800">Électronique — Marque: ${sec.brand}</div></div><div class="grid">${cards}</div></div>`;
      })
      .join("") || "";
  
  return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Atlas Fournitures — Catalogue</title><style>${css}</style></head><body>${cover}${toc}${pages}${pagesElectronics}</body></html>`;
}

/**
 * Build HTML for a single section
 */
function buildSectionHtml(kind, brand, items, baseDir) {
  const be = beautyEnabled();
  const gap = be ? 14 : 12;
  const imgH = be ? 190 : 170;
  const radius = be ? 14 : 12;
  const shadow = be ? "0 4px 12px rgba(0,0,0,0.08)" : "0 2px 6px rgba(0,0,0,0.06)";
  const nameSize = be ? 18 : 16;
  
  const css =
    "html,body{margin:0;background:#f7f7fa;color:#0e1118}" +
    "body{font-family:system-ui,-apple-system,Segoe UI,Roboto,Ubuntu,Cantarell,Noto Sans,sans-serif}" +
    ".page{padding:16px;max-width:180mm;margin:0 auto}" +
    ".divider{margin:10px 0 18px;padding:12px 14px;border-radius:12px;border:1px solid #1e2532;display:flex;align-items:center;gap:10px}" +
    ".divider .logo{height:24px;display:inline-block}" +
    `.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:${gap}px}` +
    `.card{background:#fff;border:1px solid #dfe6f3;border-radius:${radius}px;overflow:hidden;box-shadow:${shadow};display:flex;flex-direction:column}` +
    `.img{background:#11182a;position:relative}.img img{width:100%;height:${imgH}px;object-fit:contain;display:block}` +
    ".overlay-price{position:absolute;right:8px;bottom:8px;background:rgba(22,38,58,0.85);color:#eaf1ff;border:1px solid #2a3e58;border-radius:8px;padding:6px 8px;font-size:12px}" +
    ".content{display:grid;grid-template-columns:1fr 1fr;gap:8px;padding:10px}" +
    ".col{border:1px solid #e8eef8;border-radius:8px;padding:8px;background:#f9fbff}" +
    `.name{margin:0 0 4px;font-size:${nameSize}px;color:#0d1425;font-weight:600}` +
    ".ref{margin-top:6px;font-size:10px;color:#6b7c99}" +
    ".fr{direction:ltr;text-align:left}" +
    ".ar{direction:rtl;text-align:right}" +
    ".meta{display:flex;wrap;gap:6px;margin-top:6px}" +
    ".pill{display:inline-flex;padding:4px 8px;border-radius:999px;background:#eef3fb;border:1px solid #d6e0f2;color:#21406a;font-size:12px}" +
    ".price{margin-top:8px;padding:6px;border:2px dashed #cfd8ea;border-radius:8px;background:#fafcff;color:#7c8aa5;font-size:12px}" +
    "@page{size:A4;margin:12mm}" +
    "@media print{.grid{break-inside:avoid;page-break-inside:avoid}.card{break-inside:avoid;page-break-inside:avoid}.divider{break-inside:avoid}.page{break-after:page}}";
  
  const themes = readBrandThemes() || {};
  const showPrice = kind === "electronics";
  const imageMap = loadImageMap(baseDir) || buildAutoImageAssignment(items, baseDir);
  const cards = items.map((p) => cardFor(baseDir, p, { showPrice }, imageMap)).join("");
  const anchor = slugify(`${kind}-${brand}`);
  const t = themes[String(brand || "").toUpperCase()] || themes[String(brand || "")] || {};
  const bg = t.primary_color || (showPrice ? "#16263a" : "#0e1118");
  const fg = "#ffffff";
  const logo = t.logo_path && fs.existsSync(path.resolve(process.cwd(), t.logo_path))
    ? toFileUrl(path.resolve(process.cwd(), t.logo_path))
    : "";
  const logoHtml = logo ? `<img class="logo" src="${logo}" alt="${brand} logo"/>` : "";
  
  return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${brand}</title><style>${css}</style></head><body><div class="page" id="${anchor}"><div class="divider" style="background:${bg};color:${fg};border-color:${bg}${be ? `;background-image:linear-gradient(90deg,${bg} 0%,rgba(255,255,255,0.06) 100%)` : ""}">${logoHtml}<div style="font-weight:800">${showPrice ? "Électronique — Marque: " : "Marque: "}${brand}</div></div><div class="grid">${cards}</div></div></body></html>`;
}

// ============================================
// PDF GENERATION
// ============================================

function findEdge() {
  const candidates = [
    "C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe",
    "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe",
  ];
  
  for (const c of candidates) {
    try {
      fs.accessSync(c);
      logger.info(`Found Edge browser at: ${c}`);
      return c;
    } catch {}
  }
  
  logger.warn("Edge browser not found, PDF generation will be skipped");
  return null;
}

// ============================================
// MAIN EXECUTION
// ============================================

function main() {
  logger.info("Starting catalogue generation");
  
  const root = process.cwd();
  const masterPath = path.resolve(root, "catalogue", "catalogue_master.json");
  const outHtml = path.resolve(root, "catalogue", "catalogue_full.html");
  
  const master = readJson(masterPath);
  
  // Load electronics catalogue
  let electronics = readJson(path.resolve(root, "catalogue", "catalogue_electronics.json"));
  
  // Fallback to products.json if electronics catalogue not found
  if (!electronics) {
    const alt = readJsonIfExists(path.resolve(root, "catalogue", "images_photos", "products.json"));
    if (Array.isArray(alt)) {
      const items = alt.map((x, i) => ({
        id: String(x.id || `ELEC-${i + 1}`),
        brand: x.brand || "",
        name_fr: x.name_fr || x.name || "",
        name_ar: x.name_ar || "",
        label: x.name_fr || x.name || "",
        variants: [],
        price: null
      }));
      electronics = { items };
      logger.info(`Loaded ${items.length} items from products.json`);
    }
  }
  
  // Validate master catalogue
  if (!master || !Array.isArray(master.items)) {
    throw new Error("Master product list missing or invalid");
  }
  
  logger.info(`Loaded ${master.items.length} items from master catalogue`);
  if (electronics) {
    logger.info(`Loaded ${electronics.items.length} items from electronics catalogue`);
  }
  
  // Determine base directory for images
  const baseDir = fs.existsSync(path.resolve(process.cwd(), "catalogue", "images_photos"))
    ? path.resolve(process.cwd(), "catalogue", "images_photos")
    : path.resolve(process.cwd(), "catalogue");
  
  logger.info(`Using image directory: ${baseDir}`);
  
  // Generate full HTML
  const html = buildHtml(master, electronics, baseDir);
  writeText(outHtml, html);
  logger.info(`Generated full catalogue HTML: ${outHtml}`);
  
  // Generate section HTML and PDFs
  const priority = readBrandPriority();
  const furnitureSections = orderSections(brandSections(master.items), priority);
  const electronicsSections = electronics && Array.isArray(electronics.items)
    ? orderSections(brandSections(electronics.items), priority)
    : [];
  
  const sectionsDir = path.resolve(root, "catalogue", "sections");
  const pdfDir = path.resolve(root, "catalogue", "pdfs");
  
  ensureDir(path.join(sectionsDir, "x"));
  ensureDir(path.join(pdfDir, "x"));
  
  const manifest = [];
  
  // Process furniture sections
  for (const sec of furnitureSections) {
    const slug = slugify(`brand-${sec.brand}`);
    const sHtml = path.join(sectionsDir, `${slug}.html`);
    const sPdf = path.join(pdfDir, `${slug}.pdf`);
    const htmlStr = buildSectionHtml("brand", sec.brand, sec.items, baseDir);
    
    writeText(sHtml, htmlStr);
    manifest.push({
      type: "furniture",
      brand: sec.brand,
      anchor: slug,
      html: sHtml,
      pdf: sPdf,
      count: sec.items.length
    });
  }
  
  // Process electronics sections
  for (const sec of electronicsSections) {
    const slug = slugify(`elec-${sec.brand}`);
    const sHtml = path.join(sectionsDir, `${slug}.html`);
    const sPdf = path.join(pdfDir, `${slug}.pdf`);
    const htmlStr = buildSectionHtml("electronics", sec.brand, sec.items, baseDir);
    
    writeText(sHtml, htmlStr);
    manifest.push({
      type: "electronics",
      brand: sec.brand,
      anchor: slug,
      html: sHtml,
      pdf: sPdf,
      count: sec.items.length
    });
  }
  
  // Write manifest
  writeText(
    path.resolve(root, "catalogue", "catalogue_manifest.json"),
    JSON.stringify({ full_html: outHtml, sections: manifest }, null, 2)
  );
  
  logger.info(`Generated ${manifest.length} section HTML files`);
  
  // Generate PDFs using Edge
  const edge = findEdge();
  
  if (edge) {
    // Generate full PDF
    const outPdf = path.resolve(root, "catalogue", "catalogue_full.pdf");
    logger.info(`Generating full catalogue PDF: ${outPdf}`);
    
    spawnSync(edge, ["--headless", "--disable-gpu", `--print-to-pdf=${outPdf}`, toFileUrl(outHtml)], {
      stdio: "ignore"
    });
    
    // Generate section PDFs
    for (const entry of manifest) {
      const url = toFileUrl(entry.html);
      logger.info(`Generating PDF for ${entry.brand}: ${entry.pdf}`);
      
      const res = spawnSync(edge, ["--headless", "--disable-gpu", `--print-to-pdf=${entry.pdf}`, url], {
        stdio: "ignore"
      });
      
      if (res.error) {
        logger.error(`Failed to generate PDF for ${entry.brand}:`, res.error.message);
      }
    }
  }
  
  // Log statistics
  logger.info("=== IMAGE MATCHING STATISTICS ===");
  logger.info(`Total products processed: ${stats.totalProducts}`);
  logger.info(`Images matched by ID: ${stats.imagesMatchedById}`);
  logger.info(`Images matched by brand-label combo: ${stats.imagesMatchedByCombo}`);
  logger.info(`Images matched by label only: ${stats.imagesMatchedByLabel}`);
  logger.info(`Images matched by map: ${stats.imagesMatchedByMap}`);
  logger.info(`Images matched automatically: ${stats.imagesMatchedAuto}`);
  logger.info(`Images not found (placeholders): ${stats.imagesNotFound}`);
  logger.info(`================================`);
  
  const matchRate = stats.totalProducts > 0
    ? ((stats.totalProducts - stats.imagesNotFound) / stats.totalProducts * 100).toFixed(1)
    : 0;
  
  logger.info(`Overall image match rate: ${matchRate}%`);
  
  // Output result
  process.stdout.write(JSON.stringify({
    ok: true,
    outHtml,
    count: master.items.length,
    sections: manifest.length,
    edge: Boolean(edge),
    stats: {
      matchRate: `${matchRate}%`,
      matched: stats.totalProducts - stats.imagesNotFound,
      notFound: stats.imagesNotFound,
      placeholders: stats.placeholdersGenerated
    }
  }, null, 2) + "\n");
  
  logger.info("Catalogue generation complete");
}

// Run main function
main();
