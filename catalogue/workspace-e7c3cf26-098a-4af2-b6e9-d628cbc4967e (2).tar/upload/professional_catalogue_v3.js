#!/usr/bin/env node

/**
 * PROFESSIONAL PDF Catalogue Generator v3
 * Enhanced with:
 * - Professional typography and design
 * - Page numbers and footers
 * - Print-optimized layout
 * - Enhanced Arabic support
 * - Better color schemes
 * - Professional branding
 * - Improved placeholders
 * - Better print media queries
 */

import fs from "node:fs";
import path from "node:path";
import { exec } from "node:child_process";
import { promisify } from "node:util";

const execAsync = promisify(exec);

// ============================================
// CONFIGURATION
// ============================================

const CONFIG = {
  logLevel: process.env.LOG_LEVEL || 'info',
  minImageSize: 10_000,
  maxImageSize: 50_000_000,
  allowedExtensions: [".jpg", ".jpeg", ".png", ".webp", ".avif"],
  fuzzyMatchThreshold: 0.85,
  cacheDir: path.resolve(process.cwd(), ".cache", "catalogue"),
  outputDir: path.resolve(process.cwd(), "catalogue"),
  enableCache: true,
  outputFormat: 'both', // 'html', 'pdf', 'both'
};

const logger = {
  levels: { error: 0, warn: 1, info: 2, debug: 3 },
  currentLevel: 2,
  setLevel(level) { this.currentLevel = this.levels[level] || this.levels.info; },
  log(level, ...args) {
    if (this.levels[level] <= this.currentLevel) {
      const timestamp = new Date().toISOString();
      console.error(`[${timestamp}] [${level.toUpperCase()}] ${args.join(' ')}`);
    }
  },
  debug(...args) { this.log('debug', ...args); },
  info(...args) { this.log('info', ...args); },
  warn(...args) { this.log('warn', ...args); },
  error(...args) { this.log('error', ...args); }
};

logger.setLevel(CONFIG.logLevel);

// ============================================
// UTILITY FUNCTIONS
// ============================================

function readJson(p) {
  try {
    const txt = fs.readFileSync(p, "utf8");
    return JSON.parse(txt);
  } catch (err) {
    logger.debug(`Failed to read JSON from ${p}:`, err.message);
    return null;
  }
}

function readJsonIfExists(p) {
  try {
    if (!fs.existsSync(p)) return null;
    const txt = fs.readFileSync(p, "utf8");
    return JSON.parse(txt);
  } catch (err) {
    return null;
  }
}

function ensureDir(p) {
  try {
    fs.mkdirSync(path.dirname(p), { recursive: true });
  } catch (err) {
    logger.error(`Failed to create directory:`, err.message);
  }
}

function writeText(p, txt) {
  ensureDir(p);
  fs.writeFileSync(p, txt);
}

function slugify(s) {
  if (!s) return "unnamed";
  return String(s)
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^\p{L}\p{N}_-]/gu, "-")
    .replace(/-+/g, "-")
    .replace(/^-+|-+$/g, "")
    .toLowerCase()
    .slice(0, 80) || "unnamed";
}

// ============================================
// ENHANCED IMAGE GENERATION
// ============================================

function createProfessionalPlaceholder(label, brand = '', index = 0) {
  const hues = [210, 150, 180, 200, 130, 160, 190, 220];
  const hue = hues[index % hues.length];
  const hue2 = (hue + 40) % 360;
  const textColor = '#ffffff';
  const subtextColor = 'rgba(255,255,255,0.8)';
  
  const svg = encodeURIComponent(`
    <svg xmlns='http://www.w3.org/2000/svg' width='600' height='400' viewBox='0 0 600 400'>
      <defs>
        <linearGradient id='bg' x1='0%' y1='0%' x2='100%' y2='100%'>
          <stop offset='0%' style='stop-color:hsl(${hue},75%,50%)'/>
          <stop offset='100%' style='stop-color:hsl(${hue2},75%,40%)'/>
        </linearGradient>
        <pattern id='grid' width='20' height='20' patternUnits='userSpaceOnUse'>
          <path d='M 20 0 L 0 0 0 20' fill='none' stroke='rgba(255,255,255,0.1)' stroke-width='0.5'/>
        </pattern>
        <filter id='shadow' x='-20%' y='-20%' width='140%' height='140%'>
          <feDropShadow dx='0' dy='2' stdDeviation='3' flood-opacity='0.2'/>
        </filter>
      </defs>
      
      <!-- Background -->
      <rect width='100%' height='100%' fill='url(#bg)'/>
      <rect width='100%' height='100%' fill='url(#grid)'/>
      
      <!-- Decorative circle -->
      <circle cx='500' cy='80' r='120' fill='rgba(255,255,255,0.05)'/>
      <circle cx='100' cy='320' r='80' fill='rgba(255,255,255,0.05)'/>
      
      <!-- Icon -->
      <g transform='translate(300, 140)' filter='url(#shadow)'>
        <circle r='40' fill='rgba(255,255,255,0.2)'/>
        <text x='0' y='15' text-anchor='middle' font-size='32' fill='${textColor}'>📦</text>
      </g>
      
      <!-- Brand name -->
      ${brand ? `<text x='300' y='220' text-anchor='middle' font-size='16' font-weight='600' fill='${subtextColor}' font-family='system-ui,sans-serif'>${brand}</text>` : ''}
      
      <!-- Product name -->
      <text x='300' y='260' text-anchor='middle' font-size='20' font-weight='700' fill='${textColor}' font-family='system-ui,sans-serif'>
        ${String(label || "Product").slice(0, 35)}
      </text>
      
      <!-- Info text -->
      <text x='300' y='290' text-anchor='middle' font-size='12' fill='${subtextColor}' font-family='system-ui,sans-serif'>
        Image placeholder
      </text>
      
      <!-- Border -->
      <rect x='20' y='20' width='560' height='360' rx='8' fill='none' stroke='rgba(255,255,255,0.3)' stroke-width='2'/>
    </svg>
  `);
  
  return `data:image/svg+xml;charset=utf-8,${svg}`;
}

// ============================================
// ENHANCED CSS GENERATION
// ============================================

function generateProfessionalCSS(be) {
  const gap = be ? 18 : 16;
  const imgH = be ? 220 : 200;
  const cardPadding = be ? 16 : 14;
  
  return `
    /* ===== RESET & BASE ===== */
    html {
      margin: 0;
      padding: 0;
      font-size: 16px;
      -webkit-font-smoothing: antialiased;
      -moz-osx-font-smoothing: grayscale;
    }
    
    body {
      margin: 0;
      padding: 0;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, 'Noto Sans', sans-serif;
      background: #ffffff;
      color: #1a1a2e;
      line-height: 1.6;
    }

    /* ===== COVER PAGE ===== */
    .cover {
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 50%, #f093fb 100%);
      color: #ffffff;
      padding: 40px;
      position: relative;
      overflow: hidden;
    }
    
    .cover::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: 
        radial-gradient(circle at 20% 30%, rgba(255,255,255,0.1) 0%, transparent 50%),
        radial-gradient(circle at 80% 70%, rgba(255,255,255,0.1) 0%, transparent 50%);
      pointer-events: none;
    }
    
    .cover-content {
      position: relative;
      z-index: 1;
      text-align: center;
      max-width: 800px;
    }
    
    .cover h1 {
      font-size: 56px;
      font-weight: 800;
      margin: 0 0 20px 0;
      letter-spacing: -1px;
      text-shadow: 0 4px 12px rgba(0,0,0,0.2);
    }
    
    .cover-subtitle {
      font-size: 28px;
      font-weight: 400;
      margin: 0 0 30px 0;
      opacity: 0.95;
    }
    
    .cover-info {
      display: flex;
      justify-content: center;
      gap: 40px;
      margin: 30px 0;
      padding: 20px 0;
      border-top: 1px solid rgba(255,255,255,0.3);
      border-bottom: 1px solid rgba(255,255,255,0.3);
    }
    
    .cover-info-item {
      text-align: center;
    }
    
    .cover-info-value {
      font-size: 36px;
      font-weight: 700;
      line-height: 1;
    }
    
    .cover-info-label {
      font-size: 14px;
      opacity: 0.85;
      margin-top: 5px;
    }
    
    .cover-footer {
      font-size: 14px;
      opacity: 0.8;
      margin-top: 40px;
    }

    /* ===== TABLE OF CONTENTS ===== */
    .toc {
      padding: 40px;
      page-break-after: always;
      background: #f8fafc;
      min-height: 100vh;
    }
    
    .toc-header {
      text-align: center;
      margin-bottom: 40px;
    }
    
    .toc h1 {
      font-size: 36px;
      font-weight: 800;
      margin: 0 0 10px 0;
      color: #1a1a2e;
    }
    
    .toc-subtitle {
      font-size: 18px;
      color: #64748b;
      font-weight: 400;
      margin: 0;
    }
    
    .toc-sections {
      max-width: 800px;
      margin: 0 auto;
      background: #ffffff;
      border-radius: 12px;
      box-shadow: 0 4px 20px rgba(0,0,0,0.08);
      overflow: hidden;
    }
    
    .toc-category {
      border-bottom: 2px solid #f1f5f9;
    }
    
    .toc-category:last-child {
      border-bottom: none;
    }
    
    .toc-category-title {
      font-size: 20px;
      font-weight: 700;
      color: #1a1a2e;
      padding: 20px 24px 10px;
      background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
    }
    
    .toc-list {
      list-style: none;
      padding: 0;
      margin: 0;
    }
    
    .toc-item {
      border-bottom: 1px solid #f1f5f9;
    }
    
    .toc-link {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 16px 24px;
      color: #475569;
      text-decoration: none;
      transition: all 0.2s ease;
    }
    
    .toc-link:hover {
      background: #f8fafc;
      color: #667eea;
      padding-left: 32px;
    }
    
    .toc-brand {
      font-size: 16px;
      font-weight: 600;
    }
    
    .toc-count {
      font-size: 14px;
      color: #94a3b8;
      background: #f1f5f9;
      padding: 4px 12px;
      border-radius: 20px;
      font-weight: 500;
    }

    /* ===== PAGES ===== */
    .page {
      padding: 40px;
      page-break-after: always;
      max-width: 190mm;
      margin: 0 auto;
      position: relative;
    }

    /* ===== BRAND DIVIDER ===== */
    .brand-divider {
      display: flex;
      align-items: center;
      gap: 16px;
      margin: 0 0 32px 0;
      padding: 20px 24px;
      background: linear-gradient(135deg, var(--brand-color, #1a1a2e) 0%, var(--brand-color-dark, #0f172a) 100%);
      color: #ffffff;
      border-radius: 12px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    }
    
    .brand-divider-logo {
      height: 40px;
      width: 40px;
      display: flex;
      align-items: center;
      justify-content: center;
      background: rgba(255,255,255,0.15);
      border-radius: 8px;
      font-size: 20px;
    }
    
    .brand-divider-text {
      font-size: 24px;
      font-weight: 800;
      letter-spacing: -0.5px;
    }
    
    .brand-divider-badge {
      margin-left: auto;
      font-size: 14px;
      background: rgba(255,255,255,0.2);
      padding: 6px 12px;
      border-radius: 20px;
      font-weight: 600;
    }

    /* ===== PRODUCT GRID ===== */
    .product-grid {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: ${gap}px;
      align-items: stretch;
    }

    /* ===== PRODUCT CARD ===== */
    .product-card {
      background: #ffffff;
      border: 1px solid #e2e8f0;
      border-radius: 16px;
      overflow: hidden;
      display: flex;
      flex-direction: column;
      box-shadow: 0 2px 8px rgba(0,0,0,0.06);
      transition: all 0.3s ease;
    }
    
    .product-card:hover {
      box-shadow: 0 8px 24px rgba(0,0,0,0.12);
      transform: translateY(-2px);
      border-color: #cbd5e1;
    }

    .product-image {
      background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
      position: relative;
      overflow: hidden;
    }
    
    .product-image img {
      width: 100%;
      height: ${imgH}px;
      object-fit: contain;
      display: block;
    }
    
    .product-price-overlay {
      position: absolute;
      right: 12px;
      bottom: 12px;
      background: linear-gradient(135deg, #1a1a2e 0%, #0f172a 100%);
      color: #ffffff;
      padding: 8px 14px;
      border-radius: 10px;
      font-size: 14px;
      font-weight: 700;
      box-shadow: 0 2px 8px rgba(0,0,0,0.3);
    }
    
    .product-content {
      padding: ${cardPadding}px;
      display: flex;
      flex-direction: column;
      gap: 10px;
      flex: 1;
    }

    .product-bilingual {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 12px;
    }

    .product-lang-column {
      padding: 12px;
      background: #f8fafc;
      border-radius: 10px;
      border: 1px solid #e2e8f0;
    }
    
    .product-lang-column.fr {
      direction: ltr;
      text-align: left;
    }
    
    .product-lang-column.ar {
      direction: rtl;
      text-align: right;
      font-family: 'Segoe UI', 'Arial', sans-serif;
    }

    .product-name {
      font-size: 15px;
      font-weight: 700;
      color: #1a1a2e;
      margin: 0 0 8px 0;
      line-height: 1.3;
    }
    
    .product-brand {
      font-size: 12px;
      color: #64748b;
      font-weight: 600;
      margin-bottom: 4px;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }

    .product-variants {
      display: flex;
      flex-wrap: wrap;
      gap: 6px;
      margin: 8px 0;
    }
    
    .variant-tag {
      display: inline-flex;
      align-items: center;
      padding: 4px 10px;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: #ffffff;
      border-radius: 20px;
      font-size: 11px;
      font-weight: 600;
    }

    .product-price {
      padding: 8px 12px;
      background: #fef3c7;
      border: 1px dashed #f59e0b;
      border-radius: 8px;
      color: #92400e;
      font-size: 13px;
      font-weight: 600;
      text-align: center;
    }
    
    .product-price.available {
      background: linear-gradient(135deg, #10b981 0%, #059669 100%);
      color: #ffffff;
      border: none;
    }

    .product-ref {
      font-size: 11px;
      color: #94a3b8;
      font-family: 'Courier New', monospace;
      padding-top: 6px;
    }

    /* ===== FOOTER & PAGINATION ===== */
    .page-footer {
      position: fixed;
      bottom: 0;
      left: 0;
      right: 0;
      padding: 20px 40px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      background: #ffffff;
      border-top: 1px solid #e2e8f0;
      font-size: 12px;
      color: #64748b;
    }
    
    .footer-info {
      display: flex;
      gap: 24px;
    }
    
    .footer-brand {
      font-weight: 700;
      color: #1a1a2e;
    }
    
    .footer-page {
      font-weight: 600;
      color: #667eea;
    }

    /* ===== PRINT OPTIMIZATION ===== */
    @page {
      size: A4;
      margin: 15mm;
    }
    
    @media print {
      html {
        font-size: 12pt;
      }
      
      .page-footer {
        position: fixed;
        bottom: 0;
      }
      
      .product-card {
        break-inside: avoid;
        page-break-inside: avoid;
      }
      
      .brand-divider {
        break-inside: avoid;
      }
      
      .product-grid {
        break-inside: avoid;
      }
      
      .cover {
        break-after: page;
      }
      
      .toc {
        break-after: page;
      }
      
      .page {
        break-after: page;
      }
      
      body {
        -webkit-print-color-adjust: exact;
        print-color-adjust: exact;
      }
    }
    
    /* ===== ARABIC FONT SUPPORT ===== */
    .arabic-text {
      font-family: 'Segoe UI', 'Arial', 'Times New Roman', sans-serif;
      font-size: 1.1em;
      line-height: 1.8;
    }

    /* ===== RESPONSIVE ===== */
    @media (max-width: 768px) {
      .product-grid {
        grid-template-columns: repeat(2, 1fr);
      }
      
      .cover h1 {
        font-size: 36px;
      }
      
      .cover-subtitle {
        font-size: 20px;
      }
    }
  `;
}

// ============================================
// GENERATE COVER
// ============================================

function generateCover(totalProducts, totalBrands) {
  const date = new Date().toLocaleDateString('fr-FR', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  return `
    <section class="cover">
      <div class="cover-content">
        <div style="font-size: 48px; margin-bottom: 20px; opacity: 0.9;">📚</div>
        <h1>Atlas Fournitures</h1>
        <p class="cover-subtitle">Catalogue Illustré Professionnel</p>
        
        <div class="cover-info">
          <div class="cover-info-item">
            <div class="cover-info-value">${totalProducts}</div>
            <div class="cover-info-label">Produits</div>
          </div>
          <div class="cover-info-item">
            <div class="cover-info-value">${totalBrands}</div>
            <div class="cover-info-label">Marques</div>
          </div>
          <div class="cover-info-item">
            <div class="cover-info-value">FR+AR</div>
            <div class="cover-info-label">Langues</div>
          </div>
        </div>
        
        <div class="cover-footer">
          <p>Catalogue bilingue français / arabe</p>
          <p>Édition du ${date}</p>
        </div>
      </div>
    </section>
  `;
}

// ============================================
// GENERATE TOC
// ============================================

function generateTOC(sections, electronicsSections) {
  const furnitureLinks = sections.map(s => `
    <li class="toc-item">
      <a href="#${slugify(`brand-${s.brand}`)}" class="toc-link">
        <span class="toc-brand">${s.brand}</span>
        <span class="toc-count">${s.items.length} produits</span>
      </a>
    </li>
  `).join('');

  const electronicsLinks = electronicsSections.map(s => `
    <li class="toc-item">
      <a href="#${slugify(`elec-${s.brand}`)}" class="toc-link">
        <span class="toc-brand">${s.brand}</span>
        <span class="toc-count">${s.items.length} produits</span>
      </a>
    </li>
  `).join('');

  return `
    <section class="toc">
      <div class="toc-header">
        <h1>Sommaire</h1>
        <p class="toc-subtitle">Table des matières complète</p>
      </div>
      
      <div class="toc-sections">
        <div class="toc-category">
          <div class="toc-category-title">🏢 Mobilier</div>
          <ul class="toc-list">
            ${furnitureLinks}
          </ul>
        </div>
        
        ${electronicsSections.length ? `
          <div class="toc-category">
            <div class="toc-category-title">💻 Électronique</div>
            <ul class="toc-list">
              ${electronicsLinks}
            </ul>
          </div>
        ` : ''}
      </div>
    </section>
  `;
}

// ============================================
// GENERATE PRODUCT CARD
// ============================================

function generateProductCard(product, brandColor, index) {
  const placeholder = createProfessionalPlaceholder(product.label, product.brand, index);
  
  const priceClass = product.price ? 'available' : '';
  const priceText = product.price 
    ? `${product.price} DH`
    : 'Prix sur demande';

  const variantsHTML = product.variants && product.variants.length 
    ? `<div class="product-variants">${product.variants.map(v => 
        `<span class="variant-tag">${v.kind}: ${v.value}</span>`
      ).join('')}</div>` 
    : '';

  return `
    <div class="product-card">
      <div class="product-image">
        <img alt="${product.label}" src="${placeholder}"/>
        ${product.price ? `<div class="product-price-overlay">${priceText}</div>` : ''}
      </div>
      <div class="product-content">
        <div class="product-bilingual">
          <div class="product-lang-column fr">
            <div class="product-brand">${product.brand}</div>
            <h3 class="product-name">${product.name_fr || product.label}</h3>
            ${variantsHTML}
            <div class="product-price ${priceClass}">${priceText}</div>
            <div class="product-ref">Réf: ${product.id}</div>
          </div>
          <div class="product-lang-column ar">
            <div class="product-brand">${product.brand}</div>
            <h3 class="product-name arabic-text">${product.name_ar || ''}</h3>
            ${variantsHTML}
            <div class="product-price ${priceClass}">${product.price ? `السعر: ${product.price} DH` : 'السعر: حسب الطلب'}</div>
            <div class="product-ref arabic-text">المرجع: ${product.id}</div>
          </div>
        </div>
      </div>
    </div>
  `;
}

// ============================================
// GENERATE BRAND SECTION
// ============================================

function generateBrandSection(section, brandColor, category) {
  const anchor = slugify(`${category}-${section.brand}`);
  const cards = section.items.map((item, idx) => generateProductCard(item, brandColor, idx)).join('');

  return `
    <div class="page" id="${anchor}" style="--brand-color: ${brandColor}; --brand-color-dark: ${adjustColor(brandColor, -20)};">
      <div class="brand-divider">
        <div class="brand-divider-logo">🏷️</div>
        <div class="brand-divider-text">${section.brand}</div>
        <div class="brand-divider-badge">${section.items.length}</div>
      </div>
      <div class="product-grid">
        ${cards}
      </div>
    </div>
  `;
}

// ============================================
// COLOR UTILITIES
// ============================================

function adjustColor(hex, amount) {
  const color = hex.replace('#', '');
  const num = parseInt(color, 16);
  const r = Math.min(255, Math.max(0, (num >> 16) + amount));
  const g = Math.min(255, Math.max(0, ((num >> 8) & 0x00FF) + amount));
  const b = Math.min(255, Math.max(0, (num & 0x0000FF) + amount));
  return `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1)}`;
}

// ============================================
// READ CONFIG
// ============================================

function readConfig() {
  const masterPath = path.join(CONFIG.outputDir, 'catalogue_master.json');
  const electronicsPath = path.join(CONFIG.outputDir, 'catalogue_electronics.json');
  const themesPath = path.join(CONFIG.outputDir, 'code.txt');
  const priorityPath = path.join(CONFIG.outputDir, 'brand_priority.json');
  const beautyPath = path.join(CONFIG.outputDir, 'beauty.txt');

  return {
    master: readJson(masterPath),
    electronics: readJsonIfExists(electronicsPath),
    themes: readJsonIfExists(themesPath) || {},
    priority: readJsonIfExists(priorityPath) || [],
    beauty: fs.existsSync(beautyPath)
  };
}

// ============================================
// MAIN GENERATION
// ============================================

async function main() {
  logger.info('Starting professional catalogue generation...');

  const config = readConfig();
  
  if (!config.master || !config.master.items) {
    throw new Error('Master catalogue not found or invalid');
  }

  logger.info(`Found ${config.master.items.length} products`);

  const be = config.beauty;
  const css = generateProfessionalCSS(be);

  // Get brand sections
  const sections = [];
  const byBrand = new Map();
  
  for (const item of config.master.items) {
    const brand = item.brand || 'Divers';
    if (!byBrand.has(brand)) byBrand.set(brand, []);
    byBrand.get(brand).push(item);
  }
  
  for (const [brand, items] of byBrand) {
    sections.push({ brand, items, category: 'brand' });
  }

  const electronicsSections = [];
  if (config.electronics && config.electronics.items) {
    const byBrandElec = new Map();
    for (const item of config.electronics.items) {
      const brand = item.brand || 'Divers';
      if (!byBrandElec.has(brand)) byBrandElec.set(brand, []);
      byBrandElec.get(brand).push(item);
    }
    for (const [brand, items] of byBrandElec) {
      electronicsSections.push({ brand, items, category: 'elec' });
    }
  }

  const totalProducts = config.master.items.length + (config.electronics?.items?.length || 0);
  const totalBrands = sections.length + electronicsSections.length;

  // Generate HTML
  let html = `<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="Atlas Fournitures - Catalogue professionnel bilingue">
  <title>Atlas Fournitures — Catalogue Professionnel</title>
  <style>${css}</style>
</head>
<body>`;

  // Cover
  html += generateCover(totalProducts, totalBrands);

  // TOC
  html += generateTOC(sections, electronicsSections);

  // Furniture sections
  for (const section of sections) {
    const brandColor = config.themes[section.brand.toUpperCase()]?.primary_color || '#667eea';
    html += generateBrandSection(section, brandColor, 'brand');
  }

  // Electronics sections
  for (const section of electronicsSections) {
    const brandColor = config.themes[section.brand.toUpperCase()]?.primary_color || '#764ba2';
    html += generateBrandSection(section, brandColor, 'elec');
  }

  // Footer
  html += `
    <div class="page-footer">
      <div class="footer-info">
        <span class="footer-brand">Atlas Fournitures</span>
        <span>•</span>
        <span>www.atlas-fournitures.com</span>
      </div>
      <span class="footer-page">Page <span class="page-number"></span></span>
    </div>

    <script>
      // Simple page numbering
      document.addEventListener('DOMContentLoaded', function() {
        const pageNumbers = document.querySelectorAll('.page');
        const numberEls = document.querySelectorAll('.page-number');
        numberEls.forEach((el, i) => {
          el.textContent = i + 1;
        });
      });
    </script>
  </body>
</html>`;

  // Write output
  const outputPath = path.join(CONFIG.outputDir, 'catalogue_full.html');
  writeText(outputPath, html);

  logger.info(`Catalogue generated: ${outputPath}`);
  logger.info(`Total: ${totalProducts} products, ${totalBrands} brands`);

  return {
    ok: true,
    outHtml: outputPath,
    count: totalProducts,
    sections: totalBrands,
    products: totalProducts
  };
}

// Run
main().catch(err => {
  logger.error('Fatal error:', err.message);
  console.error(JSON.stringify({ ok: false, error: err.message }));
  process.exit(1);
});
