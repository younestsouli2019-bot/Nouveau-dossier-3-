#!/usr/bin/env node

/**
 * ENHANCED Professional Catalogue Generator V4
 * 
 * Key Features:
 * - Professional product pages like e-commerce sites
 * - Smart image discovery with multiple strategies
 * - Professional typography and spacing
 * - Print-optimized layouts
 * - Product detail pages
 * - Responsive design
 * - Professional pricing display
 * - Color-coded categories
 */

import fs from "node:fs";
import path from "node:path";

// ============================================
// CONFIGURATION
// ============================================

const CONFIG = {
  outputDir: process.cwd(),
  catalogueDir: path.join(process.cwd(), 'catalogue'),
  imageDir: path.join(process.cwd(), 'catalogue', 'images_photos'),
  productsDir: path.join(process.cwd(), 'catalogue'),
  
  // Layout settings
  productsPerPage: 12,
  productColumns: 3,
  imageHeight: 300,
  
  // Color schemes
  colors: {
    primary: '#1a1a2e',
    secondary: '#4f46e5',
    accent: '#667eea',
    success: '#10b981',
    warning: '#f59e0b',
    danger: '#ef4444',
    light: '#f8fafc',
    dark: '#1e293b'
  },
  
  // Professional design
  spacing: {
    xs: 8,
    sm: 12,
    md: 16,
    lg: 24,
    xl: 32
  },
  
  borderRadius: {
    sm: 8,
    md: 12,
    lg: 16,
    xl: 20
  },
  
  shadows: {
    sm: '0 1px 3px rgba(0,0,0,0.1)',
    md: '0 4px 6px rgba(0,0,0,0.1)',
    lg: '0 10px 15px rgba(0,0,0,0.15)'
  }
};

// ============================================
// LOGGER
// ============================================

const logger = {
  info: (msg) => console.error(`[INFO] ${msg}`),
  warn: (msg) => console.error(`[WARN] ${msg}`),
  error: (msg) => console.error(`[ERROR] ${msg}`),
  debug: (msg) => process.env.DEBUG ? console.error(`[DEBUG] ${msg}`) : null
};

// ============================================
// IMAGE DISCOVERY SYSTEM
// ============================================

class ImageDiscovery {
  constructor(imageDir, productsDir) {
    this.imageDir = imageDir;
    this.productsDir = productsDir;
    this.imageCache = new Map();
    this.brandImages = new Map();
  }

  discoverImages(products) {
    logger.info(`Discovering images for ${products.length} products...`);
    
    const discovered = new Map();
    let foundCount = 0;
    let placeholderCount = 0;

    for (const product of products) {
      const image = this.findBestImage(product);
      
      if (image) {
        discovered.set(product.id, image);
        foundCount++;
        
        // Track by brand
        const brand = product.brand || 'Divers';
        if (!this.brandImages.has(brand)) {
          this.brandImages.set(brand, []);
        }
        this.brandImages.get(brand).push(image.path);
      } else {
        placeholderCount++;
        discovered.set(product.id, null);
      }
    }

    logger.info(`Image discovery complete: ${foundCount} found, ${placeholderCount} placeholders`);
    
    return {
      found: foundCount,
      placeholders: placeholderCount,
      matchRate: ((foundCount / products.length) * 100).toFixed(1),
      byBrand: this.getBrandStats()
    };
  }

  findBestImage(product) {
    // Strategy 1: Check cache
    if (this.imageCache.has(product.id)) {
      return this.imageCache.get(product.id);
    }

    const strategies = [
      this.tryExactIdMatch(product),
      this.tryProductBrandNameMatch(product),
      this.trySlugifiedNameMatch(product),
      this.tryPatternMatch(product),
      this.tryFuzzyMatch(product),
      this.tryCategoryMatch(product),
      this.tryBrandFolderMatch(product)
    ];

    for (const result of strategies) {
      if (result) {
        this.imageCache.set(product.id, result);
        return result;
      }
    }

    return null;
  }

  tryExactIdMatch(product) {
    const exts = ['.jpg', '.jpeg', '.png', '.webp'];
    
    for (const ext of exts) {
      const imagePath = path.join(this.imageDir, `${product.id}${ext}`);
      if (fs.existsSync(imagePath)) {
        const stats = fs.statSync(imagePath);
        if (stats.size > 5000 && stats.size < 10000000) {
          logger.debug(`Found image for ${product.id}: exact ID match`);
          return { path: imagePath, method: 'exact-id' };
        }
      }
    }
    
    return null;
  }

  tryProductBrandNameMatch(product) {
    const exts = ['.jpg', '.jpeg', '.png', '.webp'];
    const brandSlug = this.slugify(product.brand || '');
    const nameSlug = this.slugify(product.name_fr || product.label || '');
    
    for (const ext of exts) {
      const filename = `${brandSlug}-${nameSlug}${ext}`;
      const imagePath = path.join(this.imageDir, filename);
      
      if (fs.existsSync(imagePath)) {
        const stats = fs.statSync(imagePath);
        if (stats.size > 5000) {
          logger.debug(`Found image for ${product.id}: brand-name match`);
          return { path: imagePath, method: 'brand-name' };
        }
      }
    }
    
    return null;
  }

  trySlugifiedNameMatch(product) {
    const exts = ['.jpg', '.jpeg', '.png', '.webp'];
    const nameSlug = this.slugify(product.name_fr || product.label || '');
    
    for (const ext of exts) {
      const filename = `${nameSlug}${ext}`;
      const imagePath = path.join(this.imageDir, filename);
      
      if (fs.existsSync(imagePath)) {
        const stats = fs.statSync(imagePath);
        if (stats.size > 5000) {
          logger.debug(`Found image for ${product.id}: slugified name`);
          return { path: imagePath, method: 'slugified-name' };
        }
      }
    }
    
    return null;
  discovery complete: ${foundCount} found, ${placeholderCount} placeholders`;
  }

  tryPatternMatch(product) {
    const exts = ['.jpg', '.jpeg', '.png', '.webp'];
    
    // Try different naming patterns
    const patterns = [
      product.id,
      product.label,
      product.name_fr,
      product.id.replace(/[^a-zA-Z0-9]/g, ''),
      (product.brand || '') + '_' + (product.label || '')
    ];

    for (const pattern of patterns) {
      const slug = this.slugify(pattern);
      
      for (const ext of exts) {
        const filename = `${slug}${ext}`;
        const imagePath = path.join(this.imageDir, filename);
        
        if (fs.existsSync(imagePath)) {
          const stats = fs.statSync(imagePath);
          if (stats.size > 5000) {
            logger.debug(`Found image for ${product.id}: pattern match (${slug})`);
            return { path: imagePath, method: 'pattern' };
          }
        }
      }
    }
    }
    
    return null;
  }

  tryFuzzyMatch(product) {
    const exts = ['.jpg', '.jpeg', '.png', '.webp'];
    const productName = (product.name_fr || product.label || '').toLowerCase();
    
    // List all images
    const allImages = this.listAllImages();
    
    if (!allImages.length) return null;

    // Simple fuzzy matching
    const matches = [];
    for (const imgFile of allImages) {
      const imgName = path.basename(imgFile, path.extname(imgFile)).toLowerCase();
      const score = this.calculateFuzzyScore(productName, imgName);
      
      if (score > 0.6) {
        matches.push({ path: imgFile, score });
      }
    }

    if (matches.length > 0) {
      matches.sort((a, b) => b.score - a.score);
      const best = matches[0];
      
      logger.debug(`Found image for ${product.id}: fuzzy match (${best.score.toFixed(2)})`);
      return { path: best.path, method: 'fuzzy' };
    }
    
    return null;
  }

  tryCategoryMatch(product) {
    // Check for category-based image folders
    const category = this.slugify(product.category || 'general');
    const categoryDir = path.join(this.imageDir, category);
    
    if (!fs.existsSync(categoryDir)) return null;

    const exts = ['.jpg', '.jpeg', '.png', '.webp'];
    const nameSlug = this.slugify(product.name_fr || product.label || '');
    
    for (const ext of exts) {
      const filename = `${nameSlug}${ext}`;
      const imagePath = path.join(categoryDir, filename);
      
      if (fs.existsSync(imagePath)) {
        const stats = fs.statSync(imagePath);
        if (stats.size > 5000) {
          logger.debug(`Found image for ${product.id}: category match`);
          return { path: imagePath, method: 'category' };
        }
      }
    }
    
    return null;
  }

  tryBrandFolderMatch(product) {
    // Check for brand-specific folders
    const brand = product.brand || 'Divers';
    const brandSlug = this.slugify(brand);
    const brandDir = path.join(this.imageDir, brandSlug);
    
    if (!fs.existsSync(brandDir)) return null;

    const exts = ['.jpg', '.jpeg', '.png', '.webp'];
    const nameSlug = this.slugify(product.name_fr || product.label || '');
    
    for (const ext of exts) {
      const filename = `${nameSlug}${ext}`;
      const imagePath = path.join(brandDir, filename);
      
      if (fs.existsSync(imagePath)) {
        const stats = fs.statSync(imagePath);
        if (stats.size > 5000) {
          logger.debug(`Found image for ${product.id}: brand folder match`);
          return { path: imagePath, method: 'brand-folder' };
        }
      }
    }
    
    return null;
  }

  listAllImages() {
    const exts = ['.jpg', '.jpeg', '.png', '.webp'];
    const images = [];
    
    if (!fs.existsSync(this.imageDir)) return images;

    const entries = fs.readdirSync(this.imageDir, { withFileTypes: true });
    
    for (const entry of entries) {
      if (entry.isDirectory()) {
        // Skip directories, handled by category/brand matchers
        continue;
      }
      
      const ext = path.extname(entry.name).toLowerCase();
      if (!exts.includes(ext)) continue;
      
      const filePath = path.join(this.imageDir, entry.name);
      try {
        const stats = fs.statSync(filePath);
        if (stats.size > 5000 && stats.size < 10000000) {
          images.push(filePath);
        }
      } catch (err) {
        // Skip invalid files
      }
    }
    
    return images;
  }

  slugify(text) {
    if (!text) return '';
    return String(text)
      .toLowerCase()
      .normalize('NFKD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^\w\s-]+/g, '-')
      .replace(/[^\s-]+/g, '')
      .replace(/[-\s]+/g, '-')
      .slice(0, 80);
  }

  calculateFuzzyScore(name1, name2) {
    if (!name1 || !name2) return 0;
    name1 = name1.toLowerCase();
    name2 = name2.toLowerCase();
    
    if (name1 === name2) return 1;
    
    // Simple matching algorithm
    let matches = 0;
    const len1 = name1.length;
    const len2 = name2.length;
    
    for (let i = 0; i < len1 && i < len2; i++) {
      if (name1[i] === name2[i]) matches++;
    }
    
    const matchRatio = matches / Math.max(len1, len2);
    return matchRatio;
  }

  getBrandStats() {
    const stats = {};
    
    for (const [brand, images] of this.brandImages) {
      stats[brand] = {
        total: images.length,
        discovered: images.length
      };
    }
    
    return stats;
  }

  generatePlaceholder(product, index = 0) {
    const hues = [210, 150, 180, 200, 130, 160, 190, 220, 230, 250, 270];
    const hue = hues[index % hues.length];
    const hue2 = (hue + 40) % 360;
    
    const svg = encodeURIComponent(`
      <svg xmlns='http://www.w3.org/2000/svg' width='600' height='${CONFIG.imageHeight}' viewBox='0 0 600 ${CONFIG.imageHeight}'>
        <defs>
          <linearGradient id='bg' x1='0%' y1='0%' x2='100%' y2='100%'>
            <stop offset='0%' style='stop-color:hsl(${hue},75%,50%)'/>
            <stop offset='100%' style='stop-color:hsl(${hue2},75%,40%)'/>
          </linearGradient>
          <pattern id='grid' width='40' height='40' patternUnits='userSpaceOnUse'>
            <path d='M 40 0 L 0 0 0 40' fill='none' stroke='rgba(255,255,255,0.08)' stroke-width='0.5'/>
          </pattern>
          <filter id='shadow' x='-10%' y='-10%' width='120%' height='120%'>
            <feDropShadow dx='0' dy='4' stdDeviation='4' flood-opacity='0.15'/>
          </filter>
        </defs>
        
        <rect width='100%' height='100%' fill='url(#bg)'/>
        <rect width='100%' height='100%' fill='url(#grid)'/>
        
        <!-- Decorative elements -->
        <circle cx='500' cy='100' r='80' fill='rgba(255,255,255,0.05)'/>
        <circle cx='100' cy='${CONFIG.imageHeight - 80}' r='60' fill='rgba(255,255,255,0.05)'/>
        
        <!-- Product icon -->
        <g transform='translate(300, ${CONFIG.imageHeight / 2})' filter='url(#shadow)'>
          <circle r='50' fill='rgba(255,255,255,0.2)'/>
          <text x='0' y='15' text-anchor='middle' font-size='36' fill='#ffffff' font-weight='600'>📦</text>
        </g>
        
        <!-- Brand name -->
        ${product.brand ? `
          <text x='300' y='${CONFIG.imageHeight - 80}' text-anchor='middle' font-size='16' fill='rgba(255,255,255,0.85)' font-family='system-ui,sans-serif'>
            ${product.brand}
          </text>
        ` : ''}
        
        <!-- Product name -->
        <text x='300' y='${CONFIG.imageHeight - 50}' text-anchor='middle' font-size='22' fill='#ffffff' font-weight='700' font-family='system-ui,sans-serif'>
          ${this.truncateText(product.name_fr || product.label || "Product", 25)}
        </text>
        
        <!-- No image text -->
        <text x='300' y='${CONFIG.imageHeight - 30}' text-anchor='middle' font-size='14' fill='rgba(255,255,255,0.75)' font-family='system-ui,sans-serif'>
          Image not available
        </text>
        
        <!-- Border -->
        <rect x='30' y='30' width='540' height='${CONFIG.imageHeight - 60}' rx='16' fill='none' stroke='rgba(255,255,255,0.3)' stroke-width='3'/>
      </svg>
    `);
    
    return `data:image/svg+xml;charset=utf-8,${svg}`;
  }

  truncateText(text, maxLength) {
    if (!text) return '';
    if (text.length <= maxLength) return text;
    return text.substring(0, maxLength) + '...';
  }

  getRelativePath(imagePath) {
    return imagePath;
  }
}

// ============================================
// CATALOGUE GENERATOR
// ============================================

class CatalogueGenerator {
  constructor(config) {
    this.config = config;
    this.imageDiscovery = new ImageDiscovery(config.imageDir, config.productsDir);
  }

  async loadProducts() {
    const masterPath = path.join(this.config.productsDir, 'catalogue_master.json');
    const electronicsPath = path.join(this.config.productsDir, 'catalogue_electronics.json');
    
    const products = [];
    const electronics = [];
    
    try {
      if (fs.existsSync(masterPath)) {
        const data = JSON.parse(fs.readFileSync(masterPath, 'utf8'));
        products = data.items || [];
      }
      
      if (fs.existsSync(electronicsPath)) {
        const data = JSON.parse(fs.readFileSync(electronicsPath, 'utf8'));
        electronics = data.items || [];
      }
    } catch (err) {
      logger.error(`Failed to load products: ${err.message}`);
    }
    
    return { products, electronics };
  }

  async generate() {
    logger.info('Starting catalogue generation...');
    
    // Load products
    const { products, electronics } = await this.loadProducts();
    logger.info(`Loaded ${products.length} furniture + ${electronics.length} electronics products`);
    
    // Discover images
    const discoveryResult = this.imageDiscovery.discoverImages([...products, ...electronics]);
    
    // Generate HTML
    const html = this.generateCatalogueHTML(products, electronics, discoveryResult);
    
    // Write output
    const outputPath = path.join(this.config.catalogueDir, 'catalogue_full.html');
    fs.writeFileSync(outputPath, html);
    
    // Generate report
    const report = this.generateReport(products, electronics, discoveryResult);
    const reportPath = path.join(this.config.catalogueDir, 'report.json');
    fs.writeFileSync(reportPath, JSON.stringify(report, null, 2));
    
    logger.info(`Catalogue generated: ${outputPath}`);
    
    return {
      ok: true,
      outputPath,
      report,
      discovery: discoveryResult
    };
  }

  generateCatalogueHTML(products, electronics, discovery) {
    return `<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Atlas Fournitures — Catalogue Professionnel</title>
  <style>
    ${this.generateCSS()}
  </style>
</head>
<body>
  ${this.generateCover(products, electronics)}
  ${this.generateTOC(products, electronics)}
  ${this.generateProductSections(products, electronics, discovery)}
  ${this.generateFooter()}
</body>
</html>`;
  }

  generateCSS() {
    return `
      /* ===== RESET ===== */
      * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
      }
      
      html, body {
        margin: 0;
        padding: 0;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen', 'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue', sans-serif;
        background: ${CONFIG.colors.light};
        color: ${CONFIG.colors.dark};
        line-height: 1.6;
      }
      
      body {
        padding: 0;
      }
      
      /* ===== CONTAINER ===== */
      .container {
        max-width: 1400px;
        margin: 0 auto;
        padding: 0 ${CONFIG.spacing.lg}px;
      }
      
      /* ===== HEADER ===== */
      .header {
        background: linear-gradient(135deg, ${CONFIG.colors.primary} 0%, ${CONFIG.colors.accent} 100%);
        color: #ffffff;
        padding: ${CONFIG.spacing.lg}px ${CONFIG.spacing.md}px;
        text-align: center;
        box-shadow: ${CONFIG.shadows.lg};
      }
      
      .header h1 {
        font-size: 48px;
        font-weight: 800;
        margin: 0 0 ${CONFIG.spacing.md}px;
        letter-spacing: -1px;
      }
      
      .header p {
        font-size: 18px;
        opacity: 0.95;
        margin: 0;
      }
      
      /* ===== STATS ===== */
      .stats {
        display: flex;
        justify-content: center;
        gap: ${CONFIG.spacing.xl}px;
        margin: ${CONFIG.spacing.lg}px 0;
        flex-wrap: wrap;
      }
      
      .stat-item {
        text-align: center;
        padding: ${CONFIG.spacing.sm}px ${CONFIG.spacing.md}px;
        background: rgba(255,255,255,0.1);
        border-radius: ${CONFIG.borderRadius.md}px;
      }
      
      .stat-value {
        font-size: 36px;
        font-weight: 700;
        color: ${CONFIG.colors.accent};
        line-height: 1;
      }
      
      .stat-label {
        font-size: 14px;
        color: ${CONFIG.colors.dark};
        opacity: 0.7;
        margin-top: ${CONFIG.spacing.xs}px;
      }
      
      /* ===== SECTIONS ===== */
      .section {
        margin-bottom: ${CONFIG.spacing.xl}px;
      }
      
      .section-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: ${CONFIG.spacing.md}px ${CONFIG.spacing.lg}px;
        background: ${CONFIG.colors.light};
        border-radius: ${CONFIG.borderRadius.lg}px;
        margin-bottom: ${CONFIG.spacing.md}px;
        box-shadow: ${CONFIG.shadows.sm};
      }
      
      .section-title {
        font-size: 28px;
        font-weight: 700;
        color: ${CONFIG.colors.primary};
        display: flex;
        align-items: center;
        gap: ${CONFIG.spacing.md}px;
      }
      
      .section-count {
        font-size: 16px;
        background: ${CONFIG.colors.accent};
        color: #ffffff;
        padding: ${CONFIG.spacing.sm}px ${CONFIG.spacing.md}px;
        border-radius: ${CONFIG.borderRadius.full}px;
        font-weight: 600;
      }
      
      /* ===== PRODUCT GRID ===== */
      .product-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
        gap: ${CONFIG.spacing.lg}px;
      }
      
      /* ===== PRODUCT CARD ===== */
      .product-card {
        background: #ffffff;
        border-radius: ${CONFIG.borderRadius.lg}px;
        overflow: hidden;
        box-shadow: ${CONFIG.shadows.md};
        transition: all 0.3s ease;
        display: flex;
        flex-direction: column;
      }
      
      .product-card:hover {
        transform: translateY(-4px);
        box-shadow: ${CONFIG.shadows.lg};
      }
      
      .product-image {
        background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
        position: relative;
        overflow: hidden;
      }
      
      .product-image img {
        width: 100%;
        height: ${CONFIG.imageHeight}px;
        object-fit: contain;
        display: block;
        transition: all 0.3s ease;
      }
      
      .product-image:hover img {
        transform: scale(1.05);
      }
      
      .product-badge {
        position: absolute;
        top: ${CONFIG.spacing.md}px;
        right: ${CONFIG.spacing.md}px;
        background: ${CONFIG.colors.success};
        color: #ffffff;
        padding: ${CONFIG.spacing.sm}px ${CONFIG.spacing.md}px;
        border-radius: ${CONFIG.borderRadius.full}px;
        font-size: 12px;
        font-weight: 600;
      }
      
      .product-content {
        padding: ${CONFIG.spacing.md}px;
        flex: 1;
        flex-direction: column;
        gap: ${CONFIG.spacing.sm}px;
      }
      
      .product-brand {
        font-size: 11px;
        color: ${CONFIG.colors.dark};
        text-transform: uppercase;
        letter-spacing: 0.5px;
        margin-bottom: ${CONFIG.spacing.xs}px;
        opacity: 0.7;
      }
      
      .product-name {
        font-size: 18px;
        font-weight: 700;
        color: ${CONFIG.colors.primary};
        margin: 0 0 ${CONFIG.spacing.sm}px;
        line-height: 1.3;
      }
      
      .product-description {
        font-size: 14px;
        color: ${CONFIG.colors.dark};
        line-height: 1.5;
        opacity: 0.85;
        margin-bottom: ${CONFIG.spacing.sm}px;
      }
      
      .product-specs {
        display: flex;
        flex-wrap: wrap;
        gap: ${CONFIG.spacing.xs}px;
        margin-top: ${CONFIG.spacing.sm}px;
      }
      
      .spec-item {
        display: flex;
        align-items: center;
        gap: ${CONFIG.spacing.xs}px;
        padding: ${CONFIG.spacing.xs}px ${CONFIG.spacing.sm}px;
        background: ${CONFIG.colors.light};
        border-radius: ${CONFIG.borderRadius.md}px;
        font-size: 13px;
      }
      
      .spec-label {
        color: ${CONFIG.colors.dark};
        opacity: 0.6;
        font-size: 12px;
      }
      
      .spec-value {
        font-weight: 600;
        color: ${CONFIG.colors.primary};
      }
      
      .product-price {
        font-size: 24px;
        font-weight: 700;
        color: ${CONFIG.colors.success};
        margin-top: ${CONFIG.spacing.sm}px;
        padding: ${CONFIG.spacing.md}px;
        background: linear-gradient(135deg, ${CONFIG.colors.success} 0%, ${CONFIG.colors.success} 0%, #059669 100%);
        color: #ffffff;
        text-align: center;
        border-radius: ${CONFIG.borderRadius.md}px;
      }
      
      .product-price small {
        font-size: 14px;
        padding: ${CONFIG.spacing.sm}px ${CONFIG.spacing.md}px;
      }
      
      .product-ref {
        font-size: 11px;
        color: ${CONFIG.colors.dark};
        opacity: 0.6;
        font-family: 'Courier New', monospace;
      }
      
      /* ===== FOOTER ===== */
      .footer {
        background: ${CONFIG.colors.primary};
        color: #ffffff;
        padding: ${CONFIG.spacing.lg}px ${CONFIG.spacing.md}px;
        text-align: center;
        margin-top: ${CONFIG.spacing.xl}px;
      }
      
      .footer p {
        margin: ${CONFIG.spacing.xs}px 0;
        opacity: 0.9;
      }
      
      /* ===== RESPONSIVE ===== */
      @media (max-width: 768px) {
        .product-grid {
          grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
        }
        
        .header h1 {
          font-size: 32px;
        }
        
        .stat-value {
          font-size: 28px;
        }
      }
      
      @media (max-width: 480px) {
        .product-grid {
          grid-template-columns: 1fr;
        }
        
        .stats {
          flex-direction: column;
        }
      }
      
      /* ===== PRINT ===== */
      @media print {
        body {
          background: white;
        color: black;
        }
        
        .header {
          background: ${CONFIG.colors.primary};
          box-shadow: none;
        }
        
        .product-card {
          box-shadow: none;
          break-inside: avoid;
        }
        
        .product-grid {
          break-inside: avoid;
        }
        
        @page {
          size: A4;
          margin: 1cm;
        }
      }
    `;
  }

  generateCover(products, electronics) {
    const totalProducts = products.length + electronics.length;
    const totalBrands = new Set([...products, ...electronics].map(p => p.brand)).size;
    const totalColors = new Set([...products, ...electronics].map(p => p.variants?.[0]?.value || '')).size;

    return `
      <header class="header">
        <h1>🏪 Atlas Fournitures</h1>
        <p>Catalogue Professionnel 2026</p>
        <div class="stats">
          <div class="stat-item">
            <div class="stat-value">${totalProducts}</div>
            <div class="stat-label">Produits</div>
          </div>
          <div class="stat-item">
            <div class="stat-value">${totalBrands}</div>
            <div class="stat-label">Marques</div>
          </div>
          <div class="stat-item">
            <div class="stat-value">FR+AR</div>
            <div class="stat-label">Langues</div>
          </div>
          <div class="stat-item">
            <div class="stat-value">${totalColors}</div>
            <div class="stat-label">Couleurs</div>
          </div>
        </div>
      </header>
    `;
  }

  generateTOC(products, electronics) {
    const byBrand = new Map();
    
    for (const product of products) {
      const brand = product.brand || 'Divers';
      if (!byBrand.has(brand)) byBrand.set(brand, []);
      byBrand.get(brand).push(product);
    }
    
    for (const product of electronics) {
      const brand = product.brand || 'Divers';
      if (!byBrand.has(brand)) byBrand.set(brand, []);
      byBrand.get(brand).push(product);
    }
    
    const brands = Array.from(byBrand.entries()).sort((a, b) => a[0].localeCompare(b[0]));
    
    const furnitureLinks = brands.filter(([brand]) => brand !== 'Divers').map(([brand, items]) => 
      `<li><a href="#furniture-${brand.toLowerCase()}">${brand} <span>(${items.length})</span></a></li>`
    ).join('');
    
    const electronicsLinks = brands.filter(([brand]) => brand !== 'Divers').map(([brand, items]) => 
      `<li><a href="#electronics-${brand.toLowerCase()}">${brand} <span>(${items.length})</span></a></li>`
    ).join('');
    
    return `
      <section class="section">
        <div class="section-header">
          <div class="section-title">📋 Sommaire</div>
          <div class="section-count">${brands.length} marques</div>
        </div>
        
        <h2>🏢 Mobilier</h2>
        <ul>
          ${furnitureLinks}
          <li><a href="#electronics">💻 Électronique</a></li>
          <li><a href="#divers">📦 Divers</a></li>
        </ul>
      </section>
    `;
  }

  generateProductSections(products, electronics, discovery) {
    const sections = [];
    
    // Group by brand
    const byBrand = new Map();
    
    for (const product of [...products, ...electronics]) {
      const brand = product.brand || 'Divers';
      if (!byBrand.has(brand)) {
        byBrand.set(brand, []);
      }
      byBrand.get(brand).push(product);
    }
    
    const brandSections = Array.from(byBrand.entries());
    
    // Generate furniture sections
    for (const [brand, brandProducts] of brandSections) {
      sections.push(this.generateBrandSection(brand, brandProducts, 'furniture', discovery));
    }
    
    return sections.join('');
  }

  generateBrandSection(brand, products, type, discovery) {
    const slug = brand.toLowerCase().replace(/[^a-z0-9]/g, '');
    
    const productCards = products.map((product, index) => {
      const hasImage = discovery.found > 0;
      const image = hasImage ? this.imageDiscovery.findBestImage(product) : null;
      const placeholder = this.imageDiscovery.generatePlaceholder(product, index);
      const imageSrc = image ? 
        `file:///${this.imageDiscovery.getRelativePath(image.path)}` : 
        placeholder;
      
      return `
        <div class="product-card">
          ${product.price && hasImage ? `<div class="product-badge">En Stock</div>` : ''}
          <div class="product-image">
            <img src="${imageSrc}" alt="${product.label}" loading="lazy" onerror="this.src='data:image/svg+xml;base64,PHN2ZyBvcmlnaWQgc3R0cmV0.9MCAwIDALOIAWQgc3R'"/>
          </div>
          <div class="product-content">
            <div class="product-brand">${product.brand || 'Divers'}</div>
            <h2 class="product-name">${product.name_fr || product.label}</h2>
            ${product.description ? `<p class="product-description">${product.description}</p>` : ''}
            
            <div class="product-specs">
              ${product.variants && product.variants.length ? product.variants.map(v => `
                <div class="spec-item">
                  <span class="spec-label">${v.kind}:</span>
                  <span class="spec-value">${v.value}</span>
                </div>
              `).join('') : ''}
            </div>
            
            <div class="product-ref">Réf: ${product.id}</div>
            
            ${product.price ? `
              <div class="product-price">${product.price} DH</div>
            ` : ''}
          </div>
        </div>
      `;
    }).join('');
  }

  generateFooter() {
    const year = new Date().getFullYear();
    
    return `
      <footer>
        <p>© ${year} Atlas Fournitures — Catalogue Professionnel</p>
        <p>Tous droits réservés</p>
        <p>Contactez-nous pour vos commandes</p>
      </footer>
    `;
  }

  generateReport(products, electronics, discovery) {
    const totalProducts = products.length + electronics.length;
    
    return {
      generation: {
        timestamp: new Date().toISOString(),
        totalProducts,
        furniture: products.length,
        electronics: electronics.length,
        imageDiscovery: discovery
      },
      statistics: discovery.byBrand,
      recommendations: this.getRecommendations(discovery)
    };
  }

  getRecommendations(discovery) {
    const recommendations = [];
    
    // Find brands with low match rates
    for (const [brand, stats] of Object.entries(discovery.byBrand)) {
      const matchRate = (stats.discovered / stats.total) * 100;
      if (matchRate < 50 && stats.total > 5) {
        recommendations.push({
          type: 'low-image-match',
          brand,
          matchRate: matchRate.toFixed(1) + '%',
          message: `Only ${matchRate.toFixed(0)}% of ${brand} products have images. Consider renaming image files.`,
          priority: 'high'
        });
      }
    }
    
    // Check for large brands without images
    for (const [brand, stats] of Object.entries(discovery.byBrand)) {
      if (stats.discovered === 0 && stats.total > 10) {
        recommendations.push({
          type: 'no-images',
          brand,
          matchRate: '0%',
          message: `${brand} has ${stats.total} products but no images found. Create an image folder structure.`,
          priority: 'critical'
        });
      }
    }
    
    return recommendations;
  }
}

// ============================================
// MAIN
// ============================================

async function main() {
  console.error('='.repeat(60));
  console.error('ENHANCED PROFESSIONAL CATALOGUE GENERATOR V4');
  console.error('='.repeat(60));
  
  const generator = new CatalogueGenerator(CONFIG);
  
  const result = await generator.generate();
  
  console.error('');
  console.error('✓ Catalogue generated successfully!');
  console.error(`  Output: ${result.outputPath}`);
  console.error(`  Report: ${path.join(CONFIG.catalogueDir, 'report.json')}`);
  console.error('');
  console.error('Image Discovery:');
  console.error(`  Found: ${result.discovery.found} images`);
  console.error(`  Match Rate: ${result.discovery.matchRate}%`);
  console.error(`  By Brand:`);
  console.error(JSON.stringify(result.discovery.byBrand, null, 2));
  console.error('');
  
  if (result.discovery.recommendations.length > 0) {
    console.error('⚠️  Recommendations:');
    for (const rec of result.discovery.recommendations) {
      console.error(`  [${rec.priority.toUpperCase()}] ${rec.message}`);
    }
    console.error('');
  }
  
  process.exit(0);
}

// Run
main().catch(err => {
  console.error('');
  console.error('❌ Error:', err.message);
  console.error('');
  process.exit(1);
});
