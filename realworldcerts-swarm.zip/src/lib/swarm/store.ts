"use client";

import { create } from "zustand";
import type {
  PipelineRun,
  NodeId,
  NodeStatus,
  SceneSpec,
  GeneratedFrame,
  GeneratedAudio,
  TriageResult,
  PublishLayer,
  AspectRatio,
} from "./types";
import { ANTITAKEDOWN_LAYERS } from "./data";

// Deterministic SVG gradient thumbnail (tiny data URL) so seeded drafts
// render a real-looking preview without hitting the generation API.
function svgThumb(label: string, index: number): string {
  const hues = [160, 35, 280, 200, 12, 320];
  const h1 = hues[index % hues.length];
  const h2 = hues[(index + 2) % hues.length];
  const initials = label
    .split(" ")
    .slice(0, 3)
    .map((w) => w[0])
    .join("")
    .toUpperCase();
  const svg = `<svg xmlns='http://www.w3.org/2000/svg' width='640' height='360'>
  <defs><linearGradient id='g' x1='0' y1='0' x2='1' y2='1'>
  <stop offset='0' stop-color='hsl(${h1} 70% 28%)'/>
  <stop offset='1' stop-color='hsl(${h2} 70% 18%)'/></linearGradient></defs>
  <rect width='640' height='360' fill='url(#g)'/>
  <text x='24' y='330' font-family='monospace' font-size='20' fill='rgba(255,255,255,0.55)'>RWC · SCENE ${index + 1}</text>
  <text x='24' y='70' font-family='sans-serif' font-weight='bold' font-size='30' fill='white'>${initials}</text>
  <rect x='24' y='86' width='60' height='4' fill='hsl(${h1} 80% 60%)'/>
  </svg>`;
  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

function emptyNodes(): Record<NodeId, NodeStatus> {
  return {
    recon: "idle",
    gen_matrix: "idle",
    triage: "idle",
    assemble: "idle",
    publish: "idle",
    self_improve: "idle",
  };
}

let counter = 0;
function uid(prefix = "run"): string {
  counter += 1;
  return `${prefix}_${Date.now().toString(36)}_${counter}`;
}

function makeSeedDraft(opts: {
  brief: string;
  aspect: AspectRatio;
  model: string;
  ageMin: number;
  score: number;
  verdict: TriageResult["verdict"];
}): PipelineRun {
  const createdAt = Date.now() - opts.ageMin * 60_000;
  const scenes: SceneSpec[] = [
    {
      id: uid("sc"),
      index: 0,
      shot: "Opening — brand mark over dark mesh gradient",
      visual_prompt:
        "Dark cinematic mesh gradient, emerald and amber, RealWorldCerts wordmark fading in, 16:9",
      narration: "RealWorldCerts — certification that actually means something.",
      duration_sec: 4,
    },
    {
      id: uid("sc"),
      index: 1,
      shot: "Hands typing, code on screen, credentials stacking",
      visual_prompt:
        "Close-up hands on mechanical keyboard, green terminal text reflecting on glasses, shallow depth of field",
      narration: "Built by engineers who passed the exams they now write about.",
      duration_sec: 5,
    },
    {
      id: uid("sc"),
      index: 2,
      shot: "Logo lockup + CTA",
      visual_prompt:
        "Minimal end card, RealWorldCerts logo, emerald glow, 'Start free' call to action",
      narration: "Start free at realworldcerts.com.",
      duration_sec: 3,
    },
  ];
  const frames: GeneratedFrame[] = scenes.map((s) => ({
    sceneId: s.id,
    index: s.index,
    shot: s.shot,
    dataUrl: svgThumb(s.shot, s.index),
    prompt: s.visual_prompt,
  }));
  const triage: TriageResult = {
    score: opts.score,
    verdict: opts.verdict,
    notes:
      opts.verdict === "approve"
        ? "Strong brand fit; pacing on beat; caption alignment clean. Ready for approval gate."
        : "Composition slightly busy on scene 2; consider tighter crop. Borderline — human review.",
    scores: {
      clarity: Math.min(100, opts.score + 4),
      brand_fit: Math.min(100, opts.score + 2),
      composition: Math.max(40, opts.score - 6),
      pacing: Math.min(100, opts.score + 1),
    },
  };
  return {
    id: uid("run"),
    brief: opts.brief,
    aspect: opts.aspect,
    model: opts.model,
    createdAt,
    status: "draft",
    iteration: 1,
    nodes: {
      recon: "done",
      gen_matrix: "done",
      triage: "done",
      assemble: "done",
      publish: "idle",
      self_improve: "idle",
    },
    sceneSpecs: scenes,
    frames,
    audio: [], // seeded drafts have no live audio — re-run to regenerate
    triage,
    publishLayers: ANTITAKEDOWN_LAYERS.map((l) => ({ ...l, status: "pending" as const })),
    assembledMp4Name: `rwc_promo_${createdAt.toString(36)}.mp4`,
    baselineNote: "Seeded draft — baseline JSON not yet updated.",
    durationMs: 0,
  };
}

function makePublishedHistory(opts: {
  brief: string;
  model: string;
  ageMin: number;
  score: number;
  clips: number;
}): PipelineRun {
  const createdAt = Date.now() - opts.ageMin * 60_000;
  return {
    id: uid("run"),
    brief: opts.brief,
    aspect: "16:9",
    model: opts.model,
    createdAt,
    status: "published",
    iteration: 1,
    nodes: {
      recon: "done",
      gen_matrix: "done",
      triage: "done",
      assemble: "done",
      publish: "done",
      self_improve: "done",
    },
    sceneSpecs: [],
    frames: [],
    audio: [],
    triage: {
      score: opts.score,
      verdict: "approve",
      notes: "Auto-published by triage threshold.",
      scores: { clarity: 90, brand_fit: 92, composition: 88, pacing: 91 },
    },
    publishLayers: ANTITAKEDOWN_LAYERS.map((l) => ({ ...l, status: "pinned" as const })),
    assembledMp4Name: `rwc_${createdAt.toString(36)}.mp4`,
    baselineNote: "Baseline updated: +1 to 'emerald-mesh' prompt family.",
    durationMs: 0,
  };
}

interface SwarmState {
  runs: PipelineRun[];
  activeRunId: string | null;
  baseline: {
    totalRuns: number;
    avgScore: number;
    suppressedPrompts: string[];
    topPromptFamilies: { name: string; avg: number; count: number }[];
  };

  createRun: (brief: string, aspect: AspectRatio, model: string) => string;
  setActiveRun: (id: string | null) => void;
  setNodeStatus: (id: string, node: NodeId, status: NodeStatus) => void;
  setSceneSpecs: (id: string, specs: SceneSpec[]) => void;
  addFrames: (id: string, frames: GeneratedFrame[]) => void;
  addAudio: (id: string, audio: GeneratedAudio[]) => void;
  setTriage: (id: string, triage: TriageResult) => void;
  finalizeAssemble: (id: string, mp4Name: string, durationMs: number) => void;
  setPublishLayers: (id: string, layers: PublishLayer[]) => void;
  setBaselineNote: (id: string, note: string) => void;
  approve: (id: string) => void;
  reject: (id: string) => void;
  publish: (id: string) => void;
  removeRun: (id: string) => void;
  reset: () => void;
}

const SEED_RUNS: PipelineRun[] = [
  makePublishedHistory({
    brief: "AWS Cloud Practitioner — 15s promo",
    model: "wan22",
    ageMin: 640,
    score: 91,
    clips: 1,
  }),
  makePublishedHistory({
    brief: "Security+ — dark visualiser",
    model: "hunyuan15",
    ageMin: 980,
    score: 88,
    clips: 1,
  }),
  makePublishedHistory({
    brief: "Terraform Associate — vertical TikTok",
    model: "wan22",
    ageMin: 1450,
    score: 94,
    clips: 1,
  }),
  makeSeedDraft({
    brief: "RealWorldCerts — brand launch 16:9",
    aspect: "16:9",
    model: "wan22",
    ageMin: 4,
    score: 87,
    verdict: "approve",
  }),
  makeSeedDraft({
    brief: "CKA exam prep — vertical 9:16",
    aspect: "9:16",
    model: "hunyuan15",
    ageMin: 11,
    score: 72,
    verdict: "borderline",
  }),
];

const SEED_BASELINE = {
  totalRuns: 312,
  avgScore: 84.6,
  suppressedPrompts: ["busy-office-pan", "white-bg-product"],
  topPromptFamilies: [
    { name: "emerald-mesh", avg: 91, count: 64 },
    { name: "terminal-closeup", avg: 88, count: 51 },
    { name: "dark-visualiser", avg: 86, count: 43 },
    { name: "end-card-minimal", avg: 90, count: 38 },
  ],
};

export const useSwarm = create<SwarmState>((set) => ({
  runs: SEED_RUNS,
  activeRunId: null,
  baseline: SEED_BASELINE,

  createRun: (brief, aspect, model) => {
    const id = uid("run");
    const run: PipelineRun = {
      id,
      brief,
      aspect,
      model,
      createdAt: Date.now(),
      status: "running",
      iteration: 1,
      nodes: emptyNodes(),
      sceneSpecs: [],
      frames: [],
      audio: [],
      triage: null,
      publishLayers: [],
      assembledMp4Name: "",
      baselineNote: "",
      durationMs: 0,
    };
    set((s) => ({ runs: [run, ...s.runs], activeRunId: id }));
    return id;
  },
  setActiveRun: (id) => set({ activeRunId: id }),
  setNodeStatus: (id, node, status) =>
    set((s) => ({
      runs: s.runs.map((r) =>
        r.id === id ? { ...r, nodes: { ...r.nodes, [node]: status } } : r
      ),
    })),
  setSceneSpecs: (id, specs) =>
    set((s) => ({
      runs: s.runs.map((r) => (r.id === id ? { ...r, sceneSpecs: specs } : r)),
    })),
  addFrames: (id, frames) =>
    set((s) => ({
      runs: s.runs.map((r) =>
        r.id === id ? { ...r, frames: [...r.frames, ...frames] } : r
      ),
    })),
  addAudio: (id, audio) =>
    set((s) => ({
      runs: s.runs.map((r) =>
        r.id === id ? { ...r, audio: [...r.audio, ...audio] } : r
      ),
    })),
  setTriage: (id, triage) =>
    set((s) => ({
      runs: s.runs.map((r) => (r.id === id ? { ...r, triage } : r)),
    })),
  finalizeAssemble: (id, mp4Name, durationMs) =>
    set((s) => ({
      runs: s.runs.map((r) =>
        r.id === id
          ? { ...r, assembledMp4Name: mp4Name, durationMs }
          : r
      ),
    })),
  setPublishLayers: (id, layers) =>
    set((s) => ({
      runs: s.runs.map((r) => (r.id === id ? { ...r, publishLayers: layers } : r)),
    })),
  setBaselineNote: (id, note) =>
    set((s) => ({
      runs: s.runs.map((r) => (r.id === id ? { ...r, baselineNote: note } : r)),
    })),
  approve: (id) =>
    set((s) => ({
      runs: s.runs.map((r) =>
        r.id === id ? { ...r, status: "approved", nodes: { ...r.nodes, publish: "running" } } : r
      ),
    })),
  reject: (id) =>
    set((s) => ({
      runs: s.runs.map((r) =>
        r.id === id ? { ...r, status: "rejected" } : r
      ),
    })),
  publish: (id) =>
    set((s) => ({
      runs: s.runs.map((r) =>
        r.id === id
          ? {
              ...r,
              status: "published",
              nodes: {
                ...r.nodes,
                publish: "done",
                self_improve: "done",
              },
              publishLayers: (r.publishLayers.length
                ? r.publishLayers
                : ANTITAKEDOWN_LAYERS
              ).map((l) => ({ ...l, status: "pinned" as const })),
            }
          : r
      ),
    })),
  removeRun: (id) =>
    set((s) => ({
      runs: s.runs.filter((r) => r.id !== id),
      activeRunId: s.activeRunId === id ? null : s.activeRunId,
    })),
  reset: () => set({ runs: SEED_RUNS, activeRunId: null, baseline: SEED_BASELINE }),
}));

export { svgThumb };
