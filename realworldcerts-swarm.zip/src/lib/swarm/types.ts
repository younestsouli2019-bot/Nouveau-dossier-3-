// RealWorldCerts Unified Swarm — core domain types
// Mirrors the PromoAgentState from the architecture PDF and the
// Metiutek Unified Engine capability registry from the AIM brief.

export type AspectRatio = "16:9" | "9:16" | "1:1";

export type NodeId =
  | "recon"
  | "gen_matrix"
  | "triage"
  | "assemble"
  | "publish"
  | "self_improve";

export type NodeStatus = "idle" | "running" | "done" | "error" | "skipped";

export interface SwarmNode {
  id: NodeId;
  label: string;
  cybershield: string;
  script: string;
  description: string;
  runtime: string;
}

export interface SceneSpec {
  id: string;
  index: number;
  shot: string;
  visual_prompt: string;
  narration: string;
  duration_sec: number;
}

export interface GeneratedFrame {
  sceneId: string;
  index: number;
  shot: string;
  dataUrl: string;
  prompt: string;
}

export interface GeneratedAudio {
  sceneId: string;
  narration: string;
  dataUrl: string;
  voice: string;
  durationSec: number;
}

export interface TriageResult {
  score: number;
  verdict: "approve" | "borderline" | "reject";
  notes: string;
  scores: {
    clarity: number;
    brand_fit: number;
    composition: number;
    pacing: number;
  };
}

export interface PublishLayer {
  layer: "I-Legal" | "II-Host" | "III-Discovery" | "IV-Decentralised";
  original: string;
  adapted: string;
  target: string;
  status: "pinned" | "pending" | "failed";
  ref: string;
}

export interface PipelineRun {
  id: string;
  brief: string;
  aspect: AspectRatio;
  model: string;
  createdAt: number;
  status: "draft" | "approved" | "rejected" | "published" | "running";
  iteration: number;
  nodes: Record<NodeId, NodeStatus>;
  sceneSpecs: SceneSpec[];
  frames: GeneratedFrame[];
  audio: GeneratedAudio[];
  triage: TriageResult | null;
  publishLayers: PublishLayer[];
  assembledMp4Name: string;
  baselineNote: string;
  durationMs: number;
}

export interface ServiceCapability {
  id: string;
  name: string;
  engine: string;
  port: number;
  role: string;
  capabilities: string[];
  status: "online" | "degraded" | "offline";
  vram: string;
  mcpCommand: string;
  mcpArgs: string[];
}

export interface MCPServer {
  name: string;
  command: string;
  args: string[];
  description: string;
  toolCount: number;
}

export interface ModelEntry {
  id: string;
  name: string;
  params: string;
  precision: string;
  minVram: string;
  licence: string;
  commercial: "full" | "restricted" | "excluded";
  restrictionNote: string;
  source: string;
  role: "video" | "audio" | "tooling";
  primary?: boolean;
}

export interface ScriptEntry {
  script: string;
  status: "extend" | "new";
  purpose: string;
  deps: string;
}

export interface DockerService {
  name: string;
  image: string;
  port: string;
  purpose: string;
  gpu: boolean;
  volume: string;
}
