import ZAI from "z-ai-web-dev-sdk";

let _zai: Awaited<ReturnType<typeof ZAI.create>> | null = null;

export async function getZai() {
  if (!_zai) {
    _zai = await ZAI.create();
  }
  return _zai;
}

// Strip markdown code fences and find the first JSON object/array in an LLM reply.
export function extractJson<T = unknown>(text: string): T | null {
  if (!text) return null;
  let t = text.trim();
  // remove ```json ... ``` or ``` ... ``` fences
  t = t.replace(/^```(?:json)?\s*/i, "").replace(/```$/i, "").trim();
  // try direct parse
  try {
    return JSON.parse(t) as T;
  } catch {
    // fall through
  }
  // find first { ... } or [ ... ]
  const start = t.search(/[\[{]/);
  if (start === -1) return null;
  const open = t[start];
  const close = open === "{" ? "}" : "]";
  let depth = 0;
  let inStr = false;
  let esc = false;
  for (let i = start; i < t.length; i++) {
    const c = t[i];
    if (inStr) {
      if (esc) esc = false;
      else if (c === "\\") esc = true;
      else if (c === '"') inStr = false;
      continue;
    }
    if (c === '"') inStr = true;
    else if (c === open) depth++;
    else if (c === close) {
      depth--;
      if (depth === 0) {
        const slice = t.slice(start, i + 1);
        try {
          return JSON.parse(slice) as T;
        } catch {
          return null;
        }
      }
    }
  }
  return null;
}

export async function llmJson<T = unknown>(
  systemPrompt: string,
  userPrompt: string,
  opts: { thinking?: boolean } = {}
): Promise<T> {
  const zai = await getZai();
  const completion = await zai.chat.completions.create({
    messages: [
      { role: "assistant", content: systemPrompt },
      { role: "user", content: userPrompt },
    ],
    thinking: { type: opts.thinking ? "enabled" : "disabled" },
  });
  const content = completion.choices[0]?.message?.content ?? "";
  const parsed = extractJson<T>(content);
  if (!parsed) throw new Error("LLM did not return parseable JSON: " + content.slice(0, 200));
  return parsed;
}
