"use client";

import { useState, useMemo } from "react";
import {
  LayoutDashboard,
  Workflow,
  ShieldCheck,
  Boxes,
  Scale,
  Network,
  Container,
  Github,
  Cpu,
  Zap,
} from "lucide-react";
import { OverviewSection } from "@/components/swarm/sections/overview";
import { PipelineSection } from "@/components/swarm/sections/pipeline";
import { ApprovalSection } from "@/components/swarm/sections/approval-gate";
import { CapabilitiesSection } from "@/components/swarm/sections/capabilities";
import { ModelMatrixSection } from "@/components/swarm/sections/model-matrix";
import { AntiTakedownSection } from "@/components/swarm/sections/antitakedown";
import { TopologySection } from "@/components/swarm/sections/topology";
import { ThemeToggle } from "@/components/swarm/theme-toggle";
import { useSwarm } from "@/lib/swarm/store";
import { cn } from "@/lib/utils";

type Tab =
  | "overview"
  | "pipeline"
  | "approval"
  | "capabilities"
  | "matrix"
  | "antitakedown"
  | "topology";

const TABS: { id: Tab; label: string; icon: React.ReactNode }[] = [
  { id: "overview", label: "Overview", icon: <LayoutDashboard className="h-3.5 w-3.5" /> },
  { id: "pipeline", label: "Pipeline", icon: <Workflow className="h-3.5 w-3.5" /> },
  { id: "approval", label: "Approval Gate", icon: <ShieldCheck className="h-3.5 w-3.5" /> },
  { id: "capabilities", label: "Capabilities & MCP", icon: <Boxes className="h-3.5 w-3.5" /> },
  { id: "matrix", label: "Model Matrix", icon: <Scale className="h-3.5 w-3.5" /> },
  { id: "antitakedown", label: "Anti-Takedown", icon: <Network className="h-3.5 w-3.5" /> },
  { id: "topology", label: "Topology", icon: <Container className="h-3.5 w-3.5" /> },
];

const PRESET_BRIEFS = [
  "RealWorldCerts brand launch — dark cinematic, emerald glow, engineers at work",
  "AWS Cloud Practitioner exam prep — 15 second promo, confidence + credibility",
  "CKA Kubernetes certification — vertical TikTok, terminal close-ups, fast cuts",
];

export default function Home() {
  const [tab, setTab] = useState<Tab>("overview");
  const [brief, setBrief] = useState(PRESET_BRIEFS[0]);
  const runs = useSwarm((s) => s.runs);
  const drafts = useMemo(() => runs.filter((r) => r.status === "draft"), [runs]);

  function handleEdit(b: string) {
    setBrief(b);
    setTab("pipeline");
  }

  return (
    <div className="flex min-h-screen flex-col bg-background">
      {/* Header */}
      <header className="sticky top-0 z-40 border-b border-border/60 bg-background/80 backdrop-blur-md">
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-4 px-4 sm:px-6">
          <div className="flex items-center gap-3">
            <div className="relative flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-emerald-500 to-emerald-700 shadow-lg shadow-emerald-500/20">
              <Network className="h-5 w-5 text-white" />
            </div>
            <div className="min-w-0">
              <h1 className="truncate text-sm font-bold leading-tight sm:text-base">
                RealWorldCerts Unified Swarm
              </h1>
              <p className="hidden text-[11px] text-muted-foreground sm:block">
                Capability Engine · LangGraph + MCP gateway
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="hidden items-center gap-3 rounded-lg border border-border/60 bg-muted/30 px-3 py-1.5 md:flex">
              <span className="flex items-center gap-1.5 text-[11px]">
                <Cpu className="h-3.5 w-3.5 text-emerald-500" />
                <span className="text-muted-foreground">RTX 3060 12GB</span>
              </span>
              <span className="h-3 w-px bg-border" />
              <span className="flex items-center gap-1.5 text-[11px]">
                <Zap className="h-3.5 w-3.5 text-amber-500" />
                <span className="font-semibold text-emerald-600 dark:text-emerald-400">online</span>
              </span>
            </div>
            <a
              href="https://github.com/younestsouli2019-bot/Nouveau-dossier-3-"
              target="_blank"
              rel="noreferrer"
              className="hidden h-9 w-9 items-center justify-center rounded-md border border-border/60 text-muted-foreground transition-colors hover:text-foreground sm:flex"
              aria-label="GitHub repository"
            >
              <Github className="h-4 w-4" />
            </a>
            <ThemeToggle />
          </div>
        </div>

        {/* Tab nav */}
        <nav className="mx-auto max-w-7xl px-2 sm:px-4">
          <div className="swarm-scroll flex items-center gap-1 overflow-x-auto py-2">
            {TABS.map((t) => (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={cn(
                  "flex shrink-0 items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium transition-colors",
                  tab === t.id
                    ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400"
                    : "text-muted-foreground hover:bg-muted/40 hover:text-foreground"
                )}
              >
                {t.icon}
                {t.label}
                {t.id === "approval" && drafts.length > 0 && (
                  <span className="ml-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-amber-500 px-1 text-[9px] font-bold text-white">
                    {drafts.length}
                  </span>
                )}
              </button>
            ))}
          </div>
        </nav>
      </header>

      {/* Main */}
      <main className="mx-auto w-full max-w-7xl flex-1 px-4 py-6 sm:px-6 sm:py-8">
        {tab === "overview" && <OverviewSection />}
        {tab === "pipeline" && <PipelineSection brief={brief} setBrief={setBrief} />}
        {tab === "approval" && <ApprovalSection onEdit={handleEdit} />}
        {tab === "capabilities" && <CapabilitiesSection />}
        {tab === "matrix" && <ModelMatrixSection />}
        {tab === "antitakedown" && <AntiTakedownSection />}
        {tab === "topology" && <TopologySection />}
      </main>

      {/* Footer */}
      <footer className="mt-auto border-t border-border/60 bg-muted/20">
        <div className="mx-auto flex max-w-7xl flex-col gap-2 px-4 py-4 text-[11px] text-muted-foreground sm:flex-row sm:items-center sm:justify-between sm:px-6">
          <p>
            <span className="font-semibold text-foreground/80">Metiutek Unified Engine</span> · extends{" "}
            <a
              href="https://github.com/younestsouli2019-bot/Nouveau-dossier-3-"
              target="_blank"
              rel="noreferrer"
              className="text-emerald-600 hover:underline dark:text-emerald-400"
            >
              Nouveau-dossier-3
            </a>{" "}
            (431 commits preserved)
          </p>
          <p className="font-mono">
            Apache 2.0 · MIT · CC BY 4.0 · licence provenance verified 2026-11-05
          </p>
        </div>
      </footer>
    </div>
  );
}
