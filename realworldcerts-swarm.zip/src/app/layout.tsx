import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { ThemeProvider } from "@/components/swarm/theme-provider";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "RealWorldCerts Unified Swarm — Capability Engine",
  description:
    "Unified gateway and LangGraph swarm control plane for the RealWorldCerts video/audio/promo pipeline. Orchestrates 7 engines via MCP with a 6-node StateGraph and 4-layer anti-takedown protocol.",
  keywords: [
    "RealWorldCerts",
    "LangGraph",
    "swarm",
    "MCP",
    "unified engine",
    "video pipeline",
    "anti-takedown",
  ],
  authors: [{ name: "Metiutek Unified Engine" }],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <ThemeProvider>
          {children}
          <Toaster />
        </ThemeProvider>
      </body>
    </html>
  );
}
