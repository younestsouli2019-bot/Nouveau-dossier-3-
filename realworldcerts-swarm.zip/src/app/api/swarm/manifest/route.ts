import { NextResponse } from "next/server";
import { MCP_SERVERS, SERVICES } from "@/lib/swarm/data";

export const runtime = "nodejs";

// GET /api/swarm/manifest — aggregated MCP tool manifest for Claude Code / Cursor.
// Mirrors the gateway/main.py get_unified_mcp_config() from the AIM brief.
export async function GET() {
  const mcpServers: Record<string, { command: string; args: string[]; description?: string; toolCount?: number }> = {};
  for (const s of MCP_SERVERS) {
    mcpServers[s.name] = {
      command: s.command,
      args: s.args,
      description: s.description,
      toolCount: s.toolCount,
    };
  }

  const totalTools = MCP_SERVERS.reduce((acc, s) => acc + s.toolCount, 0);
  const portMap: Record<string, string> = {};
  for (const s of SERVICES) {
    portMap[s.id] = `http://127.0.0.1:${s.port}`;
  }

  return NextResponse.json({
    schema: "mcp-manifest/v1",
    engine: "metiutek-unified-engine",
    generatedAt: new Date().toISOString(),
    totalTools,
    services: SERVICES.map((s) => ({
      id: s.id,
      name: s.name,
      engine: s.engine,
      port: s.port,
      role: s.role,
      status: s.status,
      capabilities: s.capabilities,
    })),
    portMap,
    mcpServers,
  });
}
