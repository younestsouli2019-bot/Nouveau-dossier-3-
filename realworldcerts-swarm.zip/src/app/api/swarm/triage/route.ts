import { NextRequest, NextResponse } from "next/server";
import { llmJson } from "@/lib/swarm/llm";
import type { SceneSpec, TriageResult } from "@/lib/swarm/types";

export const runtime = "nodejs";
export const maxDuration = 60;

interface TriageInput {
  brief: string;
  scenes: SceneSpec[];
  model: string;
}

interface TriageRaw {
  score?: number;
  verdict?: string;
  notes?: string;
  scores?: { clarity?: number; brand_fit?: number; composition?: number; pacing?: number };
}

export async function POST(req: NextRequest) {
  try {
    const { brief, scenes, model } = (await req.json()) as TriageInput;
    if (!scenes || !scenes.length) {
      return NextResponse.json({ error: "scenes required" }, { status: 400 });
    }

    const system =
      "You are the TRIAGE node of the RealWorldCerts promo-video swarm. " +
      "You score a draft against the self-improving baseline JSON and the brand bar. " +
      "Respond with STRICT JSON only. Schema: " +
      "{ \"score\": number(0-100), \"verdict\": \"approve\"|\"borderline\"|\"reject\", " +
      "\"notes\": string, \"scores\": { \"clarity\": number, \"brand_fit\": number, " +
      "\"composition\": number, \"pacing\": number } }. " +
      "approve when score >= 85, borderline 70-84, reject < 70. " +
      "notes: one concrete actionable sentence. Be honest and specific.";

    const sceneDigest = scenes
      .map(
        (s, i) =>
          `Scene ${i + 1} [${s.duration_sec}s]: ${s.shot}\n  visual: ${s.visual_prompt}\n  narration: "${s.narration}"`
      )
      .join("\n");

    const user =
      `Brief: """${brief}"""\n` +
      `Video model: ${model}\n` +
      `Scenes:\n${sceneDigest}\n` +
      `Score this draft against the brand bar.`;

    const raw = await llmJson<TriageRaw>(system, user);

    const score = Math.max(0, Math.min(100, Math.round(Number(raw.score) || 0)));
    const verdict: TriageResult["verdict"] =
      raw.verdict === "approve" || raw.verdict === "borderline" || raw.verdict === "reject"
        ? raw.verdict
        : score >= 85
          ? "approve"
          : score >= 70
            ? "borderline"
            : "reject";

    const triage: TriageResult = {
      score,
      verdict,
      notes: raw.notes || "No notes returned.",
      scores: {
        clarity: clamp(raw.scores?.clarity),
        brand_fit: clamp(raw.scores?.brand_fit),
        composition: clamp(raw.scores?.composition),
        pacing: clamp(raw.scores?.pacing),
      },
    };

    return NextResponse.json({ triage });
  } catch (err) {
    const msg = err instanceof Error ? err.message : "triage failed";
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}

function clamp(n: unknown): number {
  const v = Number(n);
  if (!Number.isFinite(v)) return 0;
  return Math.max(0, Math.min(100, Math.round(v)));
}
