import { NextRequest, NextResponse } from "next/server";
import { getZai } from "@/lib/swarm/llm";
import type { AspectRatio, GeneratedFrame, SceneSpec } from "@/lib/swarm/types";

export const runtime = "nodejs";
export const maxDuration = 60;

const SIZE_BY_ASPECT: Record<AspectRatio, string> = {
  "16:9": "1344x768",
  "9:16": "768x1344",
  "1:1": "1024x1024",
};

interface GenFramesInput {
  scenes: SceneSpec[];
  aspect: AspectRatio;
}

export async function POST(req: NextRequest) {
  try {
    const { scenes, aspect } = (await req.json()) as GenFramesInput;
    if (!scenes || !scenes.length) {
      return NextResponse.json({ error: "scenes required" }, { status: 400 });
    }
    const size = SIZE_BY_ASPECT[aspect] || "1344x768";
    const zai = await getZai();

    const frames: GeneratedFrame[] = [];
    for (const scene of scenes) {
      try {
        const response = await zai.images.generations.create({
          prompt:
            scene.visual_prompt +
            ", professional cinematic still, high detail, RealWorldCerts brand palette (emerald + amber on near-black)",
          size,
        });
        const b64 = response.data?.[0]?.base64;
        if (!b64) throw new Error("no image returned");
        frames.push({
          sceneId: scene.id,
          index: scene.index,
          shot: scene.shot,
          dataUrl: `data:image/png;base64,${b64}`,
          prompt: scene.visual_prompt,
        });
      } catch (e) {
        const msg = e instanceof Error ? e.message : "frame gen failed";
        frames.push({
          sceneId: scene.id,
          index: scene.index,
          shot: scene.shot,
          dataUrl: "",
          prompt: scene.visual_prompt,
        });
        // surface the error on the last frame's shot field via console
        console.error(`[gen-frames] scene ${scene.index} failed:`, msg);
      }
    }

    return NextResponse.json({ frames, size });
  } catch (err) {
    const msg = err instanceof Error ? err.message : "gen-frames failed";
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}
