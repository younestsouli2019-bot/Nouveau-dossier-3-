import { NextRequest, NextResponse } from "next/server";
import { llmJson } from "@/lib/swarm/llm";
import type { AspectRatio, SceneSpec } from "@/lib/swarm/types";

export const runtime = "nodejs";
export const maxDuration = 60;

interface ReconInput {
  brief: string;
  aspect: AspectRatio;
  model: string;
}

interface ReconSceneRaw {
  shot?: string;
  visual_prompt?: string;
  narration?: string;
  duration_sec?: number;
}

export async function POST(req: NextRequest) {
  try {
    const { brief, aspect, model } = (await req.json()) as ReconInput;
    if (!brief || !brief.trim()) {
      return NextResponse.json({ error: "brief is required" }, { status: 400 });
    }

    const system =
      "You are the RECON node of the RealWorldCerts promo-video swarm (a LangGraph StateGraph). " +
      "You parse a promo brief into exactly 3 cinematic scene specifications. " +
      "Respond with STRICT JSON only, no prose, no markdown fences. " +
      "Schema: { \"scenes\": [ { \"shot\": string, \"visual_prompt\": string, \"narration\": string, \"duration_sec\": number } ] } " +
      "visual_prompt must be a dense, filmic image-generation prompt (lighting, lens, mood, palette). " +
      "narration must be a single spoken line under 90 characters. " +
      "duration_sec between 3 and 6. Keep the brand RealWorldCerts (certification, engineers, credibility).";

    const user =
      `Brief: """${brief}"""\n` +
      `Aspect ratio: ${aspect}\n` +
      `Target video model: ${model}\n` +
      `Return 3 scenes as JSON.`;

    const result = await llmJson<{ scenes: ReconSceneRaw[] }>(system, user);

    const scenes: SceneSpec[] = (result.scenes || []).slice(0, 3).map((s, i) => ({
      id: `sc_${Date.now().toString(36)}_${i}`,
      index: i,
      shot: s.shot || `Scene ${i + 1}`,
      visual_prompt: s.visual_prompt || `${brief}, cinematic, ${aspect}`,
      narration:
        (s.narration || "").slice(0, 200) || "RealWorldCerts — certification that means something.",
      duration_sec: Math.max(3, Math.min(6, Number(s.duration_sec) || 4)),
    }));

    if (scenes.length === 0) throw new Error("Recon produced no scenes");

    return NextResponse.json({ scenes });
  } catch (err) {
    const msg = err instanceof Error ? err.message : "recon failed";
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}
