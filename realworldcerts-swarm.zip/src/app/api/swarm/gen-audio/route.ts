import { NextRequest, NextResponse } from "next/server";
import { getZai } from "@/lib/swarm/llm";
import type { GeneratedAudio, SceneSpec } from "@/lib/swarm/types";

export const runtime = "nodejs";
export const maxDuration = 60;

interface GenAudioInput {
  scenes: SceneSpec[];
  voice?: string;
}

// xiaochen = "沉稳专业" (calm/professional) — good fit for cert promos
const DEFAULT_VOICE = "xiaochen";

export async function POST(req: NextRequest) {
  try {
    const { scenes, voice = DEFAULT_VOICE } = (await req.json()) as GenAudioInput;
    if (!scenes || !scenes.length) {
      return NextResponse.json({ error: "scenes required" }, { status: 400 });
    }
    const zai = await getZai();

    const audio: GeneratedAudio[] = [];
    for (const scene of scenes) {
      const text = (scene.narration || "").slice(0, 1000);
      if (!text.trim()) continue;
      try {
        const response = await zai.audio.tts.create({
          input: text,
          voice,
          speed: 1.0,
          response_format: "wav",
          stream: false,
        });
        const arrayBuffer = await response.arrayBuffer();
        const buffer = Buffer.from(new Uint8Array(arrayBuffer));
        const b64 = buffer.toString("base64");
        // rough duration estimate: 24kHz mono wav, ~48KB/sec
        const durationSec = Math.max(1, Math.round(buffer.length / 48000));
        audio.push({
          sceneId: scene.id,
          narration: text,
          dataUrl: `data:audio/wav;base64,${b64}`,
          voice,
          durationSec,
        });
      } catch (e) {
        const msg = e instanceof Error ? e.message : "tts failed";
        console.error(`[gen-audio] scene ${scene.index} failed:`, msg);
        audio.push({
          sceneId: scene.id,
          narration: text,
          dataUrl: "",
          voice,
          durationSec: scene.duration_sec,
        });
      }
    }

    return NextResponse.json({ audio, voice });
  } catch (err) {
    const msg = err instanceof Error ? err.message : "gen-audio failed";
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}
