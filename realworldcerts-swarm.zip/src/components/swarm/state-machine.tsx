"use client";

import { Check, Loader2, AlertCircle, MinusCircle } from "lucide-react";
import { SWARM_NODES } from "@/lib/swarm/data";
import type { NodeId, NodeStatus } from "@/lib/swarm/types";
import { cn } from "@/lib/utils";

const STATUS_STYLE: Record<NodeStatus, string> = {
  idle: "border-border bg-card text-muted-foreground",
  running:
    "border-emerald-500/60 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 shadow-[0_0_0_3px_rgba(16,185,129,0.12)]",
  done: "border-emerald-600/40 bg-emerald-600/10 text-emerald-700 dark:text-emerald-300",
  error: "border-rose-500/60 bg-rose-500/10 text-rose-600 dark:text-rose-400",
  skipped: "border-border bg-muted text-muted-foreground/60",
};

function StatusIcon({ status }: { status: NodeStatus }) {
  if (status === "running")
    return <Loader2 className="h-3.5 w-3.5 animate-spin" />;
  if (status === "done") return <Check className="h-3.5 w-3.5" />;
  if (status === "error") return <AlertCircle className="h-3.5 w-3.5" />;
  if (status === "skipped") return <MinusCircle className="h-3.5 w-3.5" />;
  return <span className="h-1.5 w-1.5 rounded-full bg-current opacity-40" />;
}

export function StateMachine({
  nodes,
  compact = false,
}: {
  nodes: Record<NodeId, NodeStatus>;
  compact?: boolean;
}) {
  return (
    <div
      className={cn(
        "flex flex-wrap items-stretch gap-2",
        compact && "gap-1.5"
      )}
    >
      {SWARM_NODES.map((node, i) => {
        const status = nodes[node.id];
        return (
          <div key={node.id} className="flex items-center gap-2">
            <div
              className={cn(
                "relative flex flex-col rounded-lg border px-3 py-2 transition-colors",
                compact ? "min-w-[112px]" : "min-w-[140px] flex-1",
                STATUS_STYLE[status]
              )}
            >
              <div className="flex items-center justify-between gap-2">
                <span className="text-[10px] font-mono uppercase tracking-wider opacity-60">
                  {String(i + 1).padStart(2, "0")}
                </span>
                <StatusIcon status={status} />
              </div>
              <span
                className={cn(
                  "mt-1 font-semibold leading-tight",
                  compact ? "text-xs" : "text-sm"
                )}
              >
                {node.label}
              </span>
              {!compact && (
                <span className="mt-0.5 text-[10px] font-mono text-muted-foreground/80">
                  {node.runtime}
                </span>
              )}
            </div>
            {i < SWARM_NODES.length - 1 && (
              <div
                className={cn(
                  "hidden shrink-0 self-center text-muted-foreground/40 sm:block",
                  compact ? "h-px w-3 bg-current" : "h-px w-4 bg-current"
                )}
                aria-hidden
              />
            )}
          </div>
        );
      })}
    </div>
  );
}
