"use client";

import { useCallback } from "react";
import { useSwarm } from "@/lib/swarm/store";
import type { AspectRatio, SceneSpec, GeneratedFrame, GeneratedAudio, TriageResult } from "@/lib/swarm/types";
import { ANTITAKEDOWN_LAYERS } from "@/lib/swarm/data";
import { useToast } from "@/hooks/use-toast";

interface ReconResponse {
  scenes: SceneSpec[];
}
interface FramesResponse {
  frames: GeneratedFrame[];
  size: string;
}
interface AudioResponse {
  audio: GeneratedAudio[];
  voice: string;
}
interface TriageResponse {
  triage: TriageResult;
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

async function postJson<T>(url: string, body: unknown): Promise<T> {
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    const txt = await res.text().catch(() => "");
    throw new Error(`${res.status} ${res.statusText} ${txt.slice(0, 160)}`);
  }
  return (await res.json()) as T;
}

export function usePipelineRunner() {
  const {
    createRun,
    setNodeStatus,
    setSceneSpecs,
    addFrames,
    addAudio,
    setTriage,
    finalizeAssemble,
    setBaselineNote,
    setActiveRun,
  } = useSwarm();
  const { toast } = useToast();

  const runPipeline = useCallback(
    async (brief: string, aspect: AspectRatio, model: string) => {
      const id = createRun(brief, aspect, model);
      setActiveRun(id);
      const started = Date.now();

      // 1. RECON — LLM parses brief into scene specs
      setNodeStatus(id, "recon", "running");
      try {
        const { scenes } = await postJson<ReconResponse>("/api/swarm/recon", {
          brief,
          aspect,
          model,
        });
        setSceneSpecs(id, scenes);
        setNodeStatus(id, "recon", "done");
      } catch (e) {
        setNodeStatus(id, "recon", "error");
        toast({
          title: "Recon node failed",
          description: e instanceof Error ? e.message : "unknown error",
          variant: "destructive",
        });
        return id;
      }

      // 2. GEN MATRIX — parallel image + audio generation
      setNodeStatus(id, "gen_matrix", "running");
      const scenes = useSwarm.getState().runs.find((r) => r.id === id)?.sceneSpecs ?? [];
      try {
        const [framesRes, audioRes] = await Promise.all([
          postJson<FramesResponse>("/api/swarm/gen-frames", { scenes, aspect }),
          postJson<AudioResponse>("/api/swarm/gen-audio", { scenes, voice: "xiaochen" }),
        ]);
        addFrames(id, framesRes.frames);
        addAudio(id, audioRes.audio);
        setNodeStatus(id, "gen_matrix", "done");
      } catch (e) {
        setNodeStatus(id, "gen_matrix", "error");
        toast({
          title: "Gen-matrix node failed",
          description: e instanceof Error ? e.message : "unknown error",
          variant: "destructive",
        });
        return id;
      }

      // 3. TRIAGE — LLM scores the draft
      setNodeStatus(id, "triage", "running");
      try {
        const { triage } = await postJson<TriageResponse>("/api/swarm/triage", {
          brief,
          scenes,
          model,
        });
        setTriage(id, triage);
        setNodeStatus(id, "triage", "done");
      } catch (e) {
        // graceful fallback: synthetic triage so the pipeline still completes
        const fallback: TriageResult = {
          score: 78,
          verdict: "borderline",
          notes: "Triage LLM unavailable — applied fallback baseline score (78). Human review required.",
          scores: { clarity: 80, brand_fit: 82, composition: 74, pacing: 78 },
        };
        setTriage(id, fallback);
        setNodeStatus(id, "triage", "done");
        toast({
          title: "Triage fallback applied",
          description: "LLM scorer unreachable; using baseline 78.",
          variant: "default",
        });
      }

      // 4. ASSEMBLE — simulated FFmpeg mux
      setNodeStatus(id, "assemble", "running");
      await sleep(900);
      const totalDur = scenes.reduce((a, s) => a + s.duration_sec, 0);
      const mp4 = `rwc_${id.slice(-6)}_${aspect.replace(":", "x")}.mp4`;
      finalizeAssemble(id, mp4, Date.now() - started);
      setNodeStatus(id, "assemble", "done");

      // publish + self_improve wait at the approval gate
      useSwarm.setState((s) => ({
        runs: s.runs.map((r) =>
          r.id === id ? { ...r, status: "draft" } : r
        ),
      }));

      toast({
        title: "Draft ready for approval",
        description: `Triage ${useSwarm.getState().runs.find((r) => r.id === id)?.triage?.score ?? "—"}/100 — review in the Approval Gate.`,
      });
      return id;
    },
    [
      createRun,
      setActiveRun,
      setNodeStatus,
      setSceneSpecs,
      addFrames,
      addAudio,
      setTriage,
      finalizeAssemble,
      setBaselineNote,
      toast,
    ]
  );

  // Approve → publish → self_improve (fires the 4-layer deposit)
  const approveAndPublish = useCallback(
    async (id: string) => {
      useSwarm.getState().approve(id);
      await sleep(700);
      // simulate 4-layer deposit pinning
      const layers = ANTITAKEDOWN_LAYERS.map((l) => ({
        ...l,
        status: "pinned" as const,
        ref:
          l.layer === "IV-Decentralised"
            ? `Qm${id.slice(-8).toUpperCase()}${Math.random().toString(36).slice(2, 10)}`
            : l.ref,
      }));
      useSwarm.getState().setPublishLayers(id, layers);
      await sleep(500);
      setBaselineNote(
        id,
        `Baseline updated: +1 to prompt family for "${useSwarm.getState().runs.find((r) => r.id === id)?.brief.slice(0, 32) ?? "draft"}…". Iteration budget 1/5 consumed.`
      );
      useSwarm.getState().publish(id);
      toast({
        title: "Published across 4 layers",
        description: "PeerTube · Internet Archive · IPFS · RSS federation pinned.",
      });
    },
    [setBaselineNote, toast]
  );

  return { runPipeline, approveAndPublish };
}
