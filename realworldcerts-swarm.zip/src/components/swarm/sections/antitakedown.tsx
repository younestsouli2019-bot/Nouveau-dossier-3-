"use client";

import { useState } from "react";
import {
  Scale,
  Server,
  Rss,
  Network,
  ShieldAlert,
  Play,
  CheckCircle2,
  RefreshCw,
} from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ANTITAKEDOWN_LAYERS, TAKEDOWN_DRILL_STEPS } from "@/lib/swarm/data";
import { cn } from "@/lib/utils";

const LAYER_ICON = {
  "I-Legal": Scale,
  "II-Host": Server,
  "III-Discovery": Rss,
  "IV-Decentralised": Network,
} as const;

export function AntiTakedownSection() {
  const [drillRunning, setDrillRunning] = useState(false);
  const [drillStep, setDrillStep] = useState(-1);

  async function runDrill() {
    setDrillRunning(true);
    setDrillStep(-1);
    for (let i = 0; i < TAKEDOWN_DRILL_STEPS.length; i++) {
      await new Promise((r) => setTimeout(r, 900));
      setDrillStep(i);
    }
    setDrillRunning(false);
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="pb-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <CardTitle className="flex items-center gap-2 text-base">
                <Network className="h-4 w-4 text-emerald-500" />
                Four-Layer Anti-Takedown Protocol
              </CardTitle>
              <CardDescription>
                Adapted from the Self-Publishing Protocol Manual — each asset is operationally undeletable.
              </CardDescription>
            </div>
            <Badge variant="outline" className="gap-1.5 border-emerald-500/40 text-emerald-600 dark:text-emerald-400">
              <ShieldAlert className="h-3 w-3" />
              100% survivable
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2">
            {ANTITAKEDOWN_LAYERS.map((layer) => {
              const Icon = LAYER_ICON[layer.layer];
              return (
                <div
                  key={layer.layer}
                  className={cn(
                    "rounded-lg border p-4 transition-colors",
                    layer.status === "pinned"
                      ? "border-emerald-500/30 bg-emerald-500/5"
                      : "border-amber-500/30 bg-amber-500/5"
                  )}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="flex h-8 w-8 items-center justify-center rounded-md bg-background/60">
                        <Icon className="h-4 w-4 text-emerald-500" />
                      </span>
                      <div>
                        <div className="text-sm font-semibold">{layer.layer}</div>
                        <div className="text-[10px] text-muted-foreground">{layer.target}</div>
                      </div>
                    </div>
                    <Badge
                      variant="outline"
                      className={cn(
                        "text-[10px]",
                        layer.status === "pinned"
                          ? "border-emerald-500/40 text-emerald-600 dark:text-emerald-400"
                          : "border-amber-500/40 text-amber-600 dark:text-amber-400"
                      )}
                    >
                      {layer.status}
                    </Badge>
                  </div>
                  <div className="mt-3 space-y-1.5 text-[11px]">
                    <div>
                      <span className="text-muted-foreground">Original (PDF): </span>
                      <span className="text-foreground/80">{layer.original}</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Adapted (video/audio): </span>
                      <span className="text-foreground/80">{layer.adapted}</span>
                    </div>
                    <div className="flex items-center gap-1 pt-1">
                      <span className="text-muted-foreground">ref:</span>
                      <code className="truncate text-emerald-600 dark:text-emerald-400">{layer.ref}</code>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <CardTitle className="flex items-center gap-2 text-base">
                <ShieldAlert className="h-4 w-4 text-amber-500" />
                Takedown Drill Simulator
              </CardTitle>
              <CardDescription>
                Monthly drill: remove one host and verify mirrors serve the file within 60s.
              </CardDescription>
            </div>
            <Button
              onClick={runDrill}
              disabled={drillRunning}
              size="sm"
              variant="outline"
              className="gap-1.5"
            >
              {drillRunning ? <RefreshCw className="h-3.5 w-3.5 animate-spin" /> : <Play className="h-3.5 w-3.5" />}
              {drillRunning ? "Running drill…" : "Run drill"}
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {TAKEDOWN_DRILL_STEPS.map((step, i) => {
              const done = drillStep >= i;
              const active = drillRunning && drillStep === i;
              return (
                <div
                  key={i}
                  className={cn(
                    "flex items-start gap-3 rounded-lg border p-3 transition-colors",
                    done && "border-emerald-500/30 bg-emerald-500/5",
                    active && "border-amber-500/50 bg-amber-500/5",
                    !done && !active && "border-border/50 bg-muted/20"
                  )}
                >
                  <span
                    className={cn(
                      "mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full text-[10px] font-bold",
                      done
                        ? "bg-emerald-500 text-white"
                        : active
                          ? "bg-amber-500 text-white"
                          : "bg-muted text-muted-foreground"
                    )}
                  >
                    {done ? <CheckCircle2 className="h-3 w-3" /> : i + 1}
                  </span>
                  <p className="text-[11px] leading-relaxed text-foreground/80">{step}</p>
                </div>
              );
            })}
          </div>
          {!drillRunning && drillStep >= TAKEDOWN_DRILL_STEPS.length - 1 && (
            <div className="mt-3 flex items-center gap-2 rounded-lg border border-emerald-500/30 bg-emerald-500/5 p-3 text-xs">
              <CheckCircle2 className="h-4 w-4 text-emerald-500" />
              <span>Drill passed — all 4 tiers survived. IPFS CID retrievable from 3 gateways + local kubo node.</span>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
