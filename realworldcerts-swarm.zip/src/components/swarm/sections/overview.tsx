"use client";

import {
  Activity,
  Film,
  Gauge,
  Layers,
  Pin,
  ShieldCheck,
  TrendingUp,
  Cpu,
} from "lucide-react";
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useSwarm } from "@/lib/swarm/store";
import { SWARM_NODES } from "@/lib/swarm/data";
import { StateMachine } from "@/components/swarm/state-machine";
import { ScoreRing, timeAgo } from "@/components/swarm/primitives";
import type { NodeId } from "@/lib/swarm/types";

const THROUGHPUT = [
  { day: "Mon", clips: 24, score: 82 },
  { day: "Tue", clips: 31, score: 84 },
  { day: "Wed", clips: 28, score: 86 },
  { day: "Thu", clips: 33, score: 83 },
  { day: "Fri", clips: 35, score: 88 },
  { day: "Sat", clips: 22, score: 90 },
  { day: "Sun", clips: 30, score: 89 },
];

function aggregateNodeStatus(): Record<NodeId, "done"> {
  const r = {} as Record<NodeId, "done">;
  SWARM_NODES.forEach((n) => (r[n.id] = "done"));
  return r;
}

export function OverviewSection() {
  const { runs, baseline } = useSwarm();
  const drafts = runs.filter((r) => r.status === "draft");
  const todayClips = 30;
  const avgScore = baseline.avgScore;
  const ipfsPins = 247;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <KpiCard icon={<Film className="h-4 w-4" />} label="Clips today" value={String(todayClips)} sub="target 30/day" accent="emerald" />
        <KpiCard icon={<Gauge className="h-4 w-4" />} label="Avg triage score" value={avgScore.toFixed(1)} sub="90-day baseline" accent="amber" />
        <KpiCard icon={<ShieldCheck className="h-4 w-4" />} label="Approval queue" value={String(drafts.length)} sub="awaiting human review" accent="emerald" />
        <KpiCard icon={<Pin className="h-4 w-4" />} label="IPFS pins live" value={String(ipfsPins)} sub="across 3 gateways" accent="emerald" />
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-2 text-base">
                  <Layers className="h-4 w-4 text-emerald-500" />
                  LangGraph StateGraph
                </CardTitle>
                <CardDescription>6-node pipeline · CyberShield recon→triage→self-improve pattern</CardDescription>
              </div>
              <Badge variant="outline" className="gap-1.5 border-emerald-500/40 text-emerald-600 dark:text-emerald-400">
                <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-500" />
                orchestrator live
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            <StateMachine nodes={aggregateNodeStatus()} />
            <p className="mt-4 text-xs text-muted-foreground">
              Iteration ceiling 5 · non-interactive CLI defaults · OpenRouter cost ceiling active.
              Verification router terminates on triage ≥ threshold + approval granted.
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base">
              <TrendingUp className="h-4 w-4 text-amber-500" />
              Self-Improving Baseline
            </CardTitle>
            <CardDescription>swarm-memory.mjs · JSON persisted</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between rounded-lg border border-border/60 bg-muted/30 p-3">
              <div>
                <div className="text-2xl font-bold tabular-nums">{baseline.totalRuns}</div>
                <div className="text-[11px] text-muted-foreground">total pipeline runs</div>
              </div>
              <ScoreRing score={avgScore} />
            </div>
            <div>
              <div className="mb-1.5 text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
                Top prompt families
              </div>
              <div className="space-y-1.5">
                {baseline.topPromptFamilies.map((f) => (
                  <div key={f.name} className="flex items-center gap-2 text-xs">
                    <span className="flex-1 truncate font-mono">{f.name}</span>
                    <span className="tabular-nums text-muted-foreground">×{f.count}</span>
                    <span className="w-8 text-right font-semibold tabular-nums text-emerald-600 dark:text-emerald-400">
                      {f.avg}
                    </span>
                  </div>
                ))}
              </div>
            </div>
            <div>
              <div className="mb-1.5 text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
                Suppressed prompts
              </div>
              <div className="flex flex-wrap gap-1.5">
                {baseline.suppressedPrompts.map((p) => (
                  <span key={p} className="rounded bg-rose-500/10 px-2 py-0.5 font-mono text-[10px] text-rose-600 line-through dark:text-rose-400">
                    {p}
                  </span>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-base">
              <Activity className="h-4 w-4 text-emerald-500" />
              7-Day Throughput &amp; Triage Trend
            </CardTitle>
            <CardDescription>owned 12-16 GB VRAM · ~$0/mo marginal</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={220}>
              <AreaChart data={THROUGHPUT} margin={{ top: 8, right: 8, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="clipsG" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#10b981" stopOpacity={0.5} />
                    <stop offset="100%" stopColor="#10b981" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="scoreG" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#f59e0b" stopOpacity={0.4} />
                    <stop offset="100%" stopColor="#f59e0b" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" className="stroke-border/40" vertical={false} />
                <XAxis dataKey="day" tick={{ fontSize: 11 }} stroke="currentColor" className="text-muted-foreground" />
                <YAxis yAxisId="l" tick={{ fontSize: 11 }} stroke="currentColor" className="text-muted-foreground" />
                <YAxis yAxisId="r" orientation="right" domain={[70, 100]} tick={{ fontSize: 11 }} stroke="currentColor" className="text-muted-foreground" />
                <Tooltip
                  contentStyle={{
                    background: "var(--popover)",
                    border: "1px solid var(--border)",
                    borderRadius: 8,
                    fontSize: 12,
                  }}
                />
                <Area yAxisId="l" type="monotone" dataKey="clips" stroke="#10b981" strokeWidth={2} fill="url(#clipsG)" name="clips" />
                <Area yAxisId="r" type="monotone" dataKey="score" stroke="#f59e0b" strokeWidth={2} fill="url(#scoreG)" name="triage" />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base">
              <Cpu className="h-4 w-4 text-emerald-500" />
              Recent Activity
            </CardTitle>
            <CardDescription>latest runs across the swarm</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="max-h-[240px] space-y-2 overflow-y-auto pr-1 swarm-scroll">
              {runs.slice(0, 8).map((r) => (
                <div key={r.id} className="flex items-center gap-3 rounded-lg border border-border/50 bg-muted/20 p-2.5">
                  <ScoreRing score={r.triage?.score ?? 0} size={36} />
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-xs font-medium">{r.brief}</div>
                    <div className="text-[10px] text-muted-foreground">
                      {r.model} · {timeAgo(r.createdAt)}
                    </div>
                  </div>
                  <Badge
                    variant="outline"
                    className={
                      r.status === "published"
                        ? "border-emerald-500/40 text-emerald-600 dark:text-emerald-400"
                        : r.status === "draft"
                          ? "border-amber-500/40 text-amber-600 dark:text-amber-400"
                          : "text-muted-foreground"
                    }
                  >
                    {r.status}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function KpiCard({
  icon,
  label,
  value,
  sub,
  accent,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  sub: string;
  accent: "emerald" | "amber";
}) {
  const ring = accent === "emerald" ? "text-emerald-500 bg-emerald-500/10" : "text-amber-500 bg-amber-500/10";
  return (
    <Card className="overflow-hidden">
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <span className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">{label}</span>
          <span className={`flex h-7 w-7 items-center justify-center rounded-md ${ring}`}>{icon}</span>
        </div>
        <div className="mt-2 text-3xl font-bold tabular-nums">{value}</div>
        <div className="text-[11px] text-muted-foreground">{sub}</div>
      </CardContent>
    </Card>
  );
}
