"use client";

import { useState } from "react";
import {
  Play,
  Loader2,
  Clapperboard,
  ImageIcon,
  AudioLines,
  ScanSearch,
  Film,
  Send,
  Sparkles,
} from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { useSwarm } from "@/lib/swarm/store";
import { usePipelineRunner } from "@/components/swarm/use-pipeline-runner";
import { StateMachine } from "@/components/swarm/state-machine";
import { ScoreRing } from "@/components/swarm/primitives";
import { MODEL_MATRIX } from "@/lib/swarm/data";
import type { AspectRatio, PipelineRun } from "@/lib/swarm/types";
import { cn } from "@/lib/utils";

const ASPECTS: { value: AspectRatio; label: string }[] = [
  { value: "16:9", label: "16:9 YouTube" },
  { value: "9:16", label: "9:16 TikTok" },
  { value: "1:1", label: "1:1 Square" },
];

const VIDEO_MODELS = MODEL_MATRIX.filter((m) => m.role === "video" && m.commercial !== "excluded");

const PRESET_BRIEFS = [
  "RealWorldCerts brand launch — dark cinematic, emerald glow, engineers at work",
  "AWS Cloud Practitioner exam prep — 15 second promo, confidence + credibility",
  "CKA Kubernetes certification — vertical TikTok, terminal close-ups, fast cuts",
];

export function PipelineSection({
  brief,
  setBrief,
}: {
  brief: string;
  setBrief: (v: string) => void;
}) {
  const { runs, activeRunId } = useSwarm();
  const { runPipeline } = usePipelineRunner();
  const [aspect, setAspect] = useState<AspectRatio>("16:9");
  const [model, setModel] = useState("wan22");
  const [running, setRunning] = useState(false);

  const activeRun = runs.find((r) => r.id === activeRunId) || null;

  async function handleRun() {
    if (!brief.trim() || running) return;
    setRunning(true);
    try {
      await runPipeline(brief.trim(), aspect, model);
    } finally {
      setRunning(false);
    }
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <Clapperboard className="h-4 w-4 text-emerald-500" />
            Promo Brief → Swarm
          </CardTitle>
          <CardDescription>
            The recon node parses your brief into scene specs, then the gen-matrix runs image + TTS in parallel.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Textarea
            value={brief}
            onChange={(e) => setBrief(e.target.value)}
            placeholder="Describe the promo clip you want the swarm to produce…"
            className="min-h-[88px] resize-y font-medium"
          />
          <div className="flex flex-wrap gap-1.5">
            {PRESET_BRIEFS.map((b) => (
              <button
                key={b}
                onClick={() => setBrief(b)}
                className="rounded-full border border-border/60 bg-muted/30 px-3 py-1 text-[11px] text-muted-foreground transition-colors hover:border-emerald-500/40 hover:text-foreground"
              >
                {b.split("—")[0].trim()}
              </button>
            ))}
          </div>
          <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
            <div className="flex flex-wrap gap-4">
              <div>
                <div className="mb-1.5 text-[11px] font-medium uppercase tracking-wider text-muted-foreground">Aspect</div>
                <div className="flex gap-1.5">
                  {ASPECTS.map((a) => (
                    <button
                      key={a.value}
                      onClick={() => setAspect(a.value)}
                      className={cn(
                        "rounded-md border px-2.5 py-1.5 text-xs font-medium transition-colors",
                        aspect === a.value
                          ? "border-emerald-500/60 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400"
                          : "border-border/60 bg-muted/30 text-muted-foreground hover:text-foreground"
                      )}
                    >
                      {a.label}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <div className="mb-1.5 text-[11px] font-medium uppercase tracking-wider text-muted-foreground">Video model</div>
                <select
                  value={model}
                  onChange={(e) => setModel(e.target.value)}
                  className="rounded-md border border-border/60 bg-muted/30 px-2.5 py-1.5 text-xs font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500/40"
                >
                  {VIDEO_MODELS.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.name} · {m.licence}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            <Button
              onClick={handleRun}
              disabled={running || !brief.trim()}
              className="gap-2 bg-emerald-600 text-white hover:bg-emerald-700"
            >
              {running ? <Loader2 className="h-4 w-4 animate-spin" /> : <Play className="h-4 w-4" />}
              {running ? "Running pipeline…" : "Run Pipeline"}
            </Button>
          </div>
        </CardContent>
      </Card>

      {activeRun ? (
        <PipelineRunView run={activeRun} />
      ) : (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center justify-center gap-2 py-16 text-center">
            <Sparkles className="h-8 w-8 text-muted-foreground/40" />
            <p className="text-sm text-muted-foreground">
              No active run. Submit a brief to drive the 6-node StateGraph.
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

function PipelineRunView({ run }: { run: PipelineRun }) {
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="pb-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="min-w-0">
              <CardTitle className="truncate text-base">{run.brief}</CardTitle>
              <CardDescription className="font-mono">
                {run.id} · {run.aspect} · {run.model}
              </CardDescription>
            </div>
            <Badge
              variant="outline"
              className={cn(
                run.status === "running" && "border-emerald-500/40 text-emerald-600 dark:text-emerald-400",
                run.status === "draft" && "border-amber-500/40 text-amber-600 dark:text-amber-400",
                run.status === "published" && "border-emerald-500/40 text-emerald-600 dark:text-emerald-400"
              )}
            >
              {run.status}
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <StateMachine nodes={run.nodes} />
        </CardContent>
      </Card>

      <div className="grid gap-6 lg:grid-cols-2">
        <NodePanel
          icon={<ScanSearch className="h-4 w-4" />}
          title="Recon"
          status={run.nodes.recon}
          subtitle="scene specifications"
          empty="Awaiting brief parse…"
        >
          {run.sceneSpecs.length > 0 && (
            <div className="space-y-2">
              {run.sceneSpecs.map((s) => (
                <div key={s.id} className="rounded-lg border border-border/50 bg-muted/20 p-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold">
                      Scene {s.index + 1} · {s.shot}
                    </span>
                    <span className="font-mono text-[10px] text-muted-foreground">{s.duration_sec}s</span>
                  </div>
                  <p className="mt-1 text-[11px] text-muted-foreground">{s.visual_prompt}</p>
                  <p className="mt-1 text-xs italic text-foreground/80">“{s.narration}”</p>
                </div>
              ))}
            </div>
          )}
        </NodePanel>

        <NodePanel
          icon={<ImageIcon className="h-4 w-4" />}
          title="Gen Matrix — Frames"
          status={run.nodes.gen_matrix}
          subtitle="image generation (parallel)"
          empty="Frames generate after recon completes…"
        >
          {run.frames.length > 0 && (
            <div className="grid grid-cols-3 gap-2">
              {run.frames.map((f) => (
                <div key={f.sceneId} className="group relative overflow-hidden rounded-md border border-border/50 bg-muted/30">
                  <div className="aspect-video w-full">
                    {f.dataUrl ? (
                      <img src={f.dataUrl} alt={f.shot} className="h-full w-full object-cover" />
                    ) : (
                      <div className="flex h-full w-full items-center justify-center text-[10px] text-rose-500">
                        gen failed
                      </div>
                    )}
                  </div>
                  <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-1.5">
                    <span className="text-[9px] font-medium text-white/90">#{f.index + 1}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </NodePanel>

        <NodePanel
          icon={<AudioLines className="h-4 w-4" />}
          title="Gen Matrix — Audio"
          status={run.nodes.gen_matrix}
          subtitle="TTS narration (parallel)"
          empty="Narration generates after recon completes…"
        >
          {run.audio.length > 0 ? (
            <div className="space-y-2">
              {run.audio.map((a) => (
                <div key={a.sceneId} className="rounded-lg border border-border/50 bg-muted/20 p-2.5">
                  <div className="mb-1 flex items-center justify-between">
                    <span className="text-[11px] font-medium">Scene narration</span>
                    <span className="font-mono text-[10px] text-muted-foreground">{a.voice}</span>
                  </div>
                  {a.dataUrl ? (
                    <audio controls src={a.dataUrl} className="h-8 w-full" />
                  ) : (
                    <span className="text-[10px] text-rose-500">audio unavailable</span>
                  )}
                </div>
              ))}
            </div>
          ) : null}
        </NodePanel>

        <NodePanel
          icon={<ScanSearch className="h-4 w-4" />}
          title="Triage"
          status={run.nodes.triage}
          subtitle="quality scoring vs baseline"
          empty="Scoring after generation…"
        >
          {run.triage && (
            <div className="flex gap-4">
              <ScoreRing score={run.triage.score} size={72} />
              <div className="flex-1 space-y-2">
                <Badge
                  variant="outline"
                  className={cn(
                    run.triage.verdict === "approve" && "border-emerald-500/40 text-emerald-600 dark:text-emerald-400",
                    run.triage.verdict === "borderline" && "border-amber-500/40 text-amber-600 dark:text-amber-400",
                    run.triage.verdict === "reject" && "border-rose-500/40 text-rose-600 dark:text-rose-400"
                  )}
                >
                  {run.triage.verdict}
                </Badge>
                <div className="grid grid-cols-2 gap-x-3 gap-y-1 text-[11px]">
                  {Object.entries(run.triage.scores).map(([k, v]) => (
                    <div key={k} className="flex items-center gap-1.5">
                      <span className="text-muted-foreground">{k.replace("_", " ")}</span>
                      <div className="h-1 flex-1 overflow-hidden rounded bg-muted">
                        <div
                          className="h-full rounded bg-emerald-500"
                          style={{ width: `${v}%` }}
                        />
                      </div>
                      <span className="w-6 text-right tabular-nums">{v}</span>
                    </div>
                  ))}
                </div>
                <p className="text-[11px] text-muted-foreground">{run.triage.notes}</p>
              </div>
            </div>
          )}
        </NodePanel>

        <NodePanel
          icon={<Film className="h-4 w-4" />}
          title="Assemble"
          status={run.nodes.assemble}
          subtitle="FFmpeg mux → MP4"
          empty="Muxing frames + audio + captions…"
        >
          {run.assembledMp4Name && (
            <div className="flex items-center gap-3 rounded-lg border border-emerald-500/30 bg-emerald-500/5 p-3">
              <Film className="h-8 w-8 text-emerald-500" />
              <div className="min-w-0 flex-1">
                <div className="truncate font-mono text-xs font-semibold">{run.assembledMp4Name}</div>
                <div className="text-[10px] text-muted-foreground">
                  {run.sceneSpecs.reduce((a, s) => a + s.duration_sec, 0)}s · {run.aspect} · H.264 + AAC · captions burned
                </div>
              </div>
              <Badge variant="outline" className="border-emerald-500/40 text-emerald-600 dark:text-emerald-400">
                ready
              </Badge>
            </div>
          )}
        </NodePanel>

        <NodePanel
          icon={<Send className="h-4 w-4" />}
          title="Publish + Self-Improve"
          status={run.nodes.publish}
          subtitle="4-layer anti-takedown + baseline"
          empty="Fires after approval in the Approval Gate…"
        >
          {run.publishLayers.length > 0 ? (
            <div className="space-y-1.5">
              {run.publishLayers.map((l) => (
                <div key={l.layer} className="flex items-center gap-2 text-[11px]">
                  <span
                    className={cn(
                      "h-1.5 w-1.5 rounded-full",
                      l.status === "pinned" ? "bg-emerald-500" : "bg-amber-500"
                    )}
                  />
                  <span className="font-mono text-muted-foreground">{l.layer}</span>
                  <span className="flex-1 truncate">{l.target}</span>
                  <span className="font-mono text-[10px] text-muted-foreground">{l.ref.slice(0, 18)}</span>
                </div>
              ))}
              {run.baselineNote && (
                <p className="pt-1 text-[11px] italic text-muted-foreground">{run.baselineNote}</p>
              )}
            </div>
          ) : null}
        </NodePanel>
      </div>
    </div>
  );
}

function NodePanel({
  icon,
  title,
  status,
  subtitle,
  empty,
  children,
}: {
  icon: React.ReactNode;
  title: string;
  status: "idle" | "running" | "done" | "error" | "skipped";
  subtitle: string;
  empty: string;
  children: React.ReactNode;
}) {
  const hasContent =
    status === "done" || (children && Array.isArray(children) ? children.length > 0 : !!children);
  return (
    <Card className={cn(status === "running" && "border-emerald-500/40")}>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-sm">
            <span className="text-emerald-500">{icon}</span>
            {title}
          </CardTitle>
          <NodeStatusBadge status={status} />
        </div>
        <CardDescription className="text-[11px]">{subtitle}</CardDescription>
      </CardHeader>
      <CardContent>
        {hasContent ? children : (
          <div className="flex items-center gap-2 py-6 text-xs text-muted-foreground">
            {status === "running" ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : null}
            {empty}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function NodeStatusBadge({ status }: { status: string }) {
  const map: Record<string, string> = {
    idle: "text-muted-foreground border-border",
    running: "text-emerald-600 dark:text-emerald-400 border-emerald-500/40",
    done: "text-emerald-600 dark:text-emerald-400 border-emerald-500/40",
    error: "text-rose-600 dark:text-rose-400 border-rose-500/40",
    skipped: "text-muted-foreground border-border",
  };
  return (
    <Badge variant="outline" className={cn("text-[10px] uppercase", map[status])}>
      {status}
    </Badge>
  );
}
