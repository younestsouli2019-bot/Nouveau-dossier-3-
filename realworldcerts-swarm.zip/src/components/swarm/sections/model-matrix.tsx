"use client";

import { useState } from "react";
import { ShieldCheck, Scale, ExternalLink, Star } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { MODEL_MATRIX } from "@/lib/swarm/data";
import { CommercialBadge } from "@/components/swarm/primitives";
import { cn } from "@/lib/utils";

type Filter = "all" | "video" | "audio" | "tooling";

export function ModelMatrixSection() {
  const [filter, setFilter] = useState<Filter>("all");
  const rows = MODEL_MATRIX.filter((m) => filter === "all" || m.role === filter);
  const commercialCount = MODEL_MATRIX.filter((m) => m.commercial === "full").length;

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="pb-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <CardTitle className="flex items-center gap-2 text-base">
                <Scale className="h-4 w-4 text-amber-500" />
                Verified Model Matrix &amp; Licence Provenance
              </CardTitle>
              <CardDescription>
                Canonical licence files verified 2026-11-05 · 12-16 GB VRAM commercial-safe tier
              </CardDescription>
            </div>
            <div className="flex flex-wrap items-center gap-1.5">
              {(["all", "video", "audio", "tooling"] as Filter[]).map((f) => (
                <button
                  key={f}
                  onClick={() => setFilter(f)}
                  className={cn(
                    "rounded-md border px-2.5 py-1 text-[11px] font-medium capitalize transition-colors",
                    filter === f
                      ? "border-emerald-500/60 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400"
                      : "border-border/60 bg-muted/30 text-muted-foreground hover:text-foreground"
                  )}
                >
                  {f}
                </button>
              ))}
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="mb-3 flex flex-wrap gap-4 text-[11px] text-muted-foreground">
            <span className="inline-flex items-center gap-1.5">
              <ShieldCheck className="h-3.5 w-3.5 text-emerald-500" />
              {commercialCount} full-commercial models
            </span>
            <span>Apache 2.0 · MIT primary stack — no revenue threshold</span>
            <span>HunyuanVideo geo-fenced: EU / UK / KR excluded</span>
          </div>
          <div className="overflow-x-auto rounded-lg border border-border/60">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="min-w-[180px]">Model</TableHead>
                  <TableHead>Params</TableHead>
                  <TableHead>Precision</TableHead>
                  <TableHead>Min VRAM</TableHead>
                  <TableHead>Licence</TableHead>
                  <TableHead>Commercial</TableHead>
                  <TableHead className="min-w-[220px]">Restriction / note</TableHead>
                  <TableHead>Source</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.map((m) => (
                  <TableRow key={m.id}>
                    <TableCell className="font-medium">
                      <span className="flex items-center gap-1.5">
                        {m.primary && <Star className="h-3 w-3 fill-amber-400 text-amber-400" />}
                        {m.name}
                      </span>
                    </TableCell>
                    <TableCell className="font-mono text-[11px] text-muted-foreground">{m.params}</TableCell>
                    <TableCell className="font-mono text-[11px] text-muted-foreground">{m.precision}</TableCell>
                    <TableCell className="font-mono text-[11px] text-muted-foreground">{m.minVram}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className="text-[10px] font-normal">
                        {m.licence}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <CommercialBadge entry={m} />
                    </TableCell>
                    <TableCell className="text-[11px] text-muted-foreground">{m.restrictionNote}</TableCell>
                    <TableCell>
                      <a
                        href={`https://${m.source}`}
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex items-center gap-1 text-[11px] text-emerald-600 hover:underline dark:text-emerald-400"
                      >
                        {m.source.split("/")[0]}
                        <ExternalLink className="h-3 w-3" />
                      </a>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
          <p className="mt-3 text-[11px] text-muted-foreground">
            AudioCraft weights (CC-BY-NC 4.0) and CogVideoX are explicitly excluded from commercial output.
            WanGP wraps the 12 GB tier into a production floor via MMGP v4 + Profile 4 (50% less VRAM).
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
