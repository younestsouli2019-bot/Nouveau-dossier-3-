"use client";

import { useState } from "react";
import {
  Check,
  X,
  Pencil,
  Loader2,
  Inbox,
  ShieldCheck,
  Volume2,
  Layers3,
} from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useSwarm } from "@/lib/swarm/store";
import { usePipelineRunner } from "@/components/swarm/use-pipeline-runner";
import { ScoreRing, timeAgo } from "@/components/swarm/primitives";
import type { PipelineRun } from "@/lib/swarm/types";
import { cn } from "@/lib/utils";

export function ApprovalSection({ onEdit }: { onEdit: (brief: string) => void }) {
  const { approveAndPublish } = usePipelineRunner();
  const { reject, runs: allRuns } = useSwarm();
  const [publishingId, setPublishingId] = useState<string | null>(null);

  const drafts = allRuns.filter((r) => r.status === "draft");

  async function handleApprove(id: string) {
    setPublishingId(id);
    try {
      await approveAndPublish(id);
    } finally {
      setPublishingId(null);
    }
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="pb-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <CardTitle className="flex items-center gap-2 text-base">
                <ShieldCheck className="h-4 w-4 text-emerald-500" />
                Human-in-the-loop Approval Gate
              </CardTitle>
              <CardDescription>
                Next.js approval UI · Approve triggers the publish + self-improve nodes across the 4 anti-takedown layers.
              </CardDescription>
            </div>
            <Badge variant="outline" className="gap-1.5">
              <Inbox className="h-3 w-3" />
              {drafts.length} in queue
            </Badge>
          </div>
        </CardHeader>
      </Card>

      {drafts.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center justify-center gap-2 py-16 text-center">
            <Inbox className="h-8 w-8 text-muted-foreground/40" />
            <p className="text-sm text-muted-foreground">
              No drafts awaiting review. Run a pipeline to populate the queue.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2">
          {drafts.map((run) => (
            <DraftCard
              key={run.id}
              run={run}
              publishing={publishingId === run.id}
              onApprove={() => handleApprove(run.id)}
              onReject={() => reject(run.id)}
              onEdit={() => onEdit(run.brief)}
            />
          ))}
        </div>
      )}
    </div>
  );
}

function DraftCard({
  run,
  publishing,
  onApprove,
  onReject,
  onEdit,
}: {
  run: PipelineRun;
  publishing: boolean;
  onApprove: () => void;
  onReject: () => void;
  onEdit: () => void;
}) {
  const cover = run.frames[0];
  const firstAudio = run.audio[0];
  const triage = run.triage;

  return (
    <Card className="overflow-hidden">
      <div className="relative aspect-video w-full bg-muted/40">
        {cover?.dataUrl ? (
          <img src={cover.dataUrl} alt={cover.shot} className="h-full w-full object-cover" />
        ) : (
          <div className="flex h-full w-full items-center justify-center">
            <Layers3 className="h-8 w-8 text-muted-foreground/30" />
          </div>
        )}
        <div className="absolute left-2 top-2 flex gap-1.5">
          <Badge className="bg-black/70 text-white hover:bg-black/70">{run.aspect}</Badge>
          <Badge variant="outline" className="border-white/30 bg-black/50 text-white">
            {run.frames.length} frames
          </Badge>
        </div>
        {triage && (
          <div className="absolute right-2 top-2 rounded-full bg-black/70 p-1 backdrop-blur">
            <ScoreRing score={triage.score} size={40} />
          </div>
        )}
      </div>
      <CardContent className="space-y-3 p-4">
        <div>
          <h3 className="line-clamp-2 text-sm font-semibold leading-tight">{run.brief}</h3>
          <div className="mt-1 flex items-center gap-2 text-[11px] text-muted-foreground">
            <span className="font-mono">{run.model}</span>
            <span>·</span>
            <span>{timeAgo(run.createdAt)}</span>
            {triage && (
              <>
                <span>·</span>
                <span
                  className={cn(
                    "font-medium",
                    triage.verdict === "approve" && "text-emerald-600 dark:text-emerald-400",
                    triage.verdict === "borderline" && "text-amber-600 dark:text-amber-400",
                    triage.verdict === "reject" && "text-rose-600 dark:text-rose-400"
                  )}
                >
                  {triage.verdict}
                </span>
              </>
            )}
          </div>
        </div>

        {firstAudio?.dataUrl && (
          <div className="flex items-center gap-2 rounded-md bg-muted/40 p-2">
            <Volume2 className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
            <audio controls src={firstAudio.dataUrl} className="h-7 w-full" />
          </div>
        )}
        {!firstAudio?.dataUrl && firstAudio && (
          <div className="flex items-center gap-2 rounded-md bg-muted/40 p-2 text-[10px] text-muted-foreground">
            <Volume2 className="h-3.5 w-3.5" />
            audio preview unavailable — re-run pipeline to regenerate
          </div>
        )}

        {triage && <p className="line-clamp-2 text-[11px] text-muted-foreground">{triage.notes}</p>}

        <div className="flex gap-2 pt-1">
          <Button
            onClick={onApprove}
            disabled={publishing}
            size="sm"
            className="flex-1 gap-1.5 bg-emerald-600 text-white hover:bg-emerald-700"
          >
            {publishing ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Check className="h-3.5 w-3.5" />}
            {publishing ? "Publishing…" : "Approve"}
          </Button>
          <Button onClick={onReject} disabled={publishing} size="sm" variant="outline" className="gap-1.5">
            <X className="h-3.5 w-3.5" />
            Reject
          </Button>
          <Button onClick={onEdit} disabled={publishing} size="sm" variant="ghost" className="gap-1.5">
            <Pencil className="h-3.5 w-3.5" />
            Edit
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
