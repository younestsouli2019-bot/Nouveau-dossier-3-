"use client";
import { Container, Cpu, HardDrive, Zap, FileCode2, Copy, Check } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { DOCKER_SERVICES, SCRIPT_INVENTORY } from "@/lib/swarm/data";
import { useToast } from "@/hooks/use-toast";

const PYPROJECT = `[tool.uv]
workspace = { members = ["projects/*", "gateway"] }

[project]
name = "metiutek-unified-engine"
version = "1.0.0"
dependencies = [
    "fastapi>=0.110.0",
    "uvicorn>=0.28.0",
    "mcp>=0.1.0",
    "httpx>=0.27.0",
]`;

const MAKEFILE = `setup:
\tuv venv && uv sync
\t$(MAKE) build

build:
\tcd projects/Vortelio/vortelio && go build -o ../../../bin/vortelio ./cmd/vortelio
\tcd projects/editorvideo-ai/frontend && npm install && npm run build

run:
\tdocker compose up --build`;

export function TopologySection() {
  const { toast } = useToast();
  const [copied, setCopied] = useState<string | null>(null);

  async function copy(text: string, key: string) {
    await navigator.clipboard.writeText(text);
    setCopied(key);
    toast({ title: "Copied to clipboard" });
    setTimeout(() => setCopied(null), 1500);
  }

  const gpuServices = DOCKER_SERVICES.filter((s) => s.gpu).length;

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="pb-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <CardTitle className="flex items-center gap-2 text-base">
                <Container className="h-4 w-4 text-emerald-500" />
                Docker Compose Topology
              </CardTitle>
              <CardDescription>
                {DOCKER_SERVICES.length} services · {gpuServices} GPU-enabled · NVIDIA CUDA reserved
              </CardDescription>
            </div>
            <Badge variant="outline" className="gap-1.5 border-emerald-500/40 text-emerald-600 dark:text-emerald-400">
              <Zap className="h-3 w-3" />
              GPU passthrough
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {DOCKER_SERVICES.map((s) => (
              <div
                key={s.name}
                className="rounded-lg border border-border/60 bg-muted/20 p-3"
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="flex items-center gap-1.5 font-mono text-xs font-semibold">
                      {s.gpu && <Cpu className="h-3 w-3 text-amber-500" />}
                      {s.name}
                    </div>
                    <div className="mt-0.5 text-[10px] text-muted-foreground">{s.image}</div>
                  </div>
                  <Badge variant="outline" className="text-[10px]">
                    :{s.port}
                  </Badge>
                </div>
                <p className="mt-2 text-[11px] text-muted-foreground">{s.purpose}</p>
                <div className="mt-2 flex items-center gap-1.5 border-t border-border/40 pt-2 text-[10px] text-muted-foreground">
                  <HardDrive className="h-3 w-3" />
                  <code className="truncate">{s.volume}</code>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2 text-base">
                <FileCode2 className="h-4 w-4 text-amber-500" />
                pyproject.toml (uv workspace)
              </CardTitle>
              <Button variant="ghost" size="sm" className="h-7 gap-1" onClick={() => copy(PYPROJECT, "py")}>
                {copied === "py" ? <Check className="h-3 w-3 text-emerald-500" /> : <Copy className="h-3 w-3" />}
              </Button>
            </div>
            <CardDescription>Unified dependency resolution across the 7 projects</CardDescription>
          </CardHeader>
          <CardContent>
            <pre className="overflow-auto rounded-lg border border-border/60 bg-muted/30 p-3 text-[11px] leading-relaxed swarm-scroll">
{PYPROJECT}
            </pre>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2 text-base">
                <FileCode2 className="h-4 w-4 text-amber-500" />
                Makefile
              </CardTitle>
              <Button variant="ghost" size="sm" className="h-7 gap-1" onClick={() => copy(MAKEFILE, "mk")}>
                {copied === "mk" ? <Check className="h-3 w-3 text-emerald-500" /> : <Copy className="h-3 w-3" />}
              </Button>
            </div>
            <CardDescription>One command: setup → build → run</CardDescription>
          </CardHeader>
          <CardContent>
            <pre className="overflow-auto rounded-lg border border-border/60 bg-muted/30 p-3 text-[11px] leading-relaxed swarm-scroll">
{MAKEFILE}
            </pre>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <FileCode2 className="h-4 w-4 text-emerald-500" />
            Nouveau-dossier-3 Script Inventory
          </CardTitle>
          <CardDescription>
            Extend (preserve 431 commits) vs new — no financial / payout scripts touched.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto rounded-lg border border-border/60">
            <table className="w-full text-left text-[11px]">
              <thead className="bg-muted/40 text-[10px] uppercase tracking-wider text-muted-foreground">
                <tr>
                  <th className="px-3 py-2 font-medium">Script</th>
                  <th className="px-3 py-2 font-medium">Status</th>
                  <th className="px-3 py-2 font-medium">Purpose</th>
                  <th className="px-3 py-2 font-medium">Dependencies</th>
                </tr>
              </thead>
              <tbody>
                {SCRIPT_INVENTORY.map((s) => (
                  <tr key={s.script} className="border-t border-border/40">
                    <td className="px-3 py-2 font-mono text-emerald-600 dark:text-emerald-400">{s.script}</td>
                    <td className="px-3 py-2">
                      <Badge
                        variant="outline"
                        className={
                          s.status === "new"
                            ? "border-amber-500/40 text-[10px] text-amber-600 dark:text-amber-400"
                            : "border-emerald-500/40 text-[10px] text-emerald-600 dark:text-emerald-400"
                        }
                      >
                        {s.status}
                      </Badge>
                    </td>
                    <td className="px-3 py-2 text-muted-foreground">{s.purpose}</td>
                    <td className="px-3 py-2 font-mono text-[10px] text-muted-foreground">{s.deps}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
