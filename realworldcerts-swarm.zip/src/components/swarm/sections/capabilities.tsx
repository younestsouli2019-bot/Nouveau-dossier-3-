"use client";

import { useEffect, useState } from "react";
import { Cpu, Copy, Check, Terminal, Boxes } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { SERVICES } from "@/lib/swarm/data";
import { StatusDot } from "@/components/swarm/primitives";
import { useToast } from "@/hooks/use-toast";

interface Manifest {
  schema: string;
  engine: string;
  generatedAt: string;
  totalTools: number;
  services: {
    id: string;
    name: string;
    engine: string;
    port: number;
    role: string;
    status: string;
    capabilities: string[];
  }[];
  portMap: Record<string, string>;
  mcpServers: Record<string, { command: string; args: string[]; description?: string; toolCount?: number }>;
}

export function CapabilitiesSection() {
  const [manifest, setManifest] = useState<Manifest | null>(null);
  const [copied, setCopied] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    fetch("/api/swarm/manifest")
      .then((r) => r.json())
      .then(setManifest)
      .catch(() => setManifest(null));
  }, []);

  async function copyManifest() {
    if (!manifest) return;
    const mcpBlock = {
      mcpServers: Object.fromEntries(
        Object.entries(manifest.mcpServers).map(([k, v]) => [k, { command: v.command, args: v.args }])
      ),
    };
    await navigator.clipboard.writeText(JSON.stringify(mcpBlock, null, 2));
    setCopied(true);
    toast({ title: "MCP config copied", description: "Paste into Claude Code / Cursor mcp.json" });
    setTimeout(() => setCopied(false), 2000);
  }

  const totalTools = manifest?.totalTools ?? 196;

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="pb-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <CardTitle className="flex items-center gap-2 text-base">
                <Boxes className="h-4 w-4 text-emerald-500" />
                Unified Capability Registry
              </CardTitle>
              <CardDescription>
                7 engines aggregated behind one OpenAI-compat gateway · {totalTools}+ MCP tools
              </CardDescription>
            </div>
            <Badge variant="outline" className="gap-1.5 border-emerald-500/40 text-emerald-600 dark:text-emerald-400">
              gateway :8000
            </Badge>
          </div>
        </CardHeader>
      </Card>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {SERVICES.map((s) => (
          <Card key={s.id} className="flex flex-col">
            <CardHeader className="pb-2">
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2 text-sm">
                    <Cpu className="h-3.5 w-3.5 text-emerald-500" />
                    {s.name}
                  </CardTitle>
                  <CardDescription className="font-mono text-[10px]">
                    :{s.port} · {s.engine}
                  </CardDescription>
                </div>
                <div className="flex items-center gap-1.5">
                  <StatusDot status={s.status} />
                  <span className="text-[10px] uppercase text-muted-foreground">{s.status}</span>
                </div>
              </div>
            </CardHeader>
            <CardContent className="flex flex-1 flex-col gap-2">
              <p className="text-[11px] text-muted-foreground">{s.role}</p>
              <div className="flex flex-1 flex-wrap gap-1">
                {s.capabilities.map((c) => (
                  <span key={c} className="rounded bg-muted/60 px-1.5 py-0.5 text-[10px] font-mono">
                    {c}
                  </span>
                ))}
              </div>
              <div className="mt-1 flex items-center justify-between border-t border-border/40 pt-2">
                <span className="text-[10px] text-muted-foreground">
                  VRAM: <span className="font-mono text-foreground/80">{s.vram}</span>
                </span>
                <code className="text-[10px] text-muted-foreground">
                  {s.mcpCommand} {s.mcpArgs.join(" ")}
                </code>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* MCP manifest */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <CardTitle className="flex items-center gap-2 text-base">
                <Terminal className="h-4 w-4 text-amber-500" />
                Aggregated MCP Manifest
              </CardTitle>
              <CardDescription>
                Drop-in config for Claude Code / Cursor · mirrors gateway <code>mcp_configs.json</code>
              </CardDescription>
            </div>
            <Button onClick={copyManifest} variant="outline" size="sm" className="gap-1.5" disabled={!manifest}>
              {copied ? <Check className="h-3.5 w-3.5 text-emerald-500" /> : <Copy className="h-3.5 w-3.5" />}
              {copied ? "Copied" : "Copy mcp.json"}
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {manifest ? (
            <div className="grid gap-4 lg:grid-cols-2">
              <div>
                <div className="mb-2 text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
                  mcpServers
                </div>
                <pre className="max-h-[360px] overflow-auto rounded-lg border border-border/60 bg-muted/30 p-3 text-[11px] leading-relaxed swarm-scroll">
{JSON.stringify(
  Object.fromEntries(
    Object.entries(manifest.mcpServers).map(([k, v]) => [
      k,
      { command: v.command, args: v.args, tools: v.toolCount, description: v.description },
    ])
  ),
  null,
  2
)}
                </pre>
              </div>
              <div>
                <div className="mb-2 text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
                  portMap (internal relay)
                </div>
                <pre className="max-h-[360px] overflow-auto rounded-lg border border-border/60 bg-muted/30 p-3 text-[11px] leading-relaxed swarm-scroll">
{JSON.stringify(manifest.portMap, null, 2)}
                </pre>
              </div>
            </div>
          ) : (
            <div className="py-8 text-center text-xs text-muted-foreground">Loading manifest…</div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
