# RealWorldCerts Unified Swarm — Capability Engine

A Next.js 16 control plane that synthesizes the **RealWorldCerts Swarm Architecture**
(LangGraph StateGraph, 4-layer anti-takedown, license-provenance matrix) with the
**Metiutek Unified Engine** concept (7 services + MCP gateway) into a single cohesive
system. The pipeline actually runs using the z-ai-web-dev-sdk skills.

## What it does

A 7-tab gateway that orchestrates the whole swarm:

| Tab | Purpose |
|-----|---------|
| Overview | KPIs, live 6-node LangGraph StateGraph, throughput chart, self-improving baseline |
| Pipeline | Working golden path: brief → recon (LLM) → gen_matrix (image-gen + TTS in parallel) → triage (LLM) → assemble → publish + self_improve |
| Approval Gate | Human-in-the-loop draft queue; Approve triggers the 4-layer deposit + baseline update |
| Capabilities & MCP | 7 unified engines + aggregated MCP manifest (196 tools) with copy-to-`mcp.json` |
| Model Matrix | Verified license provenance (Wan 2.2 Apache, ACE-Step MIT, HunyuanVideo geo-fenced, AudioCraft/CogVideoX excluded) |
| Anti-Takedown | 4-layer protocol (Legal/Host/Discovery/Decentralised) + takedown-drill simulator |
| Topology | Docker Compose service map, `pyproject.toml` uv workspace, Makefile, Nouveau-dossier-3 script inventory |

## Tech stack

- **Framework**: Next.js 16 (App Router) + TypeScript 5
- **Styling**: Tailwind CSS 4 + shadcn/ui (New York)
- **State**: Zustand (client) + TanStack Query (server)
- **Charts**: Recharts
- **AI**: z-ai-web-dev-sdk (LLM chat completions, image generation, TTS) — backend only

## Getting started

```bash
bun install
bun run dev        # http://localhost:3000
bun run lint       # code quality
bun run db:push    # apply prisma schema (optional)
```

## Project structure

```
src/
├── app/
│   ├── api/swarm/
│   │   ├── recon/route.ts        # LLM → scene specs
│   │   ├── gen-frames/route.ts   # image generation (parallel)
│   │   ├── gen-audio/route.ts    # TTS narration (parallel)
│   │   ├── triage/route.ts       # LLM quality scoring
│   │   └── manifest/route.ts     # aggregated MCP manifest
│   ├── layout.tsx
│   └── page.tsx                  # 7-tab gateway UI
├── components/
│   ├── swarm/
│   │   ├── sections/             # overview, pipeline, approval, capabilities, matrix, antitakedown, topology
│   │   ├── state-machine.tsx     # 6-node StateGraph visual
│   │   ├── use-pipeline-runner.ts
│   │   └── primitives.tsx
│   └── ui/                       # shadcn/ui components
└── lib/
    ├── swarm/
    │   ├── types.ts              # PromoAgentState + capability registry types
    │   ├── data.ts               # nodes, services, model matrix, scripts, docker, anti-takedown
    │   ├── store.ts              # Zustand store + seed drafts
    │   └── llm.ts                # z-ai SDK helper + JSON extractor
    ├── db.ts
    └── utils.ts
```

## Architecture references

- **Source repo extended**: https://github.com/younestsouli2019-bot/Nouveau-dossier-3-
- **Model licence provenance**: verified 2026-11-05 against canonical licence files
- **Primary stack**: Wan 2.2 (Apache 2.0) + ACE-Step 1.5 (MIT) — full commercial, no threshold
- **Excluded**: AudioCraft weights (CC-BY-NC 4.0), CogVideoX (restrictive licence)

## License

Apache 2.0 · MIT · CC BY 4.0 — licence provenance verified 2026-11-05.
